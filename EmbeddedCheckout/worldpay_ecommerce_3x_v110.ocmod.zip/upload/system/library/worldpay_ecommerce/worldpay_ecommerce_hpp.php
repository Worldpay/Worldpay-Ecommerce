<?php

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';
require_once DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php';

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Enums\Api;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\ApiResponseException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;

class WorldpayEcommerceHpp extends WorldpayEcommerce {
	/**
	 * @throws \Worldpay\Api\Exceptions\ApiClientException
	 *
	 * @return \Worldpay\Api\ApiResponse
	 */
	public function testApiCredentials(): ?ApiResponse {
		$api = $this->worldpay_service->initializeApi();
		$api_config_provider = AccessWorldpayConfigProvider::instance();
		$api_response        = null;

		$api_config_provider->api = Api::ACCESS_WORLDPAY_HPP_API;

		return $api->initiatePayment(1)
			->withCurrency('GBP')
			->withTransactionReference(Helper::generateString(12) . '_test')
			->execute();
	}

	/**
	 * @param string $transaction_reference
	 * @param string $success_return_url
	 * @param string $failure_return_url
	 * @param string $cancel_return_url
	 *
	 * @throws ApiClientException
	 * @throws AuthenticationException
	 * @throws InvalidArgumentException
	 * @throws ApiResponseException
	 * @throws \Exception
	 *
	 * @return string|null
	 */
	public function retrieveHppUrl(string $transaction_reference, string $success_return_url, string $failure_return_url = '', string $cancel_return_url = ''): ?string {
		$order = $this->worldpay_service->getOrderData($this->order_data);
		$result_URLs = null;
		if (!empty($success_return_url) && !empty($failure_return_url) && !empty($cancel_return_url)) {
			$result_URLs = $this->worldpay_service->getResultUrls($success_return_url, $failure_return_url, $cancel_return_url);
		}

		$api = $this->worldpay_service->initializeApi();
		$api_config_provider = AccessWorldpayConfigProvider::instance();
		$api_config_provider->api = Api::ACCESS_WORLDPAY_HPP_API;

		$api_request = $api->initiatePayment($order->amount)
			->withTransactionReference($transaction_reference)
			->withOptionalOrder($order);

		if (!empty($this->worldpay_service->getDescription())) {
			$api_request = $api_request->withDescription($this->worldpay_service->getDescription());
		}

		if (!empty($result_URLs)) {
			$api_request = $api_request->withResultURLs($result_URLs);
		}

		$api_response = $api_request->execute();

		$data_to_log = [
			"checkout_mode"    => $this->worldpay_service->getCheckoutMode(),
			"api_request"      => $api_response->rawRequest,
			"api_response"     => $api_response->rawResponse,
			"wp-correlationid" => $this->getWpCorrelationId($api_response->headers),
		];
		Logger::setDescription("Retrieve Hpp url - HPP API Response")->debug($data_to_log);

		if ($api_response->statusCode !== 200) {
			throw new \Exception($api_response->rawResponse);
		}

		$decoded_api_response = $api_response->jsonDecode();

		return $decoded_api_response->url ?? '';
	}
}
