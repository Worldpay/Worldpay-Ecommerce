# Worldpay eCommerce for OpenCart change log

## [v1.1.0] (02/06/2025)
* Added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment.

## [v1.0.1] (07/12/2024)
* Added compatibility checks
* Added iframe support
* Added regex validation for merchant narrative.
* Added Description setting.
* Removed GBP checkout restriction.

## [v1.0.0] (04/05/2024)
* Initial release.