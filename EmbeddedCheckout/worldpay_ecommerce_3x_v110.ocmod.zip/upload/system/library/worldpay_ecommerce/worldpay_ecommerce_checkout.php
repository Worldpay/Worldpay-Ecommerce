<?php

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';
require_once DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php';

use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Api;
use Worldpay\Api\Enums\FraudType;
use Worldpay\Api\Enums\PaymentInstrumentType;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\ApiResponseException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Forms\Challenge;
use Worldpay\Api\Forms\DeviceDataCollection;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;
use Worldpay\Api\ValueObjects\ThreeDS;

class WorldpayEcommerceCheckout extends WorldpayEcommerce {
	/**
	 * Initialize payment request.
	 *
	 * @param string $transaction_reference
	 * @param string $payment_session
	 * @param string $card_holder_name
	 * @param string $threeDSChallengeReturnUrl
	 *
	 * @throws ApiClientException
	 * @throws InvalidArgumentException
	 * @throws ApiResponseException
	 * @throws \Exception
	 *
	 * @return object
	 */
	public function initializePayment(
		string $transaction_reference,
		string $payment_session,
		string $card_holder_name,
		string $threeDSChallengeReturnUrl
	) {
		$api   = $this->worldpay_service->initializeApi();
		$order = $this->worldpay_service->getOrderData($this->order_data);
		$payment_instrument = $this->createPaymentInstrumentObject($payment_session, $card_holder_name);
		$three_ds           = $this->createThreeDSObject($threeDSChallengeReturnUrl);

		$api_response = $api->initiatePayment($order->amount)
			->withCurrency($order->currency)
			->withTransactionReference($transaction_reference)
			->withPaymentInstrument($payment_instrument)
			->withThreeDS($three_ds)
			->withAutoSettlement()
			->withFraudType(FraudType::FRAUD_SIGHT)
			->withOptionalOrder($order)
			->execute();

		if (!$api_response->isSuccessful()) {
			throw new \Exception($api_response->rawResponse);
		}

		$api_response = $api_response->jsonDecode();
		if (empty($api_response->outcome) || empty($api_response->transactionReference)) {
			throw new \Exception('API breach of contract');
		}

		return $api_response;
	}

	/**
	 * Submit device data collection request.
	 *
	 * @param string $supply_3ds_device_link_data
	 * @param string $collection_reference
	 *
	 * @throws ApiClientException
	 * @throws ApiResponseException|AuthenticationException
	 *
	 * @return object
	 */
	public function supply3DSDeviceData(string $supply_3ds_device_link_data, string $collection_reference) {
		$api          = $this->worldpay_service->initializeApi();
		$api_response = $api->provide3DSDeviceData()
			->withLinkData($supply_3ds_device_link_data ?? '')
			->withCollectionReference($collection_reference)
			->execute();

		if (!$api_response->isSuccessful()) {
			throw new \Exception($api_response->rawResponse);
		}

		$api_response = $api_response->jsonDecode();
		if (empty($api_response->outcome) || empty($api_response->transactionReference)) {
			throw new \Exception('API breach of contract');
		}

		return $api_response;
	}

	/**
	 * 3DS Challenge result check request.
	 *
	 * @param string $complete3DSChallengeUrl
	 *
	 * @throws ApiClientException
	 * @throws ApiResponseException
	 * @throws AuthenticationException
	 *
	 * @return mixed|object
	 */
	public function fetch3DSChallengeResult(string $complete3DSChallengeUrl) {
		$api          = $this->worldpay_service->initializeApi();
		$api_response = $api->challenge3DSResult()
			->withLinkData($complete3DSChallengeUrl)
			->execute();

		if (!$api_response->isSuccessful()) {
			throw new \Exception($api_response->rawResponse);
		}

		$api_response = $api_response->jsonDecode();
		if (empty($api_response->outcome) || empty($api_response->transactionReference)) {
			throw new \Exception('API breach of contract');
		}

		return $api_response;
	}

	/**
	 * @throws ApiClientException
	 *
	 * @return ApiResponse
	 */
	public function testApiCredentials(): ?ApiResponse {
		$api                 = $this->worldpay_service->initializeApi();
		$api_config_provider = AccessWorldpayConfigProvider::instance();

		$api_config_provider->checkoutId = $api_config_provider->checkoutId ?? $this->worldpay_service->getCheckoutId();
		$api_config_provider->api        = Api::ACCESS_WORLDPAY_PAYMENT_SESSIONS_API;
		$api_response                    = $api->createPaymentSession($api_config_provider->checkoutId)
			->withCardExpiryMonth(date('n', strtotime('+1 month')))
			->withCardExpiryYear(date('Y', strtotime('+1 year')))
			->withCardNumber('4444333322221111')
			->withCardCvc('123')
			->execute();
		if ($api_response->isSuccessful()) {
			$decoded_api_response = json_decode($api_response->rawResponse, true);
			$session_url          = $decoded_api_response['_links']['sessions:session']['href'] ?? null;
			if ($session_url) {
				$api_config_provider->api = Api::ACCESS_WORLDPAY_PAYMENTS_API;
				$payment_instrument       = $this->createPaymentInstrumentObject($session_url, '');
				$api_response             = $api->initiatePayment(1)
					->withCurrency('GBP')
					->withTransactionReference(Helper::generateString(12) . "_test")
					->withPaymentInstrument($payment_instrument)
					->withAutoSettlement()
					->execute();
			} else {
				throw new Exception('Payment session is not set up, but username, password and checkout id are valid.');
			}
		}

		return $api_response;
	}

	/**
	 * Create payment instrument object.
	 *
	 * @param            $session_href
	 * @param            $card_holder_name
	 * @param Order|null $order
	 *
	 * @return CreditCard
	 */
	public function createPaymentInstrumentObject($session_href, $card_holder_name) {
		$payment_instrument                 = new CreditCard(PaymentInstrumentType::CHECKOUT);
		$payment_instrument->sessionHref    = $session_href;
		$payment_instrument->cardHolderName = $card_holder_name;

		return $payment_instrument;
	}

	/**
	 * @param string $threeDSChallengeReturnUrl
	 *
	 * @return ThreeDS
	 */
	public function createThreeDSObject(string $threeDSChallengeReturnUrl) {
		$three_ds                        = new ThreeDS();
		$three_ds->challengeReturnUrl    = $threeDSChallengeReturnUrl;
		$three_ds->deviceDataAgentHeader = $_SERVER['HTTP_USER_AGENT'];

		return $three_ds;
	}

	/**
	 * Get checkout-sdk url based on the API environment in config.
	 *
	 * @return string
	 */
	public function getCheckoutSdkUrl() {
		return AccessWorldpay::checkoutSdkUrl($this->worldpay_service->getApiEnvironment());
	}

	/**
	 * @param $url
	 * @param $bin
	 * @param $jwt
	 *
	 * @return DeviceDataCollection
	 */
	public function getDeviceDataCollectionForm($url, $bin, $jwt) {
		return new DeviceDataCollection(
			'access_worldpay_checkout-ddc-form',
			$url ?? '',
			$bin ?? '',
			$jwt ?? ''
		);
	}

	/**
	 * @param $url
	 * @param $jwt
	 * @param $hash
	 *
	 * @return Challenge
	 */
	public function get3DSChallengeForm($url, $jwt, $hash) {
		return new Challenge(
			'access_worldpay_checkout-challenge-form',
			$url ?? '',
			$jwt ?? '',
			$hash ?? '',
		);
	}
}
