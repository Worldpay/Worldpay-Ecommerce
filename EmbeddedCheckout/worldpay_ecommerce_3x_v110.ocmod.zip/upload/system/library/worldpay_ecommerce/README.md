## Worldpay eCommerce for OpenCart

Worldpay eCommerce helps enhance your online checkout experience and payments processing, so your customers can easily and safely pay how they want, which may result in fewer abandoned carts, less fraud and more sales.

### License

License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

### Features

- Embedded Checkout
- Hosted Payment Pages
- Pay with a new card
- Pay with a Mobile Wallet (Apple Pay or Google Pay)

### Compatibility

Worldpay eCommerce for OpenCart is tested with OpenCart 3.0.3.7, which itself requires PHP 7.3 or above.
This extension also needs php-mbstring and php-intl extensions to be enabled on the supporting server.

Worldpay eCommerce for OpenCart requires cookie policy set to `Lax` to allow redirect the customer's browser to the Hosted Payment Pages session URL.

### Support

For any other issues or further support log into <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a> and visit our support centre.

### Installation

1. Login to the OpenCart Admin Panel
2. Navigate to Extensions -> Installer and click on the option to Upload the extension file (on the right top of the page).
3. Choose the zip file worldpay_ecommerce.ocmod.zip.
4. When the upload is finished, the Worldpay eCommerce for OpenCart extension should be listed under Installed Extensions on the same page.
5. Click on the green plus icon button for Install
6. Navigate to Extensions -> Extensions and select the extension type Payments
7. Click on the designated green plus icon button to finalize the extension installation.
8. Click on the designated Edit button to configure the extension.
9. Enable the extension, configure and save the extension settings.

Important note: Go to System -> Settings -> Edit Store -> Server tab and be sure `Session Samesite Cookie` is set to `Lax`.

### Retrieve your credentials

1. Log into your <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a>.
2. Click on "Account & Settings".
3. Click on "Configuration Settings".
4. Click on "API credentials".
5. Switch between "Try mode" and "Live mode" and retrieve your username and password. You need:
- a Try API username
- a Try API password
6. If you're using Payments Onsite (with embedded checkout) you will also need the Checkout Id (please contact support).

### Retrieve your entity

1. Log into your <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a>.
2. Click on "Account & Settings".
3. Click on "Manage Account".
4. Click on "Business Details".
5. Use the second POxxxxxxxxx from the top as your entity.

### Go live
1. Log into your dashboard and get your Live credentials (see steps below). You need:
- a Live API username
- a Live API password
- an entity
- a Checkout Id (optional)
  These will be different from any other worldpay credentials you have already.
2. Navigate to the OpenCart config screen.
3. Ensure you have selected the "Live" environment.
4. Ensure the new "Live" entity reference is entered.
5. Copy and paste the credentials from your dashboard to the config screen, this time making sure they are going into the "Live API Credentials" section.
6. Ensure the "Debug mode" toggle is off.
7. Save the extension settings.
8. You can now initiate a Live transaction.