<?php
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once(DIR_APPLICATION . 'model/extension/payment/access_worldpay_model.php');

class ModelExtensionPaymentAccessWorldpayHpp extends \AccessWorldpayModel {
	/**
	 * @var string
	 */
	protected $payment_method = \AccessWorldpayPaymentMethods::HPP;

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 * @param string $mode
	 *
	 * @return bool
	 */
	public function saveTransactionInitialDetails(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url, string $mode): bool {
		$this->db->query("INSERT INTO `" . DB_PREFIX . $this->payment_method . "_transactions` SET `order_id` = '" . (int)$order_data["order_id"] . "', `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `env_mode` = '" . $mode . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW();");

		return true;
	}

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 *
	 * @return bool
	 */
	public function updateTransactionInitialDetailsByOcOrderId(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url): bool {
		$query = $this->db->query("UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW() WHERE `order_id` = " . (int)$order_data["order_id"] . ";");

		return true;
	}

	/**
	 * @param string $guid
	 *
	 * @return array
	 */
	public function getTransactionDetailsByGuid(string $guid): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . $this->payment_method . "_transactions` WHERE (`success_guid` = '" . $this->db->escape($guid) . "' OR `failure_guid` = '" . $this->db->escape($guid) . "') AND `finalized` = false AND `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "' ORDER BY `id` DESC LIMIT 1;");

		return $query->row;
	}
}
