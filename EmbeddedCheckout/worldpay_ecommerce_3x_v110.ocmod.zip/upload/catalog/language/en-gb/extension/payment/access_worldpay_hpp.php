<?php

include_once 'access_worldpay.php';

$_['heading_title'] = 'Pay with Card (Worldpay)';
$_['error_payment_hpp_url'] = 'Payment failed!';
