<?php

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/string_utils.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/admin/access_worldpay_controller.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce_checkout.php');

class ControllerExtensionPaymentAccessWorldpayCheckout extends \AccessWorldpayController {
	/**
	 * @var string
	 */
	protected $payment_method = \AccessWorldpayPaymentMethods::CHECKOUT;

	/**
	 * @return array
	 */
	protected function getSettingFields(): array {
		$output = parent::getSettingFields();

		$output['payment_access_worldpay_app_merchant_try_checkout_id']  = $this->config->get('payment_' . $this->payment_method . '_app_merchant_try_checkout_id');
		$output['payment_access_worldpay_app_merchant_live_checkout_id'] = $this->config->get('payment_' . $this->payment_method . '_app_merchant_live_checkout_id');
		$card_brands = unserialize($this->config->get('payment_' . $this->payment_method . '_app_card_brands') ?? "");
		$output['payment_access_worldpay_app_card_brands'] = false === $card_brands ? [] : $card_brands;
		$output['payment_access_worldpay_app_card_brands_multiselect_options'] = ['visa', 'mastercard', 'amex'];

		return $output;
	}
}
