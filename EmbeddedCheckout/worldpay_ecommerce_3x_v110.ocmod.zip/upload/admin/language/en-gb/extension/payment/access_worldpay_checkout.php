<?php

include_once 'access_worldpay.php';

// Heading
$_['heading_title'] = 'Worldpay Payment Onsite';

// Text
$_['text_success']   = 'Success: You have modified Worldpay Payment Onsite payment module!';
$_['text_edit']      = 'Edit Worldpay Payment Onsite';

$_['text_access_worldpay_checkout']	= '<a target="_BLANK" href="https://www.worldpay.com/en-gb"><img src="view/image/payment/worldpay_ecommerce.png" alt="Worldpay eCommerce" title="Worldpay eCommerce" style="max-width: 150px;" /></a>';

$_['entry_merchant_checkout_id']       = 'Merchant checkout id';
$_['entry_merchant_checkout_id_help']  = 'Checkout id that is required to create a payment session.';

$_['error_try_checkout_id']               = 'The API Try merchant checkout id is mandatory when you enable Try mode.';
$_['error_live_checkout_id']              = 'The API Live merchant checkout id is mandatory when you enable Live mode.';

$_['entry_app_card_brands'] = 'Card brands';
$_['entry_app_card_brands_help'] = 'Select the card brands displayed and used in checkout.';
$_['error_app_card_brands'] = 'Card brands field is mandatory so they can be displayed in the checkout form.';
