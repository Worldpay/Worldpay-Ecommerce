<?php

namespace Opencart\Admin\Model\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;

class AccessWorldpayCheckout extends AccessWorldpay {
	protected $payment_method = AccessWorldpayPaymentMethods::CHECKOUT;

	public function getPaymentMethodTransactionTableSql(): string {
		return "
		CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . $this->payment_method . "_transactions` (
			`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			`order_id` BIGINT UNSIGNED NOT NULL,
			`reference` VARCHAR(100) NOT NULL,
			`amount` DECIMAL(15,4) NOT NULL,
			`currency` VARCHAR(3) NOT NULL,
			`order_status` ENUM('" . WorldpayService::TRANSACTION_STATUS_PENDING . "', '" . WorldpayService::TRANSACTION_STATUS_SUCCESS . "', '" . WorldpayService::TRANSACTION_STATUS_FAILED . "', '" . WorldpayService::TRANSACTION_STATUS_CANCELED . "') DEFAULT '" . WorldpayService::TRANSACTION_STATUS_PENDING . "',
			`env_mode` ENUM('try', 'live'),
			`payment_status` VARCHAR(100),
			`link_data` TEXT NULL,
			`supply_3ds_device_data_url` TEXT NULL,
			`complete_3ds_challenge_url` TEXT NULL,
			`finalized` BOOLEAN DEFAULT FALSE,
			`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY (`reference`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		";
	}

	/**
	 * Get link data for payment management.
	 *
	 * @param  string  $transaction_reference
	 *
	 * @return string
	 */
	public function getLinkDataByTransactionReference(string $transaction_reference) {
		if (!$transaction_reference) {
			return '';
		}

		$query = $this->db->query( "SELECT `link_data` FROM `" . DB_PREFIX . $this->payment_method . "_transactions` WHERE `reference` = '" . $this->db->escape( $transaction_reference ) . "';" );

		return ($query->row)['link_data'];
	}
}
