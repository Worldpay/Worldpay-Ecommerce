<?php

include_once 'access_worldpay.php';

// Heading
$_['heading_title'] = 'Worldpay Payment Offsite';

// Text
$_['text_success']   = 'Success: You have modified Worldpay Payment Offsite payment module!';
$_['text_edit']      = 'Edit Worldpay Payment Offsite';

$_['entry_checkout_mode']               = 'Checkout mode';
$_['entry_redirect_mode']               = 'Redirect';
$_['entry_iframe_mode']                 = 'Iframe';

$_['text_access_worldpay_hpp']		= '<a target="_BLANK" href="https://www.worldpay.com/en-gb"><img src="../extension/worldpay_ecommerce/admin/view/image/payment/worldpay_ecommerce.png" alt="Worldpay eCommerce" title="Worldpay eCommerce" style="max-width: 150px;" /></a>';
