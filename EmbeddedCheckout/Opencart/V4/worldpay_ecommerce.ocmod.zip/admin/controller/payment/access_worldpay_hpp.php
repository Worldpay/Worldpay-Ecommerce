<?php

namespace Opencart\Admin\Controller\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\Admin\AccessWorldpayController;

class AccessWorldpayHpp extends AccessWorldpayController {

	/**
	 * @var string
	 */
	protected $payment_method = AccessWorldpayPaymentMethods::HPP;

	/**
	 * @return array
	 */
	protected function getSettingFields(): array {
		$output = parent::getSettingFields();

		$output['payment_access_worldpay_app_description'] = $this->config->get('payment_' . $this->payment_method . '_app_description');
		$output['payment_access_worldpay_checkout_mode']   = $this->config->get('payment_' . $this->payment_method . '_checkout_mode');

		return $output;
	}
}
