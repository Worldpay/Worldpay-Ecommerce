<?php

namespace Opencart\Catalog\Controller\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\Logger;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceHpp;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;
use Worldpay\Api\Utils\Helper;

class AccessWorldpayHpp extends AccessWorldpay {

	/**
	 * @var string
	 */
	protected $payment_method = AccessWorldpayPaymentMethods::HPP;

	public function index() {
		$data = parent::index();
		$data['checkout_mode'] = $this->config->get('payment_' . $this->payment_method . '_checkout_mode');
		if ($data['checkout_mode'] == 'iframe') {
			$json = $this->getHppUrl();
			if ( ! empty( $json['error'] ) ) {
				$data['error'] = ! is_array( $json['error'] ) ? $json['error'] : implode( '. ', $json['error'] );
			} else {
				$data['hppURL'] = $json['redirect'];
			}
		}
		return $this->load->view('extension/worldpay_ecommerce/payment/' . $this->payment_method, $data);
	}

	/**
	 * @return void
	 */
	public function returnUrl(): void {
		Logger::config($this->config, $this->payment_method);

		$url_redirect_params = [
			'language' => $this->config->get('config_language')
		];

		$data = [];
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('checkout/order');

		$guid = $this->request->get["guid"] ?? '';
		if (empty($guid)) {
			$data_to_log = [
				"checkout_mode" => $this->config->get('payment_' . $this->payment_method . '_checkout_mode'),
				"request_data"  => $this->request->get,
			];
			Logger::setDescription("Return url - invalid guid")->alert($data_to_log);
			$this->redirectToNotFound();
		}

		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$order_details = $this->{$model}->getTransactionDetailsByGuid($guid);
		if (empty($order_details)) {
			$data_to_log = [
				"request_data" => $this->request->get,
			];
			Logger::setDescription("Return url - invalid order")->alert($data_to_log);
			$this->redirectToNotFound();
		}

		$order_id = $order_details['order_id'];

		$data_to_log = [
			"checkout_mode" => $this->config->get('payment_' . $this->payment_method . '_checkout_mode'),
			"guid"          => $guid,
			"order_id"      => $order_id,
			"order_details" => $order_details,
			"request_data"  => $this->request->get,
		];
		$data_to_log["order_details"]["amount"] = number_format($order_details['amount'], 2, '.', '');

		$amount_with_currency = $this->currency->format($order_details['amount'], $order_details['currency'], 1);

		switch ($guid) {
			case $order_details["success_guid"]:
				$order_note = $amount_with_currency . " " . $this->language->get('payment_success_via_worldpay') . $order_details["reference"];
				$data['redirect'] = $this->processPaymentSuccessUrl($order_details, $url_redirect_params, $order_note);

				$data_to_log["order_details"]["order_status"] = WorldpayService::TRANSACTION_STATUS_SUCCESS;
				$this->session->data['order_id'] = $order_id;
				Logger::setDescription("Return url - success payment")->debug($data_to_log);
				break;

			case $order_details["failure_guid"]:
				$order_note = $amount_with_currency . " " . $this->language->get('payment_failed_via_worldpay') . $order_details["reference"];
				$data['redirect'] = $this->processPaymentFailureUrl($order_details, $url_redirect_params, $order_note);

				$data_to_log["order_details"]["order_status"] = WorldpayService::TRANSACTION_STATUS_FAILED;
				Logger::setDescription("Return url - failed payment")->debug($data_to_log);
				break;
		}

		$this->response->redirect($data['redirect']);
	}

	/**
	 * @param        $order_details
	 * @param array  $url_redirect_params
	 * @param string $order_note
	 *
	 * @return string
	 */
	protected function processPaymentSuccessUrl($order_details, array $url_redirect_params, string $order_note): string {
		$this->model_checkout_order->addHistory($order_details['order_id'], WorldpayService::OC_ORDER_STATUS_ID_PROCESSING, $order_note, true);
		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$this->{$model}->changeTransactionStatus($order_details['id'], WorldpayService::TRANSACTION_STATUS_SUCCESS);

		if (empty($url_redirect_params)) {
			return "";
		}

		return $this->url->link('checkout/success', $url_redirect_params, true);
	}

	/**
	 * @param        $order_details
	 * @param array  $url_redirect_params
	 * @param string $order_note
	 *
	 * @return string
	 */
	protected function processPaymentFailureUrl($order_details, array $url_redirect_params, string $order_note): string {
		if ($this->config->get('payment_' . $this->payment_method . '_checkout_mode') == 'redirect') {
			$this->model_checkout_order->addHistory($order_details['order_id'], WorldpayService::OC_ORDER_STATUS_ID_FAILED, $order_note, true);
		}
		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$this->{$model}->changeTransactionStatus($order_details['id'], WorldpayService::TRANSACTION_STATUS_FAILED);

		return $this->url->link('checkout/failure', $url_redirect_params, true);
	}

	/**
	 * @throws \Exception
	 *
	 * @return array
	 */
	protected function getHppUrl(): array {
		Logger::config($this->config, $this->payment_method);

		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		$json = $this->validateOrder();

		$order_id = $this->session->data['order_id'] ?? 0;
		$this->load->model('checkout/order');
		$order_data = $this->model_checkout_order->getOrder($order_id);
		if (empty($order_data)) {
			$json['error'] = $this->language->get('error_order');
		}

		if (!$json) {
			$success_guid = Helper::guidv4();
			$failure_guid = Helper::guidv4();
			$transaction_reference = WorldpayService::getTransactionReferenceByOrderId($order_id);

			$success_return_url = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.returnUrl', ['language' => $this->config->get('config_language'), 'guid' => $success_guid], false);
			$failure_return_url = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.returnUrl', ['language' => $this->config->get('config_language'), 'guid' => $failure_guid], false);
			$cancel_return_url = $this->url->link('checkout/checkout', ['language' => $this->config->get('config_language')]);

			// currency conversion manage
			$order_currency_conversion_log_info = [
				'session_currency'     => $this->session->data['currency'],
				'config_currency'      => $this->config->get('config_currency'),
				'order_total'          => $order_data['total'],
				'order_currency_code'  => $order_data['currency_code'],
				'order_currency_value' => $order_data['currency_value'],
			];
			$order_data['total'] = $this->currency->format($order_data['total'], $order_data['currency_code'], $order_data['currency_value'], false);
			$order_currency_conversion_log_info['currency_conversion_amount'] = $order_data['total'];

			try {
				$worldpay = new WorldpayEcommerceHpp($this->worldpay_service, $order_data);
				$hpp_url = $worldpay->retrieveHppUrl($transaction_reference, $success_return_url, $failure_return_url, $cancel_return_url);
				$json['redirect'] = $hpp_url;
				$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;

				// Workaround for internal OpenCart 4 bug for products that don't require shipping (fixed in version 4.1.0.0)
				if (empty($order_data['shipping_method']['name']) && VERSION < '4.1.0.0') {
					$shipping_method = $order_data['shipping_method'];
					$shipping_method['name'] = '';
					$this->{$model}->setOrderShippingMethod($order_id, json_encode($shipping_method));
				}

				if ($this->config->get('payment_' . $this->payment_method . '_checkout_mode') == 'redirect') {
					$note = $this->currency->format($order_data['total'], $order_data['currency_code'], 1) . ' awaiting payment via Worldpay. Transaction reference ' . $transaction_reference;
					$this->model_checkout_order->addHistory($order_id, WorldpayService::OC_ORDER_STATUS_ID_PENDING, $note);
				}

				$this->{$model}->saveTransactionInitialDetails($order_data, $transaction_reference, $success_guid, $failure_guid, $hpp_url, $this->config->get('payment_access_worldpay_hpp_app_mode'));

				$data_to_log = [
					"checkout_mode"             => $this->config->get('payment_' . $this->payment_method . '_checkout_mode') ?? '',
					"order_id"                  => $order_id,
					"order_data"                => $order_data,
					"order_currency_conversion" => $order_currency_conversion_log_info
				];
				Logger::setDescription("Retrieve Hpp url")->debug($data_to_log);
			} catch (\Throwable $exception) {
				$data_to_log = [
					"checkout_mode"             => $this->config->get('payment_' . $this->payment_method . '_checkout_mode') ?? '',
					"message"                   => $exception->getMessage(),
					"order_id"                  => $order_id,
					"order_data"                => $order_data,
					"success_return_url"        => $success_return_url,
					"failure_return_url"        => $failure_return_url,
					"cancel_return_url"         => $cancel_return_url,
					"transaction_reference"     => $transaction_reference,
					"hpp_url"                   => $hpp_url ?? "",
					"order_currency_conversion" => $order_currency_conversion_log_info
				];
				Logger::setDescription("Retrieve Hpp url failed")->alert($data_to_log);

				$json['error'] = $this->language->get('error_payment_hpp_url');
			}
		} else {
			$data_to_log = [
				"checkout_mode" => $this->config->get('payment_' . $this->payment_method . '_checkout_mode') ?? '',
				"order_id"      => $order_id ?? "",
				"order_data"    => $order_data ?? [],
				"confirm_json"  => $json,
			];
			Logger::setDescription("Retrieve Hpp url failed - configuration error")->alert($data_to_log);
		}

		return $json;
	}

	/**
	 * @throws \Exception
	 *
	 * @return void
	 */
	public function confirm(): void {
		$json = $this->getHppUrl();
		if (!empty($json['redirect'])) {
			unset($this->session->data['order_id']);
		}

		$errors_thrown_by_oc = ob_get_contents();
		if (strlen($errors_thrown_by_oc)) {
			Logger::setDescription("Confirm error thrown by OpenCart")->alert([$errors_thrown_by_oc]);
			ob_clean();
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
