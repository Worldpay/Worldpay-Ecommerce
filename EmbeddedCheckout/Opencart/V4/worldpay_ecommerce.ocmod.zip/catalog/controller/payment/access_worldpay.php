<?php

namespace Opencart\Catalog\Controller\Extension\WorldpayEcommerce\Payment;

abstract class AccessWorldpay extends \Opencart\System\Engine\Controller {

	protected $payment_method = '';

	public function index() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		$data['language'] = $this->config->get('config_language');
		$data['payment_method'] = $this->payment_method;

		return $data;
	}

	/**
	 * @throws \Exception
	 *
	 * @return void
	 */
	abstract public function confirm(): void;

	/**
	 * @return array
	 */
	protected function validateOrder(): array {
		$json = [];

		if (!isset($this->session->data['order_id'])) {
			$json['error'][] = $this->language->get('error_order');
		}

		if (!isset($this->session->data['payment_method']) || $this->session->data['payment_method']['code'] != $this->payment_method . '.' . $this->payment_method) {
			$json['error'][] = $this->language->get('error_payment_method');
		}

		return $json;
	}

	/**
	 * @return void
	 */
	protected function redirectToNotFound(): void {
		$this->response->redirect($this->url->link('error/not_found', 'language=' . $this->config->get('config_language')));
	}
}
