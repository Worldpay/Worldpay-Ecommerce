<?php

include_once 'access_worldpay.php';

$_['heading_title'] = 'Pay with Card (Worldpay)';
$_['placeholder_card_holder_name'] = 'Card Holder Name';

$_['text_test_mode'] = 'Test Mode';
$_['text_not_live_transaction'] = 'This is not a live transaction.';
$_['text_card_number'] = 'Card Number';
$_['text_expiry_date'] = 'Expiry Date (MM/YY)';
$_['text_card_cvc'] = 'Card Code (CVC)';

$_['failed_payment'] = 'Payment failed. Please try again.';
$_['error_payment'] = 'Something went wrong while processing your payment. Please try again later.';
$_['error_payment_session'] = 'Payment session not found.';
$_['error_card_holder_name'] = 'Card holder name is empty.';
$_['failed_payment_note'] = 'Payment failed via Worldpay';

