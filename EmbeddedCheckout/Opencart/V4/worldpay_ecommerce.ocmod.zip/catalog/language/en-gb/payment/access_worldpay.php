<?php

// Error
$_['error_order_id']        = 'No order ID in the session!';
$_['error_order']           = 'Warning: Order could not be found!';
$_['error_payment_method']  = 'Payment method is incorrect!';
$_['error_request']  = 'Wrong request type.';

// Payment
$_['payment_success_via_worldpay'] = 'Payment successful via Worldpay. Transaction reference ';
$_['payment_failed_via_worldpay']  = 'Payment failed via Worldpay. Transaction reference ';
