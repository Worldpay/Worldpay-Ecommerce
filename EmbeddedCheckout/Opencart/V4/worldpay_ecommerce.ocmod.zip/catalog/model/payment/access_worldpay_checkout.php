<?php

namespace Opencart\Catalog\Model\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;
use Worldpay\Api\Enums\PaymentStatus;

class AccessWorldpayCheckout extends AccessWorldpay {

	/**
	 * @var string
	 */
	protected $payment_method = AccessWorldpayPaymentMethods::CHECKOUT;

	/**
	 * Update transaction status.
	 *
	 * @param  string  $transaction_reference
	 * @param  string  $order_status
	 * @param  string  $payment_status
	 *
	 * @return void
	 */
	public function updateTransactionStatus(string $transaction_reference, string $order_status, string $payment_status, array $link_data = []): void {
		$query = "UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET";
		if (in_array($payment_status, [PaymentStatus::AUTHORIZED, PaymentStatus::SENT_FOR_SETTLEMENT])) {
			$query .= " `finalized` = 1, ";
		}
		if (!empty($link_data)) {
			$query .= " `link_data` = '".$this->db->escape($link_data['link_data'])."', `env_mode` = '".$this->db->escape($link_data['payment_env'])."', ";
		}
		$query .= "`order_status` = '".$this->db->escape($order_status)."', `payment_status` = '".$this->db->escape($payment_status)."' WHERE `reference` = '".$this->db->escape($transaction_reference)."';";
		$this->db->query($query);
	}

	/**
	 * Save initial payment data in the transactions table.
	 *
	 * @param  array   $order_data
	 * @param  string  $reference
	 * @param  string  $payment_status
	 *
	 * @return void
	 */
	public function saveTransactionInitialDetails(array $order_data, string $reference, string $payment_status) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . $this->payment_method . "_transactions` SET `order_id` = '" . (int)$order_data["order_id"] . "', `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `payment_status` = '" . $this->db->escape($payment_status) . "', `created_at` = NOW();");
	}

	/**
	 * Update 3DS device data url used for submit device data collection request.
	 *
	 * @param  string  $transaction_reference
	 * @param  string  $url
	 *
	 * @return void
	 */
	public function set3DSDeviceDataUrl(string $transaction_reference, string $url) {
		$this->db->query("UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET `supply_3ds_device_data_url` = '" . $this->db->escape($url) . "' WHERE `reference` = '" . $this->db->escape($transaction_reference) . "';");
	}

	/**
	 * Get 3DS device data url by transaction reference.
	 *
	 * @param  string  $transaction_reference
	 *
	 * @return string
	 */
	public function get3DSDeviceDataUrlByTransactionReference(string $transaction_reference) {
		if ($transaction_reference) {
			$query = $this->db->query( "SELECT `supply_3ds_device_data_url` FROM `" . DB_PREFIX . $this->payment_method . "_transactions` WHERE `reference` = '" . $this->db->escape( $transaction_reference ) . "';" );

			return $query->row;
		}

		return '';
	}

	/**
	 * Update complete 3DS challenge url for submit 3ds challenge result request.
	 *
	 * @param  string  $transaction_reference
	 * @param  string  $url
	 *
	 * @return void
	 */
	public function set3DSCompleteChallengeUrl(string $transaction_reference, string $url) {
		$this->db->query("UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET `complete_3ds_challenge_url` = '" . $this->db->escape($url) . "' WHERE `reference` = '" . $this->db->escape($transaction_reference) . "';");
	}

	/**
	 * Get complete 3DS challenge url by transaction reference.
	 *
	 * @param  string  $transaction_reference
	 *
	 * @return string
	 */
	public function get3DSCompleteChallengeByTransactionReference(string $transaction_reference) {
		if ($transaction_reference) {
			$query = $this->db->query("SELECT `complete_3ds_challenge_url` FROM `" . DB_PREFIX . $this->payment_method . "_transactions` WHERE `reference` = '" . $this->db->escape( $transaction_reference ) . "';");

			return $query->row;
		}

		return '';
	}

	/**
	 * Get transaction amount by transaction reference.
	 *
	 * @param string $transaction_reference
	 *
	 * @return string
	 */
	public function getTransactionAmountByReference(string $transaction_reference) {
		if ($transaction_reference) {
			$query = $this->db->query( "SELECT `amount` FROM `" . DB_PREFIX . $this->payment_method . "_transactions` WHERE `reference` = '" . $this->db->escape( $transaction_reference ) . "';" );

			return ( $query->row )['amount'];
		}

		return '';
	}
}
