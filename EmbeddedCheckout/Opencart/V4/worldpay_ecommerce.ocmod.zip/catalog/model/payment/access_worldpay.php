<?php

namespace Opencart\Catalog\Model\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;

class AccessWorldpay extends \Opencart\System\Engine\Model {
	protected $payment_method = '';

	/**
	 * getMethods
	 *
	 * @param mixed $address
	 *
	 * @return array
	 */
	public function getMethods(array $address = []): array {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		$totals = [];
		$taxes = $this->cart->getTaxes();
		$total = 0;

		$this->load->model('checkout/cart');
		($this->model_checkout_cart->getTotals)($totals, $taxes, $total);
		$total_data = [
			'totals' => $totals,
			'taxes'  => $taxes,
			'total'  => $total
		];

		$status = true;
		if ($total_data['total'] < 0) {
			$status = false;
		} elseif ($this->cart->hasSubscription()) {
			$status = false;
		}

		$method_data = [];

		if ($status) {
			$option_data[$this->payment_method] = [
				'code' => $this->payment_method . '.' . $this->payment_method,
				'name' => $this->language->get('heading_title')
			];

			$method_data = [
				'code'       => $this->payment_method,
				'name'       => $this->language->get('heading_title'),
				'option'     => $option_data,
				'sort_order' => $this->config->get('payment_' . $this->payment_method . '_sort_order')
			];
		}

		return $method_data;
	}

	/**
	 * @param int    $id
	 * @param string $status
	 *
	 * @return bool
	 */
	public function changeTransactionStatus(int $id, string $status): bool {
		if (!in_array($status, [WorldpayService::TRANSACTION_STATUS_SUCCESS, WorldpayService::TRANSACTION_STATUS_FAILED])) {
			return false;
		}
		$finalized = (int)($status === WorldpayService::TRANSACTION_STATUS_SUCCESS ? true : false);

		$query = $this->db->query("UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET `finalized` = " . $finalized . ", `order_status` = '" . $status . "' WHERE `id` = " . $id . ";");

		return true;
	}

	/**
	 * Set order shipping method if empty.
	 *
	 * @param  int  $order_id
	 * @param  string  $shipping_method
	 *
	 * @return void
	 */
	public function setOrderShippingMethod(int $order_id, string $shipping_method) {
		$this->db->query("UPDATE `". DB_PREFIX . "order` SET `shipping_method` = '" . $this->db->escape($shipping_method) . "' WHERE `order_id` = " . $order_id . ";");
	}
}
