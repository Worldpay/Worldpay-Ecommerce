<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library\Admin;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\Logger;
use Opencart\Extension\WorldpayEcommerce\System\Library\StringUtils;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceHpp;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Services\Validators\BaseValidator;
use Worldpay\Api\Utils\Helper;

class AccessWorldpayController extends \Opencart\System\Engine\Controller {

	/**
	 * @var string
	 */
	protected $payment_method = "";

	/**
	 * @return void
	 */
	public function index(): void {

		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = [
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method, 'user_token=' . $this->session->data['user_token'])
			];
		} else {
			$data['breadcrumbs'][] = [
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method, 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'])
			];
		}

		$data['save'] = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		$data['testCredentials'] = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.testApiCredentialsRequest', 'user_token=' . $this->session->data['user_token']);

		$data = array_merge($data, $this->getSettingFields());

		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$compatibility_errors = $this->{$model}->checkCompatibility();
		$data['isCompatible'] = empty($compatibility_errors);
		$data['compatibilityErrors'] = $compatibility_errors;

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');

		$data['payment_method'] = $this->payment_method;

		$this->response->setOutput($this->load->view('extension/worldpay_ecommerce/payment/' . $this->payment_method, $data));
	}

	/**
	 * save method
	 *
	 * @return void
	 */
	public function save(): void {
		Logger::config($this->config, $this->payment_method);
		Logger::logPlatformVersion();

		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		$json = [];

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'][] = $this->language->get('error_invalid_request');
		}

		if (!$this->user->hasPermission('modify', 'extension/worldpay_ecommerce/payment/' . $this->payment_method)) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$post_request = $this->request->post;
			$errors = $this->validate($post_request);
			if (!empty($errors)) {
				$json['error'] = array_merge($json, $errors);
			}
		}

		if (!$json) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting('payment_' . $this->payment_method, $post_request);

			if ($this->testApiCredentials($post_request)) {
				$json['success'] = $this->language->get('success_test_save_credentials');
				$json['payment_' . $this->payment_method . '_app_merchant_entity'] = StringUtils::maskStringPartially($post_request['payment_' . $this->payment_method . '_app_merchant_entity']);
				$json['payment_' . $this->payment_method . '_app_try_password'] = StringUtils::maskStringTotally($post_request['payment_' . $this->payment_method . '_app_try_password']);
				$json['payment_' . $this->payment_method . '_app_live_password'] = StringUtils::maskStringTotally($post_request['payment_' . $this->payment_method . '_app_live_password']);
			} else {
				$json['error']['warning'] = $this->language->get('error_test_save_credentials');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param array $post_request
	 *
	 * @return bool
	 */
	protected function testApiCredentials($post_request = []): bool {
		Logger::config($this->config, $this->payment_method);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));

		try {
			if (!empty($post_request)) {
				$api_config_provider                    = AccessWorldpayConfigProvider::instance();
				if ($post_request['payment_' . $this->payment_method . '_app_mode'] == 'live') {
					$api_config_provider->environment = Environment::LIVE_MODE;
					$api_config_provider->username = $post_request['payment_' . $this->payment_method . '_app_live_username'];
					$api_config_provider->password = $post_request['payment_' . $this->payment_method . '_app_live_password'];
					if ($this->payment_method == AccessWorldpayPaymentMethods::CHECKOUT) {
						$api_config_provider->checkoutId = $post_request['payment_' . $this->payment_method . '_app_merchant_live_checkout_id'];
					}
				} else {
					$api_config_provider->environment = Environment::TRY_MODE;
					$api_config_provider->username = $post_request['payment_' . $this->payment_method . '_app_try_username'];
					$api_config_provider->password = $post_request['payment_' . $this->payment_method . '_app_try_password'];
					if ($this->payment_method == AccessWorldpayPaymentMethods::CHECKOUT) {
						$api_config_provider->checkoutId = $post_request['payment_' . $this->payment_method . '_app_merchant_try_checkout_id'];
					}
				}
				$api_config_provider->merchantEntity    = $post_request['payment_' . $this->payment_method . '_app_merchant_entity'];
				$api_config_provider->merchantNarrative = 'Test API Credentials';

				$this->registry->set('api_config_provider', $api_config_provider);
			}

			if ($this->payment_method == AccessWorldpayPaymentMethods::HPP) {
				$worldpay = new WorldpayEcommerceHpp($this->worldpay_service);
			}
			if ($this->payment_method == AccessWorldpayPaymentMethods::CHECKOUT) {
				$worldpay = new WorldpayEcommerceCheckout($this->worldpay_service);
			}

			$api_response = $worldpay->testApiCredentials();

			return (bool)($api_response->isSuccessful());
		} catch (\Exception $e) {
			Logger::setDescription("Retrieve Hpp url - HPP API Response")->debug($e->getMessage());

			return false;
		}
	}

	/**
	 * @return void
	 */
	public function testApiCredentialsRequest(): void {
		$json = [];

		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_invalid_request');
		}

		if (!$json) {
			$post_to_forward = [
				'payment_' . $this->payment_method . '_app_mode'            => $this->request->post['app_mode'],
				'payment_' . $this->payment_method . '_app_merchant_entity' => $this->request->post['app_merchant_entity'],
			];
			$this->replaceMaskedMerchantEntity($post_to_forward);
			if ($this->request->post['app_mode'] == 'try') {
				$post_to_forward['payment_' . $this->payment_method . '_app_try_username'] = $this->request->post['app_username'];
				$post_to_forward['payment_' . $this->payment_method . '_app_try_password'] = $this->request->post['app_password'];
				$this->replaceMaskedApiTryPassword($post_to_forward);
				if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT) {
					$post_to_forward['payment_' . $this->payment_method . '_app_merchant_try_checkout_id'] = $this->request->post['app_merchant_checkout_id'];
				}
			} else {
				$post_to_forward['payment_' . $this->payment_method . '_app_live_username'] = $this->request->post['app_username'];
				$post_to_forward['payment_' . $this->payment_method . '_app_live_password'] = $this->request->post['app_password'];
				$this->replaceMaskedApiLivePassword($post_to_forward);
				if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT) {
					$post_to_forward['payment_' . $this->payment_method . '_app_merchant_live_checkout_id'] = $this->request->post['app_merchant_checkout_id'];
				}
			}

			if ($this->testApiCredentials($post_to_forward)) {
				$json['status'] = 'success';
			} else {
				$json['status'] = 'failed';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validate(array &$post_request): array {
		$validation_methods = [
			'validateApiTryUsername',
			'validateApiTryPassword',
			'validateApiLiveUsername',
			'validateApiLivePassword',
			'validateApiMerchantEntity',
			'validateApiMerchantNarrative',
			'validateApiDescription',
			'validateApiMerchantTryCheckoutId',
			'validateApiMerchantLiveCheckoutId',
			'validateApiCardBrands'
		];

		$errors = [];
		foreach ($validation_methods as $method) {
			$error = $this->{$method}($post_request);
			if (!empty($error)) {
				$errors = array_merge($errors, $error);
			}
		}

		return $errors;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiTryUsername(array $post_request): array {
		$error = [];
		if ($post_request['payment_' . $this->payment_method . '_app_mode'] === 'try'
			&& empty($post_request['payment_' . $this->payment_method . '_app_try_username'])) {
			$error['app-try-username'] = $this->language->get('error_try_username');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiTryPassword(array &$post_request): array {
		$error = [];
		$this->replaceMaskedApiTryPassword($post_request);
		if ($post_request['payment_' . $this->payment_method . '_app_mode'] === 'try'
			&& empty($post_request['payment_' . $this->payment_method . '_app_try_password'])) {
			$error['app-try-password'] = $this->language->get('error_try_password');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedApiTryPassword(array &$post_request): void {
		$configured_value = $this->config->get('payment_' . $this->payment_method . '_app_try_password');
		if (!empty($configured_value) && preg_match('/^[*]+$/', $post_request['payment_' . $this->payment_method . '_app_try_password'])
			&& $post_request['payment_' . $this->payment_method . '_app_try_password'] != $configured_value) {
			$post_request['payment_' . $this->payment_method . '_app_try_password'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiLiveUsername(array $post_request): array {
		$error = [];
		if ($post_request['payment_' . $this->payment_method . '_app_mode'] === 'live'
			&& empty($post_request['payment_' . $this->payment_method . '_app_live_username'])) {
			$error['app-live-username'] = $this->language->get('error_live_username');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiLivePassword(array &$post_request): array {
		$error = [];
		$this->replaceMaskedApiLivePassword($post_request);
		if ($post_request['payment_' . $this->payment_method . '_app_mode'] === 'live'
			&& empty($post_request['payment_' . $this->payment_method . '_app_live_password'])) {
			$error['app-live-password'] = $this->language->get('error_live_password');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedApiLivePassword(array &$post_request): void {
		$configured_value = $this->config->get('payment_' . $this->payment_method . '_app_live_password');
		if (!empty($configured_value) && preg_match('/^[*]+$/', $post_request['payment_' . $this->payment_method . '_app_live_password'])
			&& $post_request['payment_' . $this->payment_method . '_app_live_password'] != $configured_value) {
			$post_request['payment_' . $this->payment_method . '_app_live_password'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantEntity(array &$post_request): array {
		$error = [];
		$this->replaceMaskedMerchantEntity($post_request);
		if (empty($post_request['payment_' . $this->payment_method . '_app_merchant_entity'])
			|| strlen($post_request['payment_' . $this->payment_method . '_app_merchant_entity']) > 32) {
			$error['app-merchant-entity'] = $this->language->get('error_merchant_entity');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantTryCheckoutId(array &$post_request): array {
		$error = [];
		if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT
			&& $post_request['payment_' . $this->payment_method . '_app_mode'] === 'try'
			&& empty($post_request['payment_' . $this->payment_method . '_app_merchant_try_checkout_id'])) {
			$error['app-merchant-try-checkout-id'] = $this->language->get('error_try_checkout_id');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantLiveCheckoutId(array &$post_request): array {
		$error = [];
		if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT
			&& $post_request['payment_' . $this->payment_method . '_app_mode'] === 'live'
			&& empty($post_request['payment_' . $this->payment_method . '_app_merchant_live_checkout_id'])) {
			$error['app-merchant-live-checkout-id'] = $this->language->get('error_live_checkout_id');
		}

		return $error;
	}

	/**
	 * @param  array  $post_request
	 *
	 * @return array
	 */
	protected function validateApiCardBrands(array &$post_request): array {
		$error = [];
		if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT
		    && empty($post_request['payment_' . $this->payment_method . '_app_card_brands'])) {
			$error['error-app-card-brands'] = $this->language->get('error_app_card_brands');
		}
		if ($this->payment_method === AccessWorldpayPaymentMethods::CHECKOUT) {
			$post_request['payment_' . $this->payment_method . '_app_card_brands'] = serialize(
				$post_request['payment_' . $this->payment_method . '_app_card_brands']
			);
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedMerchantEntity(array &$post_request): void {
		$configured_value = $this->config->get('payment_' . $this->payment_method . '_app_merchant_entity');
		if (!empty($configured_value) && preg_match('/^\*+[^*]{4}$/', $post_request['payment_' . $this->payment_method . '_app_merchant_entity'])
			&& $post_request['payment_' . $this->payment_method . '_app_merchant_entity'] != $configured_value) {
			$post_request['payment_' . $this->payment_method . '_app_merchant_entity'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantNarrative(array $post_request): array {
		$error = [];

		// Check if the narrative is empty or exceeds 24 characters
		if (empty($post_request['payment_' . $this->payment_method . '_app_merchant_narrative'])
			|| !BaseValidator::hasValidLength($post_request['payment_' . $this->payment_method . '_app_merchant_narrative'], 1, 24)) {
			$error['app-merchant-narrative'] = $this->language->get('error_merchant_narrative');
		}

		// Check if the narrative contains invalid characters
		if (!BaseValidator::hasValidMerchantNarrative($post_request['payment_' . $this->payment_method . '_app_merchant_narrative'])) {
			$error['app-merchant-narrative-regex'] = $this->language->get('entry_merchant_narrative_help_valid');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiDescription(array &$post_request): array {
		$error = [];
		if ($this->payment_method === AccessWorldpayPaymentMethods::HPP
			&& !empty($post_request['payment_' . $this->payment_method . '_app_description'])
			&& strlen($post_request['payment_' . $this->payment_method . '_app_description']) > 128) {
			$error['app-description'] = $this->language->get('error_description');
		}

		return $error;
	}

	/**
	 * @return void
	 */
	public function order() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('localisation/currency');

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id'] = $this->request->get['order_id'];

		$model = "model_extension_worldpay_ecommerce_payment_" . $this->payment_method;
		$transactions = $this->{$model}->getAllTransactionsByOrderId($data['order_id']);
		if (!empty($transactions)) {
			foreach ($transactions as $key => $transaction) {
				$transactions[$key]['formatted_amount'] = $this->formatCurrencyAmount($transaction['amount'], $transaction['currency']);
			}

			$data['transactions'] = $transactions;
			$data['refunds'] = $this->refundsHistory();
		}

		$data['payment_method'] = $this->payment_method;

		return $this->load->view('extension/worldpay_ecommerce/payment/' . $this->payment_method . '_order', $data);
	}

	/**
	 * @return void
	 */
	public function history(): void {
		$this->response->setOutput($this->refundsHistory());
	}

	/**
	 * @return mixed
	 */
	public function refundsHistory() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		$this->load->model('localisation/currency');

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id'] = $this->request->get['order_id'] ?? 0;
		$data['refund_action'] = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.refund', ['user_token' => $data['user_token'], 'order_id' => $data['order_id']], true);

		$data['can_refund'] = false;

		$refunded_amount = 0;
		$model = "model_extension_worldpay_ecommerce_payment_" . $this->payment_method;
		$transaction = $this->{$model}->getFinalizedTransactionByOrderId((int)$data['order_id'], WorldpayService::TRANSACTION_STATUS_SUCCESS);
		if (!empty($transaction)) {
			$model = "model_extension_worldpay_ecommerce_payment_" . $this->payment_method;
			$refunds = $this->{$model}->getAllRefundsByOrderId((int)$data['order_id']);

			if (!empty($refunds)) {
				foreach ($refunds as $refund_key => $refund) {
					$refunded_amount += $refund['amount'];
					$refunds[$refund_key]['formatted_amount'] = $this->formatCurrencyAmount($refund['amount'], $refund['currency']);
				}
				$data['refunds'] = $refunds;
			}
			if (empty($refunded_amount) || ($refunded_amount < $transaction['amount'])) {
				$data['can_refund'] = true;
			}
			$transaction['refunded_amount'] = $refunded_amount;
			$transaction['available_amount'] = number_format((float)($transaction['amount'] - $refunded_amount), 2, '.', '');
			$transaction['formatted_amount'] = $this->formatCurrencyAmount($transaction['amount'], $transaction['currency']);
			$transaction['formatted_available_amount'] = $this->formatCurrencyAmount($transaction['available_amount'], $transaction['currency']);
			$transaction['currency_sign'] = $this->currency->getSymbolLeft($transaction['currency']) ?: $this->currency->getSymbolRight($transaction['currency']);

			$data['transaction'] = $transaction;
		}

		$data['payment_method'] = $this->payment_method;

		return $this->load->view('extension/worldpay_ecommerce/payment/' . $this->payment_method . '_order_refunds', $data);
	}

	/**
	 * @return void
	 * @throws \Exception
	 */
	public function refund(): void{
		Logger::config($this->config, $this->payment_method);
		$json = [];

		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_invalid_request');
		}

		$order_id = $this->request->post[$this->payment_method . '_full_refund_order_id'] ?? '';

		$refund_amount = $this->request->post[$this->payment_method . '_full_refund_amount'] ?? '0.00';
		$partial_refund_reference = Helper::generateString(12) . '-' . $order_id;
		$is_partial_refund = false;
		if (!empty($this->request->post[$this->payment_method . '_partial_refund_amount'])) {
			$partial_refund_amount = $this->request->post[$this->payment_method . '_partial_refund_amount'];
			if ((float)$partial_refund_amount > (float)$refund_amount) {
				$json['error'] = $this->language->get('error_partial_refund_amount_high');
			} elseif ((float)$partial_refund_amount == (float)$refund_amount) {
				$refund_amount = $partial_refund_amount;
			} else {
				$refund_amount = $partial_refund_amount;
			}
			$is_partial_refund = true;
		}

		$transaction_reference = $this->request->post[$this->payment_method . '_full_refund_reference'] ?? '';
		$refund_currency = $this->request->post[$this->payment_method . '_refund_currency'] ?? '';

		if (!$json) {
			try {
				$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
				$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;

				$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));

				$service = null;
				$link_data = '';
				switch ($this->payment_method) {
					case AccessWorldpayPaymentMethods::CHECKOUT:
						$service = new WorldpayEcommerceCheckout($this->worldpay_service);
						$link_data = $this->{$model}->getLinkDataByTransactionReference($transaction_reference);
						break;

					case AccessWorldpayPaymentMethods::HPP:
						$service = new WorldpayEcommerceHpp($this->worldpay_service);
						break;

					default:
						throw new \Exception('Payment method not implemented.');
				}

				$this->registry->set('worldpay_ecommerce', $service);

				$this->worldpay_ecommerce->refund($order_id, $refund_amount, $refund_currency,
					$transaction_reference, $partial_refund_reference, $is_partial_refund, $link_data);

				$this->{$model}->saveRefundDetails($order_id, $this->request->post[$this->payment_method . '_transaction_id'],
					$partial_refund_reference, $refund_amount, $refund_currency);

				$this->addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference);

				$json['success'] = $this->language->get('success_refund_processed');
			} catch (\Exception $e) {
				$data_to_log = [
					'message'               => $e->getMessage(),
					'order_id'              => $order_id,
					'refund_amount'         => $refund_amount,
					'transaction_reference' => $transaction_reference,
				];
				Logger::setDescription("Refund failed")->alert($data_to_log);
				$json['error'] = $this->language->get('error_refund_failed');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param $order_id
	 * @param $refund_amount
	 * @param $partial_refund_reference
	 *
	 * @return void
	 */
	protected function addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference): void {
		$this->load->model('sale/order');

		$order_data = $this->model_sale_order->getOrder($order_id);
		$order_note = $this->currency->format($refund_amount, $order_data['currency_code'], 1) . $this->language->get('entry_refund_history')
			. (!empty($partial_refund_reference) ? ($this->language->get('entry_partial_refund_history') . $partial_refund_reference) : (''));

		$post = [
			'order_status_id' => $order_data['order_status_id'],
			'comment'         => $order_note,
			'order_id'        => $order_id,
		];
		$this->request->post = $post;
		$this->request->get['store_id'] = $order_data['store_id'];
		$this->request->get['action'] = 'sale/order.addHistory';

		$this->load->controller('sale/order.call');
	}

	/**
	 * @return void
	 */
	public function install(): void {
		if ($this->user->hasPermission('modify', 'extension/payment')) {
			$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);

			$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
			$this->{$model}->install();
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		if ($this->user->hasPermission('modify', 'extension/payment')) {
			$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);

			$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
			$this->{$model}->uninstall();
		}
	}

	/**
	 * @return array
	 */
	protected function getSettingFields(): array {
		$output = [
			'payment_access_worldpay_status'                 => $this->config->get('payment_' . $this->payment_method . '_status'),
			'payment_access_worldpay_app_mode'               => $this->config->get('payment_' . $this->payment_method . '_app_mode'),
			'payment_access_worldpay_app_try_username'       => $this->config->get('payment_' . $this->payment_method . '_app_try_username'),
			'payment_access_worldpay_app_try_password'       => StringUtils::maskStringTotally($this->config->get('payment_' . $this->payment_method . '_app_try_password')),
			'payment_access_worldpay_app_live_username'      => $this->config->get('payment_' . $this->payment_method . '_app_live_username'),
			'payment_access_worldpay_app_live_password'      => StringUtils::maskStringTotally($this->config->get('payment_' . $this->payment_method . '_app_live_password')),
			'payment_access_worldpay_app_merchant_entity'    => StringUtils::maskStringPartially($this->config->get('payment_' . $this->payment_method . '_app_merchant_entity')),
			'payment_access_worldpay_app_merchant_narrative' => $this->config->get('payment_' . $this->payment_method . '_app_merchant_narrative'),
			'payment_access_worldpay_app_debug'              => $this->config->get('payment_' . $this->payment_method . '_app_debug'),
		];

		return $output;
	}

	/**
	 * @param $amount
	 * @param $currencyCode
	 *
	 * @return string
	 */
	private function formatCurrencyAmount($amount, $currencyCode) {
		$currency_symbol_left = $this->currency->getSymbolLeft($currencyCode);
		$currency_symbol_right = $this->currency->getSymbolRight($currencyCode);

		$currency_symbol = $currency_symbol_left ?: $currency_symbol_right;
		$formatted_amount = number_format((float)$amount, 2, '.', '');

		return $currency_symbol ? $currency_symbol . $formatted_amount : $formatted_amount;
	}
}
