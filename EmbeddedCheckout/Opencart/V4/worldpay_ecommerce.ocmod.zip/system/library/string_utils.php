<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library;

class StringUtils {
	/**
	 * @param $value
	 * @param $limit
	 * @param $end
	 *
	 * @return string
	 */
	public static function limit($value, $limit = 100, $end = '...'): string {
		if (mb_strwidth($value, 'UTF-8') <= $limit) {
			return $value;
		}

		return rtrim(mb_strimwidth($value, 0, $limit, '', 'UTF-8')) . $end;
	}

	/**
	 * @param $string
	 * @param $character
	 * @param $index
	 * @param $length
	 * @param $encoding
	 *
	 * @return string
	 */
	public static function mask($string, $character, $index, $length = null, $encoding = 'UTF-8'): string {
		if ($character === '') {
			return $string;
		}

		$segment = mb_substr($string, $index, $length, $encoding);

		if ($segment === '') {
			return $string;
		}

		$strlen      = mb_strlen($string, $encoding);
		$start_index = $index;

		if ($index < 0) {
			$start_index = $index < -$strlen ? 0 : $strlen + $index;
		}

		$start       = mb_substr($string, 0, $start_index, $encoding);
		$segment_len = mb_strlen($segment, $encoding);
		$end         = mb_substr($string, $start_index + $segment_len);

		return $start . str_repeat(mb_substr($character, 0, 1, $encoding), $segment_len) . $end;
	}

	/**
	 * @param $value
	 * @param $encoding
	 *
	 * @return false|int
	 */
	public static function length($value, $encoding = 'UTF-8'): bool|int {
		return mb_strlen($value, $encoding);
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public static function maskStringTotally($string) {
		return self::limit(self::mask($string, '*', 0, self::length($string)), 64, '');
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public static function maskStringPartially($string) {
		return self::mask($string, '*', 0, self::length($string) - 4);
	}
}
