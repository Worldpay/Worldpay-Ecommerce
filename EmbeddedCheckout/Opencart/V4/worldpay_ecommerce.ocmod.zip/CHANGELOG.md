# Worldpay eCommerce for OpenCart change log

### [v1.1.4] (10/07/2025)
* Fixed missing transactionReferences for 3DS DDC.

### [v1.1.3] (07/09/2025)
* Added User-Agent header to all requests
* All currency symbols are now displayed in the refund confirmation modal
* All transaction states are now displayed in the history tab
* Disabled settlement cancellation on AVS not matched
* Fix for wrong method return when attempting a payment with Onsite Checkout

### [v1.1.2] (06/16/2025)
* Added fallback refund keys

### [v1.1.1] (02/10/2025)
* Fixed bug with encoding/decoding merchant description field special characters

### [v1.1.0] (01/30/2025)
* Added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment.

### [v1.0.1] (07/19/2024)
* Added compatibility checks.
* Added iframe support.
* Added regex validation for merchant narrative.
* Added Description setting.
* Removed GBP checkout restriction.

### [v1.0.0] (03/01/2024)
* Initial release.
