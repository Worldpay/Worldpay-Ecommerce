<?php

// Load Composer's autoloader if you're using Composer
require_once __DIR__ . '/../vendor/autoload.php';

// Base directory resolution
$baseDir = realpath(__DIR__ . '/../../../../');

$context = getenv('OPENCART_TEST_CONTEXT') ?: 'admin';
// Load the appropriate OpenCart config based on the context
if (!defined('DIR_SYSTEM')) {
    if ($context === 'admin') {
        require_once $baseDir . '/admin/config.php';
    } else {
        require_once $baseDir . '/config.php';
    }
}

// Include OpenCart's startup file if necessary
require_once DIR_SYSTEM . 'startup.php';

// Include sdk autoloader
require_once __DIR__ . '/../vendor/worldpay/php-sdk/autoload.php';

// Set any additional constants or mock environment variables
putenv('APPLICATION_ENV=testing');

require_once __DIR__ . '/../worldpay_ecommerce_hpp.php';

$application_config = "admin";

define('VERSION', 'UT Version');

global $testEnv;
$testEnv = parse_ini_file(__DIR__.'/credentials.env');

function getOCRegistryConfig(string $configPath = '', $application_config = 'admin'){
// Registry
    $registry = new Registry();

    $config = new Config();
    $config->load('default'); // Load default configuration
    $registry->set('config', $config);

// Log
    $log = new Log($config->get('error_filename'));
    $registry->set('log', $log);

    date_default_timezone_set($config->get('date_timezone'));

    set_error_handler(function($code, $message, $file, $line) use($log, $config) {
        // error suppressed with @
        if (!(error_reporting() & $code)) {
            return false;
        }

        switch ($code) {
            case E_NOTICE:
            case E_USER_NOTICE:
                $error = 'Notice';
                break;
            case E_WARNING:
            case E_USER_WARNING:
                $error = 'Warning';
                break;
            case E_ERROR:
            case E_USER_ERROR:
                $error = 'Fatal Error';
                break;
            default:
                $error = 'Unknown';
                break;
        }

        if ($config->get('error_display')) {
            echo '<b>' . $error . '</b>: ' . $message . ' in <b>' . $file . '</b> on line <b>' . $line . '</b>';
        }

        if ($config->get('error_log')) {
            $log->write('PHP ' . $error . ':  ' . $message . ' in ' . $file . ' on line ' . $line);
        }

        return true;
    });

// Event
    $event = new Event($registry);
    $registry->set('event', $event);

// Event Register
    if ($config->has('action_event')) {
        foreach ($config->get('action_event') as $key => $value) {
            foreach ($value as $priority => $action) {
                $event->register($key, new Action($action), $priority);
            }
        }
    }

// Loader
    $loader = new Loader($registry);
    $registry->set('load', $loader);

// Request
    $request = new Request();
    $request->server["REMOTE_ADDR"] = '127.0.0.1';
    $registry->set('request', $request);

// Response
    $response = new Response();
    $response->addHeader('Content-Type: text/html; charset=utf-8');
    $response->setCompression($config->get('config_compression'));
    $registry->set('response', $response);

// Database
    if(empty($config->get('db_database'))){
        $config->set('db_database', DB_DATABASE);
    }
    $db = new DB($config->get('db_engine'), $config->get('db_hostname'), $config->get('db_username'), $config->get('db_password'), $config->get('db_database'), $config->get('db_port'));
    $registry->set('db', $db);

// Sync PHP and DB time zones
    $db->query("SET time_zone = '" . $db->escape(date('P')) . "'");

// Session
    $session = new Session($config->get('session_engine'), $registry);
    $registry->set('session', $session);

    if ($config->get('session_autostart')) {
        if (isset($_COOKIE[$config->get('session_name')])) {
            $session_id = $_COOKIE[$config->get('session_name')];
        } else {
            $session_id = '';
        }

        $session->start($session_id);

        setcookie($config->get('session_name'), $session->getId(), ini_get('session.cookie_lifetime'), ini_get('session.cookie_path'), ini_get('session.cookie_domain'));
    }

// Cache
    $registry->set('cache', new Cache($config->get('cache_engine'), $config->get('cache_expire')));

// Url
    if ($config->get('url_autostart')) {
        $registry->set('url', new Url($config->get('site_url'), $config->get('site_ssl')));
    }

// Language
    $language = new Language($config->get('language_directory'));
    $registry->set('language', $language);

// Document
    $registry->set('document', new Document());

// Config Autoload
    if ($config->has('config_autoload')) {
        foreach ($config->get('config_autoload') as $value) {
            $loader->config($value);
        }
    }

// Language Autoload
    if ($config->has('language_autoload')) {
        foreach ($config->get('language_autoload') as $value) {
            $loader->language($value);
        }
    }

// Library Autoload
    if ($config->has('library_autoload')) {
        foreach ($config->get('library_autoload') as $value) {
            $loader->library($value);
        }
    }

// Model Autoload
    if ($config->has('model_autoload')) {
        foreach ($config->get('model_autoload') as $value) {
            $loader->model($value);
        }
    }

// Route
    $route = new Router($registry);

// Pre Actions
    if ($config->has('action_pre_action')) {
        foreach ($config->get('action_pre_action') as $value) {
            $route->addPreAction(new Action($value));
        }
    }

    return $registry;
}