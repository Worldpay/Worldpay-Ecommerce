<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockdata;

class WorldpayHppRefundsMockData {

	public static $mockedRefunds = [
		[
			'id' => '1',
			'order_id' => '1',
			'transaction_id' => '1',
			'reference' => 'abc',
			'amount' => 22.00,
			'currency' => 'GBP',
			'created_at' => '2023-11-29T16:55:54.000000Z',
		],
		[
			'id' => '2',
			'order_id' => '2',
			'transaction_id' => '2',
			'reference' => 'def-ssadddada',
			'amount' => 124.54,
			'currency' => 'USD',
			'created_at' => '2024-02-27T16:55:54.000000Z',
		],
	];

	public static $mockedPostData = [
		'access_worldpay_hpp_full_refund_amount'    => '22.00',
		'access_worldpay_hpp_partial_refund_amount' => '10.00',
		'access_worldpay_hpp_full_refund_reference' => 'abcd',
		'access_worldpay_hpp_full_refund_order_id'  => '8',
		'access_worldpay_hpp_transaction_id'        => '1'
	];
}
