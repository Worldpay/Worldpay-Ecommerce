<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests;

use Opencart\Admin\Controller\Extension\WorldpayEcommerce\Payment\AccessWorldpayHpp;
use Opencart\Extension\WorldpayEcommerce\System\Library\StringUtils;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayOc;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;
use Opencart\Extension\WorldpayEcommerce\Tests\Mockdata\WorldpayHppRefundsMockData;
use Opencart\Extension\WorldpayEcommerce\Tests\Mockups\AccessWorldpayHppControllerMockUp;
use Opencart\Extension\WorldpayEcommerce\Tests\Mockups\AccessWorldpayHppMock;
use Opencart\System\Library\Request;
use Opencart\System\Library\Response;
use PHPUnit\Framework\TestCase;

require_once DIR_APPLICATION . 'controller/extension/payment/access_worldpay_hpp.php';
require_once __DIR__.'/../../worldpay_service.php';
require_once __DIR__.'/../../logger.php';
require_once __DIR__.'/../mockups/AccessWorldpayHppControllerMockUp.php';
require_once __DIR__.'/../mockups/WorldpayEcommerceMock.php';
require_once __DIR__.'/../mockdata/WorldpayHppRefundsMockData.php';

class AccessWorldpayHppTest extends TestCase {
	protected $registry;
	protected $session;

    protected $tryUsername;
    protected $tryPassword;
    protected $merchantEntity;

	protected function setUp(): void {
		parent::setUp();

		putenv('OPENCART_TEST_CONTEXT=admin');
		$baseDir = realpath(__DIR__ . '/../../../../');

		$this->registry = getOCRegistryConfig($baseDir . '/admin/config.php', 'admin');
		$this->session = $this->registry->get('session');

		$this->registry->set('currency', new \Cart\Currency($this->registry));

		global $testEnv;
		$this->tryUsername = $testEnv['HPP_TRY_USERNAME'];
		$this->tryPassword = $testEnv['HPP_TRY_PASSWORD'];
		$this->merchantEntity = $testEnv['HPP_MERCHANT_ENTITY'];

		$this->session = $this->registry->get('session');
		$this->session->data['user_id'] = 1;
		$this->session->data['user_token'] = 'abcd';
		$this->session->data['username'] = 'Admin';
		$this->registry->set('session', $this->session);

		if ( ! $this->registry->has( 'request' ) ) {
			$this->registry->set( 'request', new \Request() );
		}
	}

	public function testIndexMethod(): void {
        $this->registry->set('user', new \Cart\User($this->registry));
		$this->registry->get('request')->get['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.index';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->index();
		$output = $this->registry->get('response')->getOutput();
		static::assertNotEmpty($output);
	}

	public function testSaveMethod(): void {
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.save';
		require_once __DIR__.'/../mockups/UserMockup.php';
		$this->registry->set('user', new \UserMockup($this->registry));
		// Test case - request is get
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'GET';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->save();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString($controller->language->get('error_invalid_request'), $output);

		// Test case - user hasn't any permissions
		$this->registry->get('user')->hasPermissionBool = false;
		$this->registry->set('request', new \Request());
		$this->registry->get('request')->server["REMOTE_ADDR"] = '127.0.0.1';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get('request')->post = [
			'payment_access_worldpay_hpp_app_mode'               => 'try',
			'payment_access_worldpay_hpp_app_try_username'       => $this->tryUsername,
			'payment_access_worldpay_hpp_app_try_password'       => $this->tryPassword,
			'payment_access_worldpay_hpp_app_live_username'       => '',
			'payment_access_worldpay_hpp_app_live_password'       => '',
			'payment_access_worldpay_hpp_app_merchant_entity'    => $this->merchantEntity,
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'test'
		];
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->save();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString($controller->language->get('error_permission'), $output);
	}

	public function testOrderMethod() {
		$this->registry->set('url', new \Url('localhost'));
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->load->model( 'extension/payment/access_worldpay_hpp' );
		$controller->load->model( 'localisation/currency' );

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id']   = $this->registry->get( 'request' )->get['order_id'] = '10';
		$data['save']       = $this->registry->get('url')->link( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp.refund', 'user_token=' . $data['user_token'], true );

		$transaction  = $controller->model_extension_payment_access_worldpay_hpp->getFinalizedTransactionByOrderId( $data['order_id'] );
		$transactions = $controller->model_extension_payment_access_worldpay_hpp->getAllTransactionsByOrderId( $data['order_id'] );

		$data['transaction'] = $transaction;
		$data['transactions'] = $transactions;
		$controller->load->view( 'extension/payment/access_worldpay_order', $data );

		$output = $controller->order();
		$this->assertStringContainsString( 'transaction_details', $output );
	}

	public function testHistoryMethod() {
		/* Test case - transaction found with no refunds */
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->load->model( 'extension/payment/access_worldpay_hpp' );
		$controller->load->model( 'localisation/currency' );

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id']   = $this->registry->get( 'request' )->get['order_id'] = '10';
		$data['refund_action'] = $this->registry->get('url')->link('extension/worldpay_ecommerce/payment/access_worldpay_hpp.refund', ['user_token' => $data['user_token'], 'order_id'=>$data['order_id']], true);

		$transaction = $controller->model_extension_payment_access_worldpay_hpp->getFinalizedTransactionByOrderId($data['order_id'], \WorldpayService::TRANSACTION_STATUS_SUCCESS);
		if (!empty($transaction)) {
			$data['transaction'] = $transaction;
		}

		$controller->load->view('extension/payment/access_worldpay_order_refunds', $data);

		$controller->history();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( 'refunds_details', $output );

		/* Test case - transaction not found with refunds */
		$this->registry->set( 'request', new \Request() );
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->load->model( 'extension/payment/access_worldpay_hpp' );
		$controller->load->model( 'localisation/currency' );

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id']   = $this->registry->get( 'request' )->get['order_id'] = '10';
		$data['refund_action'] = $this->registry->get('url')->link('extension/worldpay_ecommerce/payment/access_worldpay_hpp.refund', ['user_token' => $data['user_token'], 'order_id'=>$data['order_id']], true);

		$transaction = $controller->model_extension_payment_access_worldpay_hpp->getFinalizedTransactionByOrderId($data['order_id'], \WorldpayService::TRANSACTION_STATUS_SUCCESS);
		if (!empty($transaction)) {
			$refunds = WorldpayHppRefundsMockData::$mockedRefunds;
			if(!empty($refunds)) {
				$data['refunds'] = $refunds;
			}

			$data['transaction'] = $transaction;
		}

		$controller->load->view('extension/payment/access_worldpay_order_refunds', $data);

		$controller->history();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( 'refunds_details', $output );
//		$this->registry->unset( 'request' );
	}


	public function testRefundMethod() {
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_username', $this->tryUsername);
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_password', $this->tryPassword);
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_entity', $this->merchantEntity);
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_narrative', "narrative");

		/* Test case - invalid request type */
		$this->registry->get( 'request' )->server['REQUEST_METHOD'] = 'GET';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->refund();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( $controller->language->get( 'error_invalid_request' ), $output );

		/* Test case - valid request type but missing body */
		$this->registry->set( 'request', new \Request() );
		$this->registry->get( 'request' )->server['REQUEST_METHOD'] = 'POST';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->refund();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( $controller->language->get( 'error_refund_failed' ), $output );

		/* Test case - invalid request with partial amount higher than the full amount  */
		$this->registry->set( 'request', new \Request() );
		$this->registry->get( 'request' )->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get( 'request' )->post = [
			'access_worldpay_hpp_full_refund_amount'    => '22.00',
			'access_worldpay_hpp_partial_refund_amount' => '23.00',
			'access_worldpay_hpp_full_refund_reference' => 'abcd',
			'access_worldpay_hpp_full_refund_order_id'  => '8'
		];
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->refund();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( $controller->language->get( 'error_partial_refund_amount_high' ), $output );

		/* Test case - invalid request with wrong transaction reference  */
		$this->registry->set( 'request', new \Request() );
		$this->registry->get( 'request' )->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get( 'request' )->post = [
			'access_worldpay_hpp_full_refund_amount'    => '22.00',
			'access_worldpay_hpp_partial_refund_amount' => '10.00',
			'access_worldpay_hpp_full_refund_reference' => 'abcd',
			'access_worldpay_hpp_full_refund_order_id'  => '8'
		];
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->refund();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( $controller->language->get( 'error_refund_failed' ), $output );

		/* Test case - invalid status code  */
		$this->setupRequestData(WorldpayHppRefundsMockData::$mockedPostData, '10');

		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		$this->expectExceptionMessage('Something went wrong while requesting payment refund.');
		$controller->refundWrongStatusCode(200);

		/* Test case - valid status code  */
		$this->setupRequestData(WorldpayHppRefundsMockData::$mockedPostData, '10');

		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		$controller->load->language( 'extension/worldpay_ecommerce/payment/access_worldpay_hpp' );
		$controller->refund();
		$output = $this->registry->get( 'response' )->getOutput();
		$this->assertStringContainsString( $controller->language->get( 'success_refund_processed' ), $output );
	}

	public function testApiCredentialsMethod(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'               => 'try',
			'payment_access_worldpay_hpp_app_try_username'       => $this->tryUsername,
			'payment_access_worldpay_hpp_app_try_password'       => $this->tryPassword,
			'payment_access_worldpay_hpp_app_merchant_entity'    => $this->merchantEntity,
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'test',
			'payment_access_worldpay_hpp_app_live_username'      => '',
			'payment_access_worldpay_hpp_app_live_password'      => ''
		];
		static::assertTrue($mockUpController->testApiCredentials($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [];
		static::assertTrue($mockUpController->testApiCredentials($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'               => 'live',
			'payment_access_worldpay_hpp_app_try_username'       => $this->tryUsername,
			'payment_access_worldpay_hpp_app_try_password'       => $this->tryPassword,
			'payment_access_worldpay_hpp_app_merchant_entity'    => $this->merchantEntity,
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'test',
			'payment_access_worldpay_hpp_app_live_username'      => 'r2t2f2f2f2452',
			'payment_access_worldpay_hpp_app_live_password'      => 'fsfw3r34ferye'
		];
		static::assertFalse($mockUpController->testApiCredentials($postRequest));
	}

	public function testValidateMethod(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'               => 'try',
			'payment_access_worldpay_hpp_app_try_username'       => $this->tryUsername,
			'payment_access_worldpay_hpp_app_try_password'       => $this->tryPassword,
			'payment_access_worldpay_hpp_app_merchant_entity'    => $this->merchantEntity,
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'test',
			'payment_access_worldpay_hpp_app_live_username'      => '',
			'payment_access_worldpay_hpp_app_live_password'      => ''
		];
		static::assertSame([], $mockUpController->validate($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'               => 'live',
			'payment_access_worldpay_hpp_app_try_username'       => '12',
			'payment_access_worldpay_hpp_app_try_password'       => '34',
			'payment_access_worldpay_hpp_app_merchant_entity'    => '56',
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'test',
			'payment_access_worldpay_hpp_app_live_username'      => '',
			'payment_access_worldpay_hpp_app_live_password'      => ''
		];
		static::assertNotEmpty($mockUpController->validate($postRequest));
	}

	public function testValidateApiTryUsername(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_username' => '8755454'
		];
		static::assertSame([], $mockUpController->validateApiTryUsername($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_username' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('error_try_username'), $mockUpController->validateApiTryUsername($postRequest));
	}

	public function testValidateApiTryPassword(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => '8755454'
		];
		static::assertSame([], $mockUpController->validateApiTryPassword($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('error_try_password'), $mockUpController->validateApiTryPassword($postRequest));
	}

	public function testyReplaceMaskedApiTryPassword(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => '8755454'
		];
		$mockUpController->replaceMaskedApiTryPassword($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => '8755454'
		]);

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => '********************'
		];
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_password', 'wewfhuf94h9343hg');
		$mockUpController->replaceMaskedApiTryPassword($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_mode'         => 'try',
			'payment_access_worldpay_hpp_app_try_password' => $this->registry->get('config')->get('payment_access_worldpay_hpp_app_try_password'),
		]);
	}

	public function testValidateApiLiveUsername(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_username' => '8755454'
		];
		static::assertSame([], $mockUpController->validateApiLiveUsername($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_username' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('error_live_username'), $mockUpController->validateApiLiveUsername($postRequest));
	}

	public function testValidateApiLivePassword(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => '8755454'
		];
		static::assertSame([], $mockUpController->validateApiLivePassword($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('error_live_password'), $mockUpController->validateApiLivePassword($postRequest));
	}

	public function testReplaceMaskedApiLivePassword(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => '8755454'
		];
		$mockUpController->replaceMaskedApiLivePassword($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => '8755454'
		]);

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => '********************'
		];
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_live_password','8755454');
		$mockUpController->replaceMaskedApiLivePassword($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_mode'          => 'live',
			'payment_access_worldpay_hpp_app_live_password' => $this->registry->get('config')->get('payment_access_worldpay_hpp_app_live_password'),
		]);
	}

	public function testValidateApiMerchantEntity(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_entity' => 'PO8755454'
		];
		static::assertSame([], $mockUpController->validateApiMerchantEntity($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_entity' => 'PO875545478454554845484854848488484548454845454545454548784515484518451545154515451548154'
		];
		static::assertNotEmpty($mockUpController->validateApiMerchantEntity($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_entity' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('error_merchant_entity'), $mockUpController->validateApiMerchantEntity($postRequest));
	}

	public function testReplaceMaskedApiMerchantEntity(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_entity' => '8755454'
		];
		$mockUpController->replaceMaskedMerchantEntity($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_merchant_entity' => '8755454'
		]);

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_entity' => '***************4589'
		];

		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_entity', '4589458945894589');
		$mockUpController->replaceMaskedMerchantEntity($postRequest);
		static::assertSame($postRequest, [
			'payment_access_worldpay_hpp_app_merchant_entity' => '4589458945894589',
		]);
	}

	public function testValidateApiMerchantNarrative(): void {
		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'PO8755454'
		];
		static::assertSame([], $mockUpController->validateApiMerchantNarrative($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'PO875545478454554845484854848488484548454845454545454548784515484518451545154515451548154'
		];
		static::assertNotEmpty($mockUpController->validateApiMerchantNarrative($postRequest));

		$mockUpController = new AccessWorldpayHppControllerMockUp($this->registry);
		$postRequest = [
			'payment_access_worldpay_hpp_app_merchant_narrative' => ''
		];
		$mockUpController->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		static::assertContains($mockUpController->language->get('entry_merchant_narrative_help'), $mockUpController->validateApiMerchantNarrative($postRequest));
	}

	public function testApiCredentialsRequestMethod(): void {
		$this->registry->set('request', new \Request());
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.testApiCredentialsRequest';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get('request')->server['REMOTE_ADDR'] = '127.0.0.1';
		$this->registry->get('request')->post = [
			'app_mode'            => 'live',
			'app_username'        => '69865451545',
			'app_password'        => '4894656854654651564',
			'app_merchant_entity' => '89751865265'
		];
		$this->registry->set('user', new \Cart\User($this->registry));
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->testApiCredentialsRequest();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString('failed', $output);


		$this->registry->set('request', new \Request());
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.testApiCredentialsRequest';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'GET';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->testApiCredentialsRequest();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString($controller->language->get('error_invalid_request'), $output);

		$this->registry->set('request', new \Request());
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.testApiCredentialsRequest';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get('request')->server['REMOTE_ADDR'] = '127.0.0.1';
		$this->registry->get('request')->post = [
			'app_mode'            => 'try',
			'app_username'        => $this->tryUsername,
			'app_password'        => $this->tryPassword,
			'app_merchant_entity' => $this->merchantEntity
		];
		$this->registry->set('user', new \Cart\User($this->registry));
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->testApiCredentialsRequest();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString('success', $output);
	}

	public function testMaskCredentialsRequestMethod(): void {
		$this->registry->set('request', new \Request());
		$post = [
			'payment_access_worldpay_hpp_app_mode'              => 'try',
			'payment_access_worldpay_hpp_app_try_username'      => 'dfgdfg',
			'payment_access_worldpay_hpp_app_try_password'      => '785285285',
			'payment_access_worldpay_hpp_app_live_password'     => '7855875225',
			'payment_access_worldpay_hpp_app_merchant_entity'   => 'entity',
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'fgdfg1234'
		];
		$this->registry->get('request')->post = $post;
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.maskCredentialsRequest';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'GET';
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');
		$controller->maskCredentialsRequest();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString($controller->language->get('error_invalid_request'), $output);

		$this->registry->set('request', new \Request());
		$this->registry->get('request')->post['route'] = 'worldpay_ecommerce/admin/controller/payment/access_worldpay_hpp.testApiCredentialsRequest';
		$this->registry->get('request')->server['REQUEST_METHOD'] = 'POST';
		$this->registry->get('request')->server['REMOTE_ADDR'] = '127.0.0.1';
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_password', '785285285');
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_password', '7855875225');
		$this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_entity', '1235877455');
		$post = [
			'app_try_password'    => '785285285',
			'app_live_password'   => '7855875225',
			'app_merchant_entity' => '1235877455',
			'payment_access_worldpay_hpp_app_try_password'    => '785285285',
			'payment_access_worldpay_hpp_app_merchant_narrative' => 'fgdfg1234',
			'payment_access_worldpay_hpp_app_merchant_entity' => '1235877455'
		];
		$this->registry->get('request')->post = $post;
		$this->registry->set('user', new \Cart\User($this->registry));
		$controller = new \ControllerExtensionPaymentAccessWorldpayHpp($this->registry);
		$controller->maskCredentialsRequest();
		$output = $this->registry->get('response')->getOutput();
		static::assertStringContainsString(\StringUtils::maskStringTotally($post['app_try_password']), $output);
		static::assertStringContainsString(\StringUtils::maskStringTotally($post['app_live_password']), $output);
		static::assertStringContainsString(\StringUtils::maskStringPartially($post['app_merchant_entity']), $output);
	}

	public function testGetSettingFields()
	{
		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		$result = $controller->getSettingFields();

		$this->assertArrayHasKey('payment_access_worldpay_status', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_mode', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_try_username', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_try_password', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_live_username', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_live_password', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_merchant_entity', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_merchant_narrative', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_debug', $result);
		$this->assertArrayHasKey('payment_access_worldpay_app_merchant_description', $result);
		$this->assertArrayHasKey('payment_access_worldpay_checkout_mode', $result);
	}

	public function testAddOrderHistory()
	{
		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		require_once __DIR__.'/../mockups/UserMockup.php';
		$this->registry->get('config')->set('config_api_id', 1);
		$controller->user = new \UserMockup($this->registry);
		$response = $controller->addOrderHistory(1,[],1 );

		$this->assertEquals('{"success":"Success: You have modified orders!"}', $response);
	}

	public function testFormatCurrencyAmount()
	{
		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		$response = $controller->formatCurrencyAmount(1,'USD' );

		$this->assertEquals('$1.00', $response);
	}

	public function testAddRefundHistoryToOrder()
	{
		$controller = new AccessWorldpayHppControllerMockUp( $this->registry );
		$controller->addRefundHistoryToOrder(1,1, 'sdfsdgsdgsg' );
		$response = $controller->orderHistoryData;

		$this->assertArrayHasKey('order_id', $response);
		$this->assertArrayHasKey('data', $response);
		$this->assertArrayHasKey('store_id', $response);
	}

	protected function tearDown(): void {
		unset($this->session->data['user_id'], $this->session->data['user_token']);
		$this->registry->set('session', $this->session);

        $response = new \Response();
        $response->addHeader('Content-Type: text/html; charset=utf-8');
        $config = $this->registry->get('config');
        $response->setCompression($config->get('config_compression'));
        $this->registry->set('response', $response);

		parent::tearDown();
	}

	private function setupRequestData($postData = [], $orderId = null, $requestMethod = 'POST') {
		$this->registry->set('request', new \Request());
		$this->registry->get('request')->server['REQUEST_METHOD'] = $requestMethod;

		if (!empty($postData)) {
			$this->registry->get('request')->post = $postData;
		}

		if ($orderId !== null) {
			$this->registry->get('request')->get['order_id'] = $orderId;
		}
	}
}
