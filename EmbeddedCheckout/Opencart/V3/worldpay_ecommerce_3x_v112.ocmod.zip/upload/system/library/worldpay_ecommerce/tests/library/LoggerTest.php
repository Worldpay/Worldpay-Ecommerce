<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests;

use Opencart\Extension\WorldpayEcommerce\Tests\Mockups\LoggerMock;
use PHPUnit\Framework\TestCase;

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');

class LoggerTest extends TestCase  {

	protected function setUp(): void
	{
		parent::setUp();
	}

	public function testFormatLogRecord(){
		$data = [
			'testData' => [
				'testData' => 'test'
			]
		];
		$key = 'testKey';
		$parent_key = 'testData';
		$response = \Logger::formatLogRecord($data, $key, $parent_key);

		$this->assertEquals('testDataTestKey="Array"', $response);
	}

	public function testValidateJson() {
		require_once __DIR__.'/../mockups/LoggerMock.php';
		$data = 'sdfsadf';
		$result = LoggerMock::validateJson($data);
		$this->assertEquals(false, $result);

		$data = '{}';
		$result = LoggerMock::validateJson($data);
		$this->assertEquals(true, $result);
	}

	public function testDebug(){
		require_once __DIR__.'/../mockups/LoggerMock.php';

		$data = [
			'testData' => [
				'testData' => 'test'
			]
		];
		$response = LoggerMock::debug($data);

		$this->assertInstanceOf(\Logger::class, $response);
	}
}