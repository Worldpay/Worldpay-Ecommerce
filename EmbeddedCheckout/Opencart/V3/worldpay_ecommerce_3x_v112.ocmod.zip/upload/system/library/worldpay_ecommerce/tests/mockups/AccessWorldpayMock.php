<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Builders\Payments\RefundsBuilder;

class AccessWorldpayMock extends AccessWorldpay {
	public function refund(int $amount): RefundsBuilder {
		return (new RefundsBuilderMock($this->apiConfigProvider))->withAmount($amount);
	}
}
