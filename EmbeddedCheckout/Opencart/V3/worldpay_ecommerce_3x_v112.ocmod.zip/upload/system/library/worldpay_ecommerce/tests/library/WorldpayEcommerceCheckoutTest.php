<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\Forms\Challenge;
use Worldpay\Api\Forms\DeviceDataCollection;
use Worldpay\Api\ValueObjects\ThreeDS;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;
use Worldpay\Api\ApiResponse;

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce_checkout.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once __DIR__.'/../../worldpay_service.php';
require_once __DIR__.'/../../logger.php';

class WorldpayEcommerceCheckoutTest extends TestCase {
    protected $registry;
    protected $payment_method;
    protected $mockOrderData = [
        'order_id' => '353',
        'invoice_no' => '0',
        'invoice_prefix' => 'INV-2024-00',
        'store_id' => '0',
        'store_name' => 'Your Store',
        'customer_id' => '1',
        'firstname' => 'Test First Name',
        'lastname' => 'Test Last Name',
        'email' => 'test@test.com',
        'telephone' => '0123456789',
        'custom_field' => NULL,
        'payment_firstname' => 'First name',
        'payment_lastname' => 'Last name',
        'payment_company' => 'Company name',
        'payment_address_1' => 'Street address',
        'payment_address_2' => '',
        'payment_postcode' => 'B14 4LE',
        'payment_city' => 'Town / City',
        'payment_zone_id' => '3949',
        'payment_zone' => 'County Antrim',
        'payment_zone_code' => 'ANT',
        'payment_country_id' => '222',
        'payment_country' => 'United Kingdom',
        'payment_iso_code_2' => 'GB',
        'payment_iso_code_3' => 'GBR',
        'payment_address_format' => '',
        'payment_method' => 'Pay with Card (Worldpay)',
        'payment_code' => 'access_worldpay_hpp',
        'shipping_firstname' => 'First name',
        'shipping_lastname' => 'Last name',
        'shipping_company' => 'Company name',
        'shipping_address_1' => 'Street address',
        'shipping_address_2' => '',
        'shipping_postcode' => 'B14 4LE',
        'shipping_city' => 'Town / City',
        'shipping_zone_id' => '3949',
        'shipping_zone' => 'County Antrim',
        'shipping_zone_code' => 'ANT',
        'shipping_country_id' => '222',
        'shipping_country' => 'United Kingdom',
        'shipping_iso_code_2' => 'GB',
        'shipping_iso_code_3' => 'GBR',
        'shipping_address_format' => '',
        'shipping_method' => 'Flat Shipping Rate',
        'shipping_code' => 'flat.flat',
        'comment' => '',
        'total' => 102.94,
        'order_status_id' => '0',
        'order_status' => NULL,
        'affiliate_id' => '0',
        'commission' => '0.0000',
        'language_id' => '1',
        'language_code' => 'en-gb',
        'currency_id' => '3',
        'currency_code' => 'EUR',
        'currency_value' => '0.78460002',
        'ip' => '127.0.0.1',
        'accept_language' => 'en-US,en;q=0.9',
        'date_added' => '2025-01-29 12:52:19',
        'date_modified' => '2025-01-29 12:52:19',
    ];

    protected $tryUsername;
    protected $tryPassword;
    protected $merchantEntity;
    protected $merchantNarrative;
    protected $merchantCheckoutId;

    protected function setUp(): void
    {
        parent::setUp();

        global $testEnv;
        $this->tryUsername = $testEnv['CHECKOUT_TRY_USERNAME'];
        $this->tryPassword = $testEnv['CHECKOUT_TRY_PASSWORD'];
        $this->merchantEntity = $testEnv['CHECKOUT_MERCHANT_ENTITY'];
        $this->merchantNarrative = $testEnv['CHECKOUT_MERCHANT_NARRATIVE'];
        $this->merchantCheckoutId = $testEnv['CHECKOUT_MERCHANT_CHECKOUT_ID'];

//        global $registry;
//        $this->registry = $registry;

        putenv('OPENCART_TEST_CONTEXT=catalog');
        $baseDir = realpath(__DIR__ . '/../../../../');

        $this->registry = getOCRegistryConfig($baseDir . '/config.php', 'catalog');
        $this->session = $this->registry->get('session');

        $this->payment_method = \AccessWorldpayPaymentMethods::CHECKOUT;

        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_mode', 'try');
        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_try_username', $this->tryUsername);
        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_try_password', $this->tryPassword);
        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_merchant_entity', $this->merchantEntity);
        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_merchant_narrative', $this->merchantNarrative);
        $this->registry->get('config')->set('payment_'.\AccessWorldpayPaymentMethods::CHECKOUT.'_app_merchant_try_checkout_id', $this->merchantCheckoutId);

        $this->registry->set('user', new \Cart\User($this->registry));

    }

    public function testGet3DSChallengeForm()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockCLass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);

        $response = $mockCLass->get3DSChallengeForm('url', 'jwt', 'hash');

        $this->assertInstanceOf(Challenge::class, $response);
    }

    public function testGetDeviceDataCollectionForm()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockCLass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);

        $response = $mockCLass->getDeviceDataCollectionForm('url', 'bn', 'jwt');

        $this->assertInstanceOf(DeviceDataCollection::class, $response);
    }

    public function testGetCheckoutSdkUrl()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockCLass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);

        $response = $mockCLass->getCheckoutSdkUrl();

        $this->assertStringContainsString('worldpay.com/access-checkout/v2/checkout.js', $response);
    }

    public function testCreateThreeDSObject()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockCLass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);

        $response = $mockCLass->createThreeDSObject('url');

        $this->assertInstanceOf(ThreeDS::class, $response);
    }

    public function testCreatePaymentInstrumentObject()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockCLass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);

        $response = $mockCLass->createPaymentInstrumentObject('session_href', 'card_holder_name');

        $this->assertInstanceOf(CreditCard::class, $response);
    }

    public function testTestApiCredentials()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockClass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);
        $response = $mockClass->testApiCredentials();

        $this->assertInstanceOf(ApiResponse::class, $response);;
    }

    public function testFetch3DSChallengeResult()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockClass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);
        $this->expectException(\Exception::class);

        $mockClass->fetch3DSChallengeResult('complete3DSChallengeUrl');
    }


    public function testSupply3DSDeviceData()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockClass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);
        $this->expectException(\Exception::class);

        $mockClass->supply3DSDeviceData('supply_3ds_device_link_data', 'collection_reference');
    }

    public function testInitializePayment()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $mockClass= new \WorldpayEcommerceCheckout($worldpayService, $this->mockOrderData);
        $this->expectException(\Exception::class);

        $mockClass->initializePayment(
            \WorldpayService::getTransactionReferenceByOrderId(rand(111, 99999)),
            '',
            'test card holder name',
            'threeDSChallengeReturnUrl'
        );

    }

}