<?php

//namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

use Cart\User;

require_once DIR_APPLICATION.'/../system/library/cart/user.php';

class UserMockup extends User{
	public $hasPermissionBool = true;

	public function hasPermission($key, $value){
		return $this->hasPermissionBool;
	}
}