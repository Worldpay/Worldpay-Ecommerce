<?php

class AccessWorldpayPaymentMethods {
	public const HPP = 'access_worldpay_hpp';
	public const CHECKOUT = 'access_worldpay_checkout';
}
