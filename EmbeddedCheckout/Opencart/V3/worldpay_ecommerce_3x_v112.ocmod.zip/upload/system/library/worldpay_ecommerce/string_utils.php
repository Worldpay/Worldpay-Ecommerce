<?php

class StringUtils {
	/**
	 * @param $value
	 * @param $limit
	 * @param $end
	 *
	 * @return string
	 */
	public static function limit($value, $limit = 100, $end = '...'): string {
		if (mb_strwidth($value, 'UTF-8') <= $limit) {
			return $value;
		}

		return rtrim(mb_strimwidth($value, 0, $limit, '', 'UTF-8')) . $end;
	}

	/**
	 * Masks a part of the string with a specified character.
	 *
	 * @param string|null $string The input string.
	 * @param string $character The character used for masking.
	 * @param int $index The start position of the mask.
	 * @param int|null $length The number of characters to mask.
	 * @param string $encoding The character encoding.
	 *
	 * @return string The masked string or the original string if null is passed.
	 */
	public static function mask($string, $character, $index, $length = null, $encoding = 'UTF-8'): string {
		if (null === $string || $character === '') {
			return $string ?? '';
		}

		$segment = mb_substr($string, $index, $length, $encoding);

		if ($segment === false || $segment === '') {
			return $string;
		}

		$strlen      = mb_strlen($string, $encoding);
		$start_index = $index >= 0 ? $index : max($strlen + $index, 0);

		$start       = mb_substr($string, 0, $start_index, $encoding);
		$segment_len = mb_strlen($segment, $encoding);
		$end         = mb_substr($string, $start_index + $segment_len, $strlen - $start_index - $segment_len, $encoding);

		return $start . str_repeat(mb_substr($character, 0, 1, $encoding), $segment_len) . $end;
	}

	/**
	 * @param $value
	 * @param $encoding
	 *
	 * @return false|int
	 */
	public static function length($value, $encoding = 'UTF-8') {
		if (empty($value)) {
			return 0;
		}

		return mb_strlen($value, $encoding);
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public static function maskStringTotally($string) {
		return self::limit(self::mask($string, '*', 0, self::length($string)), 64, '');
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public static function maskStringPartially($string) {
		return self::mask($string, '*', 0, self::length($string) - 4);
	}
}
