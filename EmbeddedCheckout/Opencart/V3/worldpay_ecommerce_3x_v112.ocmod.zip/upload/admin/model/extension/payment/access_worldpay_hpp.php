<?php

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once('access_worldpay.php');

class ModelExtensionPaymentAccessWorldpayHpp extends AccessWorldpay {
	protected $payment_method = \AccessWorldpayPaymentMethods::HPP;

	public function getPaymentMethodTransactionTableSql(): string {
		return "
		CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . $this->payment_method . "_transactions` (
			`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			`order_id` BIGINT UNSIGNED NOT NULL,
			`reference` VARCHAR(100) NOT NULL,
			`amount` DECIMAL(15,4) NOT NULL,
			`currency` VARCHAR(3) NOT NULL,
			`order_status` ENUM('" . WorldpayService::TRANSACTION_STATUS_PENDING . "', '" . WorldpayService::TRANSACTION_STATUS_SUCCESS . "', '" . WorldpayService::TRANSACTION_STATUS_FAILED . "', '" . WorldpayService::TRANSACTION_STATUS_CANCELED . "') DEFAULT '" . WorldpayService::TRANSACTION_STATUS_PENDING . "',
			`env_mode` ENUM('try', 'live'),
			`success_guid` VARCHAR(36) NOT NULL,
			`failure_guid` VARCHAR(36) NOT NULL,
			`hpp_redirect_url` VARCHAR(512) NOT NULL,
			`finalized` BOOLEAN DEFAULT FALSE,
			`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (`id`),
			KEY (`success_guid`),
			KEY (`failure_guid`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		";
	}
}
