<?php

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/string_utils.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/admin/access_worldpay_controller.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce_hpp.php');

class ControllerExtensionPaymentAccessWorldpayHpp extends \AccessWorldpayController {
	/**
	 * @var string
	 */
	protected $payment_method = \AccessWorldpayPaymentMethods::HPP;

	/**
	 * @return array
	 */
	protected function getSettingFields(): array {
		$output = parent::getSettingFields();

		$output['payment_access_worldpay_app_merchant_description'] = $this->config->get('payment_' . $this->payment_method . '_app_merchant_description');
		$output['payment_access_worldpay_checkout_mode']   = $this->config->get('payment_' . $this->payment_method . '_checkout_mode');

		return $output;
	}
}
