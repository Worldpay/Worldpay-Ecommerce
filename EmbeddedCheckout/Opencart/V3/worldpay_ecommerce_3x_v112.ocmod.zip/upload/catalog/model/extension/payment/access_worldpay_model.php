<?php

class AccessWorldpayModel extends Model {
	/**
	 * @var string
	 */
	protected $payment_method = '';

	/**
	 * getMethods
	 *
	 * @param mixed $address
	 * @param mixed $total
	 *
	 * @return array
	 */
	public function getMethod($address, $total): array {
		$total = $total ?: 0;
		$this->load->language('extension/payment/' . $this->payment_method);

		$status = true;
		if ($total < 0) {
			$status = false;
		} elseif (!empty($this->cart->getRecurringProducts())) {
			$status = false;
		}

		$method_data = [];

		if ($status) {
			$method_data = [
				'code'       => $this->payment_method,
				'title'      => $this->language->get('heading_title'),
				'terms'      => '',
				'sort_order' => $this->config->get('payment_' . $this->payment_method . '_sort_order')
			];
		}

		return $method_data;
	}

	/**
	 * @param int    $id
	 * @param string $status
	 *
	 * @return bool
	 */
	public function changeTransactionStatus(int $id, string $status): bool {
		if (!in_array($status, [WorldpayService::TRANSACTION_STATUS_SUCCESS, WorldpayService::TRANSACTION_STATUS_FAILED])) {
			return false;
		}
		$finalized = (int)($status === WorldpayService::TRANSACTION_STATUS_SUCCESS ? true : false);

		$query = $this->db->query("UPDATE `" . DB_PREFIX . $this->payment_method . "_transactions` SET `finalized` = " . $finalized . ", `order_status` = '" . $status . "' WHERE `id` = " . $id . ";");

		return true;
	}
}
