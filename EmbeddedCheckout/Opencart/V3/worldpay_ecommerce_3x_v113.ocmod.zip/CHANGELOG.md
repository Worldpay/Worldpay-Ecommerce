# Worldpay eCommerce for OpenCart change log

### [v1.1.3] (10/07/2025)
* Fixed missing transactionReferences for 3DS DDC.

### [v1.1.2] (08/25/2025)
* Added User-Agent header to all requests.
* Disabled settlement cancellation on AVS not matched.

### [v1.1.1] (06/16/2025)
* Added fallback refund keys.

### [v1.1.0] (02/06/2025)
* Added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment.

### [v1.0.1] (07/12/2024)
* Added compatibility checks.
* Added iframe support.
* Added regex validation for merchant narrative.
* Added Description setting.
* Removed GBP checkout restriction.

### [v1.0.0] (04/05/2024)
* Initial release.