<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

use Opencart\Extension\WorldpayEcommerce\System\Library\Logger;
//use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerce;
use stdClass;

class WorldpayEcommerceMock extends \WorldpayEcommerceHpp {
	public function refund($order_id, $refund_amount, $refund_currency, $transaction_reference, $partial_refund_reference, $is_partial_refund, $link_data = '', $status_code = 202): bool
    {
		$api = $this->worldpay_service->initializeApi();

		$api_response = new stdClass();
		$api_response->rawRequest = 'raw_request';
		$api_response->rawResponse = 'raw_response';
		$api_response->headers = [];
		$api_response->statusCode = $status_code;

		$data_to_log = [
			"partial_refund_reference" => $partial_refund_reference,
			"order_id"                 => $order_id,
			"transaction_amount"       => $refund_amount,
			"transaction_reference"    => $transaction_reference,
			"api_request"              => $api_response->rawRequest,
			"api_response"             => $api_response->rawResponse,
			"wp-correlationid"         => $this->getWpCorrelationId($api_response->headers),
		];

		if ($api_response->statusCode !== 202) {
			\Logger::setDescription("Refund failed")->alert($data_to_log);

			throw new \Exception('Something went wrong while requesting payment refund.');
		} else {
			\Logger::setDescription("Refund success")->debug($data_to_log);
		}

		return true;
	}
}
