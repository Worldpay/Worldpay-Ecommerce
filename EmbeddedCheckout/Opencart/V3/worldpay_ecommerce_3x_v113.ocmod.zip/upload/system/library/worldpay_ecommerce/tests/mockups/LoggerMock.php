<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');

class LoggerMock extends \Logger
{
	public static function validateJson(string $data): bool
	{
		return parent::validateJson($data);
	}

	public static function debug($log_data): \Logger
	{
		self::$app_debug = 1;
		return parent::debug($log_data);
	}
}