<?php

//namespace mockdata;

class SessionMock extends \Session
{
    public $data;

    public function getUserName()
    {
        return 'Test';
    }
}