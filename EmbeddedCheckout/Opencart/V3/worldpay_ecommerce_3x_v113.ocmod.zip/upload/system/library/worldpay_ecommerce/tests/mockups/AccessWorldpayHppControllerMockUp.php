<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

//use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;

class AccessWorldpayHppControllerMockUp extends \ControllerExtensionPaymentAccessWorldpayHpp {
	public static $orderHistoryData = [];

	public function testApiCredentials($post_request = []): bool {
		return parent::testApiCredentials($post_request);
	}

	public function testApiCredentialsRequest(): void {
		parent::testApiCredentialsRequest();
	}

	public function validate(array &$post_request): array {
		return parent::validate($post_request);
	}

	public function validateApiTryPassword(array &$post_request): array {
		return parent::validateApiTryPassword($post_request);
	}

	public function validateApiTryUsername(array $post_request): array {
		return parent::validateApiTryUsername($post_request);
	}

	public function validateApiLivePassword(array &$post_request): array {
		return parent::validateApiLivePassword($post_request);
	}

	public function validateApiLiveUsername(array $post_request): array {
		return parent::validateApiLiveUsername($post_request);
	}

	public function validateApiMerchantEntity(array &$post_request): array {
		return parent::validateApiMerchantEntity($post_request);
	}

	public function validateApiMerchantNarrative(array $post_request): array {
		return parent::validateApiMerchantNarrative($post_request);
	}

	public function replaceMaskedApiTryPassword(array &$post_request): void {
		parent::replaceMaskedApiTryPassword($post_request);
	}

	public function replaceMaskedMerchantEntity(array &$post_request): void {
		parent::replaceMaskedMerchantEntity($post_request);
	}

	public function replaceMaskedApiLivePassword(array &$post_request): void {
		parent::replaceMaskedApiLivePassword($post_request);
	}

	public function refund(): void {
		$this->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');

		$this->registry->set('worldpay_service', new \WorldpayService($this->registry));
		$worldpay = new WorldpayEcommerceMock($this->worldpay_service);

		$order_id = 1;
		$refund_amount = 22.00;
		$refund_currency = 'GBP';
		$transaction_reference = $this->request->post['access_worldpay_hpp_full_refund_reference'] ?? 'transaction_reference';
		$partial_refund_reference = 'partial_refund_reference';
		$link_data = '';

		$worldpay->refund($order_id, $refund_amount, $refund_currency, $transaction_reference, $partial_refund_reference, false, $link_data);

		$json['success'] = $this->language->get('success_refund_processed');

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function refundWrongStatusCode($status_code): void {
		$this->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');

		$this->registry->set('worldpay_service', new \WorldpayService($this->registry, \AccessWorldpayPaymentMethods::HPP));
		$worldpay = new WorldpayEcommerceMock($this->worldpay_service);

		$order_id = 1;
		$refund_amount = 22.00;
		$refund_currency = 'GBP';
		$transaction_reference = $this->request->post['access_worldpay_hpp_full_refund_reference'] ?? 'transaction_reference';
		$partial_refund_reference = 'partial_refund_reference';
		$link_data = '';

		$worldpay->refund($order_id, $refund_amount, $refund_currency, $transaction_reference, $partial_refund_reference, false, $link_data, $status_code);

		$json['success'] = $this->language->get('success_refund_processed');

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function getSettingFields(): array
	{
		return parent::getSettingFields();
	}

	public function addOrderHistory($order_id, $data, $store_id = 0)
	{
		$this->orderHistoryData = [
			'order_id' => $order_id,
			'data' => $data,
			'store_id' => $store_id,
		];
		return parent::addOrderHistory($order_id, $data, $store_id);
	}

	public function formatCurrencyAmount($amount, $currencyCode)
	{
		return parent::formatCurrencyAmount($amount, $currencyCode);
	}

	public function addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference): void
	{
		parent::addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference);
	}
}
