<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests;

use PHPUnit\Framework\TestCase;

require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce_hpp.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/access_worldpay_payment_methods.php');
require_once __DIR__.'/../../worldpay_service.php';
require_once __DIR__.'/../../logger.php';

class WorldpayEcommerceHppTest extends TestCase {

    protected $registry;
    protected $payment_method;
    protected $mockOrderData = [
        'order_id' => '353',
        'invoice_no' => '0',
        'invoice_prefix' => 'INV-2024-00',
        'store_id' => '0',
        'store_name' => 'Your Store',
        'customer_id' => '1',
        'firstname' => 'Test First Name',
        'lastname' => 'Test Last Name',
        'email' => 'test@test.com',
        'telephone' => '0123456789',
        'custom_field' => NULL,
        'payment_firstname' => 'First name',
        'payment_lastname' => 'Last name',
        'payment_company' => 'Company name',
        'payment_address_1' => 'Street address',
        'payment_address_2' => '',
        'payment_postcode' => 'B14 4LE',
        'payment_city' => 'Town / City',
        'payment_zone_id' => '3949',
        'payment_zone' => 'County Antrim',
        'payment_zone_code' => 'ANT',
        'payment_country_id' => '222',
        'payment_country' => 'United Kingdom',
        'payment_iso_code_2' => 'GB',
        'payment_iso_code_3' => 'GBR',
        'payment_address_format' => '',
        'payment_method' => 'Pay with Card (Worldpay)',
        'payment_code' => 'access_worldpay_hpp',
        'shipping_firstname' => 'First name',
        'shipping_lastname' => 'Last name',
        'shipping_company' => 'Company name',
        'shipping_address_1' => 'Street address',
        'shipping_address_2' => '',
        'shipping_postcode' => 'B14 4LE',
        'shipping_city' => 'Town / City',
        'shipping_zone_id' => '3949',
        'shipping_zone' => 'County Antrim',
        'shipping_zone_code' => 'ANT',
        'shipping_country_id' => '222',
        'shipping_country' => 'United Kingdom',
        'shipping_iso_code_2' => 'GB',
        'shipping_iso_code_3' => 'GBR',
        'shipping_address_format' => '',
        'shipping_method' => 'Flat Shipping Rate',
        'shipping_code' => 'flat.flat',
        'comment' => '',
        'total' => 102.94,
        'order_status_id' => '0',
        'order_status' => NULL,
        'affiliate_id' => '0',
        'commission' => '0.0000',
        'language_id' => '1',
        'language_code' => 'en-gb',
        'currency_id' => '3',
        'currency_code' => 'EUR',
        'currency_value' => '0.78460002',
        'ip' => '127.0.0.1',
        'accept_language' => 'en-US,en;q=0.9',
        'date_added' => '2025-01-29 12:52:19',
        'date_modified' => '2025-01-29 12:52:19',
    ];

    protected $tryUsername;
    protected $tryPassword;
    protected $merchantEntity;

    protected function setUp(): void
    {
        parent::setUp();

        global $testEnv;
        $this->tryUsername = $testEnv['HPP_TRY_USERNAME'];
        $this->tryPassword = $testEnv['HPP_TRY_PASSWORD'];
        $this->merchantEntity = $testEnv['HPP_MERCHANT_ENTITY'];

//        global $registry;
//        $this->registry = $registry;

        putenv('OPENCART_TEST_CONTEXT=catalog');
        $baseDir = realpath(__DIR__ . '/../../../../');

        $this->registry = getOCRegistryConfig($baseDir . '/config.php', 'catalog');
        $this->session = $this->registry->get('session');

        $this->payment_method = \AccessWorldpayPaymentMethods::HPP;

        $this->registry->get('config')->set('payment_access_worldpay_hpp_app_mode', 'try');
        $this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_username', $this->tryUsername);
        $this->registry->get('config')->set('payment_access_worldpay_hpp_app_try_password', $this->tryPassword);
        $this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_entity', $this->merchantEntity);
        $this->registry->get('config')->set('payment_access_worldpay_hpp_app_merchant_narrative', "narrative");

        $this->registry->set('user', new \Cart\User($this->registry));

    }

    public function testRetrieveHppUrl()
    {
        $worldpayService = new \WorldpayService($this->registry, $this->payment_method);
        $worldpay = new \WorldpayEcommerceHpp($worldpayService, $this->mockOrderData);
        $transaction_reference = \WorldpayService::getTransactionReferenceByOrderId(rand(111, 9999999));
        $success_return_url = '';
        $failure_return_url = '';
        $cancel_return_url = '';

        $hpp_url = $worldpay->retrieveHppUrl($transaction_reference, $success_return_url, $failure_return_url, $cancel_return_url);

        $this->assertStringContainsString('worldpay.com/app/hpp/integration/transaction', $hpp_url);
    }



    protected function tearDown(): void {
        unset($this->session->data['user_id'], $this->session->data['user_token']);
        $this->registry->set('session', $this->session);

        $response = new \Response();
        $response->addHeader('Content-Type: text/html; charset=utf-8');
        $config = $this->registry->get('config');
        $response->setCompression($config->get('config_compression'));
        $this->registry->set('response', $response);

        parent::tearDown();
    }
}