<?php

function getEnvironmentType(): string {
	$currentEnv = '';

	$allowed = [
		'production',
		'staging',
		'development',
		'testing'
	];

	$hasEnv = getenv('OPENCART_ENVIRONMENT');

	if(false !== $hasEnv) {
		$currentEnv = $hasEnv;
	}

	if(defined('OPENCART_ENVIRONMENT') && OPENCART_ENVIRONMENT) {
		$currentEnv = OPENCART_ENVIRONMENT;
	}

	if(!in_array($currentEnv, $allowed, true)) {
		$currentEnv = 'production';
	}

	return $currentEnv;
}

function isProduction(): bool {
	return getEnvironmentType() === 'production';
}