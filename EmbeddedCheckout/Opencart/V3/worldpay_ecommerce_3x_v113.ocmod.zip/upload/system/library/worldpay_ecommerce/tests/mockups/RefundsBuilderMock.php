<?php

namespace Opencart\Extension\WorldpayEcommerce\Tests\Mockups;

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Builders\Payments\RefundsBuilder;
use Worldpay\Api\Services\Api\AccessWorldpay\QueryResource;

class RefundsBuilderMock extends RefundsBuilder
{
	public function execute(): ApiResponse {
		$refundUrl = 'my-refund-url';

		return QueryResource::paymentsRefund($refundUrl);
	}
}
