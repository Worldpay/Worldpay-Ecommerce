Thank you for Downloading the file containing the worldpay ecommerce plugin for Opencart. Please note this is for OpenCart Version 3.X

You can find more details about the install here: https://developer.worldpay.com/products/access/plugins/opencart