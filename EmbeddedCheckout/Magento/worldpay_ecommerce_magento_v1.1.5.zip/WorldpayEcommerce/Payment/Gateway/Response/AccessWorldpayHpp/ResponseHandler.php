<?php
namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayHpp;

use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class ResponseHandler implements HandlerInterface
{

    /**
     * @var SubjectReader
     */
    protected SubjectReader $subjectReader;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     */
    public function __construct(SubjectReader $subjectReader)
    {
        $this->subjectReader = $subjectReader;
    }

    /**
     * Handle response.
     *
     * @param array $handlingSubject
     * @param array $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response): void
    {
        /** @var OrderPaymentInterface $payment */
        $payment = $this->subjectReader->readPayment($handlingSubject)->getPayment();

        $hppPaymentResponse = $response['payment'] ?? [];
        $paymentGuids = $hppPaymentResponse['guids'] ?? [];

        $hppAdditionalInformation = [
            'hppUrl'                    => $hppPaymentResponse['hppUrl'] ?? '',
            'success_guid'              => $paymentGuids['success'] ?? '',
            'failure_guid'              => $paymentGuids['failure'] ?? '',
            'cancel_guid'               => $paymentGuids['cancel'] ?? '',
            'transaction_reference'     => $hppPaymentResponse['transactionReference'] ?? '',
        ];

        foreach ($hppAdditionalInformation as $additionalInformationKey => $additionalInformationValue) {
            $payment->setAdditionalInformation($additionalInformationKey, $additionalInformationValue);
        }

        Logger::setDescription('Details Handler Additional Information')->debug($hppAdditionalInformation);
    }
}
