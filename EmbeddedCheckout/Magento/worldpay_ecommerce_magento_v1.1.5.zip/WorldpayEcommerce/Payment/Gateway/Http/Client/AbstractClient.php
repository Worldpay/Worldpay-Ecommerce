<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Store\Model\StoreManagerInterface;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Helper\RequestDataLogHelper;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use Worldpay\Api\ApiResponse;

abstract class AbstractClient implements ClientInterface
{

    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * @var Resolver
     */
    protected Resolver $store;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $url;

    /**
     * @var array
     */
    protected array $output;

    /**
     * @var array
     */
    protected array $requestData;

    /**
     * @var RequestDataLogHelper
     */
    protected RequestDataLogHelper $requestDataLogHelper;

    /**
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     * @param Resolver $store
     * @param RequestInterface $request
     * @param UrlInterface $url
     * @param ProductMetadataInterface $productMetadata
     * @param StoreManagerInterface $storeManager
     * @param RequestDataLogHelper $requestDataLogHelper
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig,
        Resolver $store,
        RequestInterface $request,
        UrlInterface $url,
        ProductMetadataInterface $productMetadata,
        StoreManagerInterface $storeManager,
        RequestDataLogHelper $requestDataLogHelper
    ) {
        $this->worldpayService = new WorldpayService(
            $config,
            $scopeConfig,
            $request,
            $productMetadata,
            $storeManager,
            $config->getMethodCode()
        );

        $this->store = $store;
        $this->url = $url;
        $this->requestDataLogHelper = $requestDataLogHelper;
        $this->output = [];
        $this->output['payment'] = [];
    }

    /**
     * @return ApiResponse
     */
    abstract protected function sendApiRequest(): ApiResponse;

    /**
     * @return string
     * @throws \Exception
     */
    protected function setTransactionReference(): string
    {
        $transactionReference = WorldpayService::getTransactionReferenceByOrderId($this->requestData['orderId']);
        $this->output['payment']['transactionReference']      = $transactionReference;
        $this->requestData['payment']['transactionReference'] = $transactionReference;

        return $transactionReference;
    }
}
