<?php

namespace WorldpayEcommerce\Payment\Helper;

class RequestDataLogHelper
{
    /**
     * Get safe initialize request data for logging.
     *
     * @param array $requestData
     * @return array
     */
    public function filterForLog(array $requestData): array
    {
        $dataToLog = [
            'paymentMethodCode' => $requestData['paymentMethodCode'] ?? '',
            'orderId' => $requestData['orderId'] ?? '',
            'total' => $requestData['total'] ?? '',
            'currency_code' => $requestData['currency_code'] ?? '',
            'customer' => $requestData['customer'] ?? [],
            'billing' => $requestData['billing'] ?? [],
        ];

        if (!empty($requestData['shipping'])) {
            $dataToLog['shipping'] = $requestData['shipping'];
        }

        if (!empty($requestData['locale'])) {
            $dataToLog['locale'] = $requestData['locale'];
        }

        if (!empty($requestData['threeDSChallengeReturnUrl'])) {
            $dataToLog['threeDSChallengeReturnUrl'] = $requestData['threeDSChallengeReturnUrl'];
        }

        return $dataToLog;
    }
}
