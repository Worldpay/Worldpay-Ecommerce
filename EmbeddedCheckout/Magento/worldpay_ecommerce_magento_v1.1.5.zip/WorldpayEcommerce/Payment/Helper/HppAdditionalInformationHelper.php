<?php

namespace WorldpayEcommerce\Payment\Helper;

class HppAdditionalInformationHelper
{
    /**
     * Get safe HPP additional information for logging.
     *
     * @param array $additionalInformation
     * @return array
     */
    public function filterForLog(array $additionalInformation): array
    {
        return [
            'hppUrl' => $additionalInformation['hppUrl'] ?? '',
            'success_guid' => $additionalInformation['success_guid'] ?? '',
            'failure_guid' => $additionalInformation['failure_guid'] ?? '',
            'cancel_guid' => $additionalInformation['cancel_guid'] ?? '',
            'transaction_reference' => $additionalInformation['transaction_reference'] ?? '',
        ];
    }
}
