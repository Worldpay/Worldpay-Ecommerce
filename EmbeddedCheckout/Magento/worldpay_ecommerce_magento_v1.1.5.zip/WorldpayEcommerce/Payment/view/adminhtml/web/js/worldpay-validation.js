require(['jquery', 'domReady!'], function ($) {
        'use strict';

        const onsiteEnabledSelector = '[data-ui-id="select-groups-worldpay-ecommerce-groups-card-payments-groups-access-worldpay-checkout-fields-active-value"]';
        const offsiteEnabledSelector = '[data-ui-id="select-groups-worldpay-ecommerce-groups-card-payments-groups-access-worldpay-hpp-fields-active-value"]';
        const selectors = [onsiteEnabledSelector, offsiteEnabledSelector];
        const cssDefaultSelector = '.worldpay-ecommerce-account-settings';
        const accountSettingsOnsite = '.worldpay-ecommerce-account-settings-onsite';

        function worldpayPaymentMethodsEnabled() {
            return selectors.some(selector => $(selector).find(':selected').val() === '1');
        }

        function isOnsitePaymentMethodEnabled() {
            return $(onsiteEnabledSelector).find(':selected').val() === '1';
        }

        function isEmptyCheckoutId() {
            return $(accountSettingsOnsite).val() === '';
        }

        function updateValidationClasses() {
            const addClasses = worldpayPaymentMethodsEnabled();
            const isOnsiteEnabled = isOnsitePaymentMethodEnabled();

            $(cssDefaultSelector).toggleClass('required-entry', addClasses);
            $(accountSettingsOnsite).toggleClass('required-entry', isOnsiteEnabled);
            $(accountSettingsOnsite).toggleClass('mage-error', isOnsiteEnabled && isEmptyCheckoutId());
            if (!addClasses) {
                $(cssDefaultSelector).removeClass('mage-error');
            }
        }

        $(selectors.join(', ')).on('change', updateValidationClasses);
        updateValidationClasses();

    $('.worldpay-ecommerce-obscure').each(function () {
        const $field = $(this);
        let currentVal = $field.val();

        $field.on('focusin', function () {
            $field.val('');
        });

        $field.on('focusout', function () {
            const newVal = $field.val();

            if (newVal === '') {
                $field.val(currentVal);
                return;
            }

            currentVal = newVal;
        });
    });
});
