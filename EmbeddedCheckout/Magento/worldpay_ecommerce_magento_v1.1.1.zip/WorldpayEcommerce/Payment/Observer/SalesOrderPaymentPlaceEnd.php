<?php

namespace WorldpayEcommerce\Payment\Observer;

use Magento\Checkout\Model\Session;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeFactory;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;

class SalesOrderPaymentPlaceEnd implements ObserverInterface
{

    /**
     * @var TransactionHelper
     */
    protected TransactionHelper $transactionHelper;

    /**
     * @var ResultFactory
     */
    protected ResultFactory $resultFactory;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var Session
     */
    protected Session $checkoutSession;

    /**
     * @var InvoiceHelper
     */
    protected InvoiceHelper $invoiceHelper;

    /**
     * @var OrderSender
     */
    protected OrderSender $emailSender;

    /**
     * @param  TransactionHelper  $transactionHelper
     * @param  ResultFactory  $resultFactory
     * @param  OrderRepositoryInterface  $orderRepository
     * @param  Session  $checkoutSession
     * @param  InvoiceHelper  $invoiceHelper
     * @param  OrderSender  $emailSender
     */
    public function __construct(
        TransactionHelper $transactionHelper,
        ResultFactory $resultFactory,
        OrderRepositoryInterface $orderRepository,
        Session $checkoutSession,
        InvoiceHelper $invoiceHelper,
        OrderSender $emailSender
    ) {
        $this->transactionHelper = $transactionHelper;
        $this->resultFactory = $resultFactory;
        $this->orderRepository = $orderRepository;
        $this->checkoutSession = $checkoutSession;
        $this->invoiceHelper = $invoiceHelper;
        $this->emailSender = $emailSender;
    }

    /**
     * @param  Observer  $observer
     *
     * @return void
     * @throws \Exception
     */
    public function execute(Observer $observer)
    {
        $payment = $observer->getEvent()->getPayment();
        $order = $payment->getOrder();

        switch ($payment->getMethod()) {
            case PaymentMethodConfig::ACCESS_WORLDPAY_HPP_CODE:
                if ($order->getStatus() === WorldpayService::TRANSACTION_STATUS_PENDING &&
                    ($order->getState() === Order::STATE_NEW || $order->getState() === Order::STATE_PROCESSING)) {
                    $order->setCanSendNewEmailFlag(false);
                    $order->setState(Order::STATE_PENDING_PAYMENT);
                    $order->setStatus(Order::STATE_PENDING_PAYMENT);
                }
                break;
            case PaymentMethodConfig::ACCESS_WORLDPAY_CHECKOUT_CODE:
                $paymentAdditionalInformation = $payment->getAdditionalInformation();
                $paymentOutcome = OutcomeFactory::createOutcome($paymentAdditionalInformation['paymentOutcome']);
                $paymentOutcome->setOrderRepositoryInterface($this->orderRepository);
                $paymentOutcome->setSession($this->checkoutSession);
                $paymentOutcome->setTransactionHelper($this->transactionHelper);
                $paymentOutcome->setInvoiceHelper($this->invoiceHelper);
                $paymentOutcome->setOrderSender($this->emailSender);
                $paymentOutcome->handleOrder($order);
                break;
        }
    }
}
