## Worldpay eCommerce for Magento Community Edition

Worldpay eCommerce helps enhance your online checkout experience and payments processing, so your customers can easily and safely pay how they want, which may result in fewer abandoned carts, less fraud and more sales.

### License

License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

### Features

- Cronjob to reconcile orders with no payment results
- Embedded Checkout
- Hosted Payment Pages
- Pay with a new card
- Pay with a Mobile Wallet (Apple Pay or Google Pay)

### Support

For any other issues or further support log into <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a> and visit our support centre.

### Retrieve your credentials

1. Log into your <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a>.
2. Click on "Account & Settings".
3. Click on "Configuration Settings".
4. Click on "API credentials".
5. Switch between "Try mode" and "Live mode" and retrieve your username and password. You need:
- a Try API username
- a Try API password
6. If you're using Payments Onsite (with embedded checkout) you will also need the Checkout Id (please contact support).

### Retrieve your entity

1. Log into your <a href="https://dashboard.worldpay.com/" target="_blank">Worldpay Dashboard</a>.
2. Click on "Account & Settings".
3. Click on "Manage Account".
4. Click on "Business Details".
5. Use the second POxxx from the top as your entity.

### Go live

1. Log into your dashboard and get your TRY credentials (see steps below). You need:
- a Live API username
- a Live API password
- an entity
- a Checkout Id (Optional)
  These will be different from any other worldpay credentials you have already.
2. Navigate to the Magento config screen.
3. Copy and paste the credentials from your dashboard to the config screen, this time making sure they are going into the "Live" section.
4. Ensure the "debug" toggle is off.
5. Ensure the new "Live" entity reference is entered.
6. You can now initiate a Live transaction.

### Verify the cronjob for reconciling the orders with no payment result
1. Run Commerce cron jobs for our custom group at least twice:
   bin/magento cron:run --group="worldpay_ecommerce"

2. Clean the cache:
   bin/magento cache:clean

4. (Optional) Verify that messages are written to worldpay_ecommerce log if debug mode is enabled.

5. (Optional) If you need to effectively install the cron, please follow the indications on the <a href="https://experienceleague.adobe.com/en/docs/commerce-operations/configuration-guide/crons/custom-cron-tutorial" target="_blank">official Adobe documentation</a>.

### Changelog
1.1.1 (06/11/2025)
* added fallback refund keys
* added csp whitelist policy for frame-src
* fixed issue where the street address was not always found

1.1.0 (04/07/2025)
* added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment.
* fixed log for checkout success to log details only for our payment methods.
* added cronjob to reconcile orders with no payment results.

1.0.5 (01/13/2025)
* fix for reading street address (or other order fields) in case of prefix existence

1.0.4 (11/04/2024)
* added backwards compatibility with Magento 2.4.5-p9

1.0.3 (10/04/2024)
* the plugin now supports multiple stores
* fix for refunding negative values
* fix for updating mini-cart if payment failure or cancellation

1.0.2 (09/18/2024)
* changed wording for some of the merchant settings inputs
* fixed billing and shipping address not being sent to the gateway
* delayed the order confirmation mails to only be sent after a successful payment

1.0.1 (08/08/2024)
* Fixed bug for empty merchant settings fields at fresh module install

1.0.0 (06/27/2024)
* Initial release
