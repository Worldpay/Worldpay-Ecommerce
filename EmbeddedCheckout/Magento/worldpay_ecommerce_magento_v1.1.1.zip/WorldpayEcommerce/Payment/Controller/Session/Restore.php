<?php

namespace WorldpayEcommerce\Payment\Controller\Session;

use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Checkout\Model\Session;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\UrlInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class Restore implements ActionInterface
{

    /**
     * @var RequestInterface
     */
    protected RequestInterface $requestInterface;


    /**
     * @var Session
     */
    protected Session $checkoutSession;

    /**
     * @var JsonFactory
     */
    protected JsonFactory $jsonFactory;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlInterface;

    /**
     * @param  RequestInterface  $requestInterface
     * @param  Session  $checkoutSession
     * @param  JsonFactory  $jsonFactory
     * @param  UrlInterface  $urlInterface
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList  $directoryList
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        RequestInterface $requestInterface,
        Session $checkoutSession,
        JsonFactory $jsonFactory,
        UrlInterface $urlInterface,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $directoryList
    ) {
        $this->requestInterface = $requestInterface;
        $this->checkoutSession = $checkoutSession;
        $this->jsonFactory = $jsonFactory;
        $this->urlInterface = $urlInterface;
        Logger::config($scopeConfig, $directoryList);
    }

    /**
     * @return Json|ResultInterface|ResponseInterface
     */
    public function execute(): Json|ResultInterface|ResponseInterface
    {
        $resultJson = $this->jsonFactory->create();
        try {
            if (!$this->requestInterface->isPost()) {
                throw new \Exception('Wrong HTTP method.');
            }
            if (!$this->checkoutSession->restoreQuote()) {
                throw new \Exception('Checkout session could not be restored.');
            }
        } catch (\Exception $e) {
            Logger::setDescription('Restore session failed')->alert(['message' => $e->getMessage()]);
            return $resultJson->setData(['error' => true, 'redirect' => $this->urlInterface->getUrl('')]);
        }
        return $resultJson->setData(['success' => true]);
    }
}

