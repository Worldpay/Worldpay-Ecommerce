<?php

namespace WorldpayEcommerce\Payment\Controller\Adminhtml\Payment;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Worldpay\Api\Enums\PaymentInstrumentType;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Gateway\Config\Config as WorldpayConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceCheckout;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

/**
 * Class TestApiCredentialsRequest
 *
 * This class handles the API credentials test request in the Magento admin panel.
 * It extends the Magento Action class and uses WorldpayService to perform the API setup and validation.
 */
class TestApiCredentialsRequest extends Action
{
    /**
     * @var JsonFactory
     */
    protected JsonFactory $resultJsonFactory;

    /**
     * @var Config
     */
    protected Config $config;

    protected WorldpayEcommerce $worldpayEcommerce;

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * @param  Context  $context
     * @param  JsonFactory  $resultJsonFactory
     * @param  WorldpayConfig  $config
     * @param  WorldpayEcommerceCheckout  $worldpayEcommerce
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList  $dir
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        Config $config,
        WorldpayEcommerceCheckout $worldpayEcommerce,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->config            = $config;
        $this->scopeConfig       = $scopeConfig;
        $this->worldpayEcommerce = $worldpayEcommerce;
        Logger::config($scopeConfig, $dir);
    }

    /**
     * Execute the API credentials test.
     *
     * @return Json
     */
    public function execute(): Json
    {
        Logger::logPlatformVersion();

        $result   = $this->resultJsonFactory->create();
        $postData = $this->getRequest()->getPostValue();

        try {
            $credentials = $this->getCredentials($postData);
            $this->validateCredentials($credentials);

            $creditCardPaymentInstrument = $this->plainCreditCard();

            if (! empty($credentials['checkoutId'])) {
                $creditCardPaymentInstrument = $this->worldpayEcommerce->checkoutCreditCardSession(
                    $credentials,
                    $creditCardPaymentInstrument
                );
            }

            $apiResponse = $this->worldpayEcommerce->testApiCredentials($creditCardPaymentInstrument, $credentials);

            $dataToLog = [
                'requestAppMode'    => $credentials['appMode'],
                'correlationId'     => WorldpayService::getWpCorrelationIdFromHeaders($apiResponse->headers),
                'apiRequest'        => $apiResponse->rawRequest,
                'apiResponse'       => $apiResponse->rawResponse,
                'apiStatusCode'     => $apiResponse->statusCode,
                'apiIsSuccessful'   => (int) $apiResponse->isSuccessful(),
                'apiHasServerError' => (int) $apiResponse->hasServerError(),
                'apiHasClientError' => $apiResponse->hasClientError(),
                'apiCurlError'      => $apiResponse->curlError,
            ];
            Logger::setDescription('Test Api Credentials Request')->debug($dataToLog);

            if ($apiResponse->isSuccessful()) {
                return $result->setData(
                    [
                        'success' => true,
                        'message' => __('Worldpay Payments connected successfully
                        to the payment gateway with your provided credentials.')
                    ]
                );
            }

            if ($apiResponse->hasServerError()) {
                Logger::setDescription('Test Api Credentials Request - failed')->alert($dataToLog);
                throw new Exception(__('Worldpay Payments could not connect
                        to Access Worldpay API. Please try again later.'));
            }

            return $result->setData(
                [
                    'success' => false,
                    'message' => __('Worldpay Payments could not connect
                    to the payment gateway with your provided credentials.')
                ]
            );
        } catch (Exception $e) {
            return $result->setData(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Retrieve the API credentials from the post data.
     *
     * @param  array  $postData
     *
     * @return array
     * @throws NoSuchEntityException
     */
    protected function getCredentials(array $postData): array
    {
        $type             = $this->getRequest()->getParam('type');
        $appMode          = $postData['app_mode'] ?? 'try';
        $configPathPrefix = 'payment/' . WorldpayConfig::ACCESS_WORLDPAY_HPP_CODE . '/';

        $apiUsername    = $postData[$type === 'live' ? 'api_live_username' : 'api_try_username'] ?? '';
        $apiPassword    = $postData[$type === 'live' ? 'api_live_password' : 'api_try_password'] ?? '';
        $merchantEntity = $postData['merchant_entity'] ?? '';
        $checkoutId     = $postData[$type === 'live' ? 'api_live_checkout_id' : 'api_try_checkout_id'] ?? '';

        if (preg_match('/^\*{6}$/', $apiPassword)) {
            $apiPassword = $this->scopeConfig->getValue(
                $configPathPrefix . ($type === 'live' ? 'api_live_password' : 'api_try_password'),
                ScopeInterface::SCOPE_STORE,
                WorldpayService::getStoreId()
            );
        }

        if (preg_match('/^\*+[^*]{4}$/', $merchantEntity)) {
            $merchantEntity = $this->scopeConfig->getValue(
                $configPathPrefix . 'merchant_entity',
                ScopeInterface::SCOPE_STORE,
                WorldpayService::getStoreId()
            );
        }

        return compact('appMode', 'apiUsername', 'apiPassword', 'merchantEntity', 'checkoutId');
    }

    /**
     * Validate the provided API credentials.
     *
     * @param  array  $credentials
     *
     * @throws Exception
     */
    protected function validateCredentials(array $credentials): void
    {
        $missingFields  = [];
        $requiredFields = [
            'apiUsername'    => __('Username'),
            'apiPassword'    => __('Password'),
            'merchantEntity' => __('Merchant Entity')
        ];

        foreach ($requiredFields as $key => $label) {
            if (empty($credentials[$key])) {
                $missingFields[] = $label;
            }
        }

        if (! empty($missingFields)) {
            throw new Exception(__('Missing required fields: %1', implode(', ', $missingFields)));
        }
    }

    /**
     * @return CreditCard
     */
    protected function plainCreditCard(): CreditCard
    {
        $paymentInstrument                  = new CreditCard(PaymentInstrumentType::PLAIN);
        $paymentInstrument->cardNumber      = '4000000000001000';
        $paymentInstrument->cardExpiryYear  = date('Y', strtotime('2 years'));
        $paymentInstrument->cardExpiryMonth = date('m', strtotime('1 month'));
        $paymentInstrument->cvc             = '123';
        $paymentInstrument->cardHolderName  = 'John Doe';

        return $paymentInstrument;
    }
}
