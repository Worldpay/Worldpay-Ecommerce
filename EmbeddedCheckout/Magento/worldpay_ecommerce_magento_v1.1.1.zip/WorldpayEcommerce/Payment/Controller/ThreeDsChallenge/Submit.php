<?php

namespace WorldpayEcommerce\Payment\Controller\ThreeDsChallenge;

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\AuthenticationException;
use WorldpayEcommerce\Payment\Controller\PaymentActions\SubmitAction;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeFactory;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Successful\SuccessfulOutcome;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceCheckout;

class Submit extends SubmitAction
{

    /**
     * @return mixed
     */
    public function execute(): mixed
    {
        $result = $this->rawFactory->create();
        $apiResponse = null;
        $paymentIsSuccessful = false;
        $order = null;
        try {
            if (!$this->requestInterface->isPost()) {
                throw new \Exception( 'Wrong HTTP method.' );
            }

            if (!$this->requestInterface->getPost('MD')) {
                throw new \Exception( 'Invalid request. There is no hash in the request.');
            }

            $orderIncrementId = base64_decode($this->requestInterface->getPost('MD'));
            $order = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);
            if (! $order->getId()) {
                throw new \Exception( 'Order does not exist.');
            }

            $orderPayment = $order->getPayment();

            if (! $orderPayment->getEntityId()) {
                throw new \Exception( 'Order payment does not exist.');
            }
            $threeDsSubmissionEndpoint = $orderPayment->getAdditionalInformation('threeDsSubmissionEndpoint');
            if ($threeDsSubmissionEndpoint === null) {
                throw new \Exception( 'Three Ds submission url does not exist for orderId= '.$orderIncrementId);
            }

            $apiResponse = $this->sendApiRequest($threeDsSubmissionEndpoint);
            if (! $apiResponse->isSuccessful()) {
                throw new ApiException( 'Payment response is not successful' );
            }

            $apiResponse = $apiResponse->jsonDecode();
            if (empty($apiResponse->outcome) || empty($apiResponse->transactionReference)) {
                throw new ApiException('API breach of contract');
            }

            $paymentOutcome = OutcomeFactory::createOutcome($apiResponse->outcome);
            $paymentOutcome = $this->setPaymentOutcomeDependencies($paymentOutcome);
            $paymentOutcome->handlePayment($orderPayment, $apiResponse);
            $paymentOutcome->handleOrder($order);

            if ($paymentOutcome instanceof SuccessfulOutcome) {
                $paymentIsSuccessful = true;
            }

        } catch (\Exception $e) {
            Logger::setDescription('Process 3DS challenge result failed')->alert(
                [
                    'message' => $e->getMessage(),
                    'apiRequest' => $apiResponse->rawRequest ?? '',
                    'apiResponse' => $apiResponse->rawResponse ?? ''
                ]
            );
        }
        $data = ['success' => $paymentIsSuccessful];
        if ($paymentIsSuccessful) {
            $data['redirect'] = $this->urlInterface->getUrl('checkout/onepage/success');
            $data['outcome'] = $apiResponse->outcome ?? '';
        } else {
            $data['message'] = __('Payment failed. Please try again.')->getText();
            $data['threeDsChallengeSessionRestoreEndpoint'] = $this->urlInterface->getUrl('access_worldpay_hpp/session/restore');
        }
        $data = json_encode($data);
        $output = "
			<html>
				<head></head>
				<body>
			        <script>
			            window.onload = function() {
			                let eventType = 'access_worldpay_checkout_payment_3ds_completed';
			                let eventData = {
			                    detail: {
			                        data: '$data'
			                    },
			                }
			                window.parent.dispatchEvent(new CustomEvent(eventType, eventData));
			            }
			        </script>
				</body>
			</html>";
        $result->setHeader('Content-Type', 'text/html');

        return $result->setContents($output);
    }

    /**
     * @throws AuthenticationException
     * @throws ApiClientException
     */
    protected function sendApiRequest(string $threeDsSubmissionEndpoint): ApiResponse
    {
        return (new WorldpayEcommerceCheckout($this->worldpayService, []))->fetchThreeDsChallengeResult($threeDsSubmissionEndpoint);
    }
}
