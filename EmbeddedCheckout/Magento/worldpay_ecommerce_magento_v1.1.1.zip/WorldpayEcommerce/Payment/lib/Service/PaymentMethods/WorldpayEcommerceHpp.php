<?php

namespace WorldpayEcommerce\Payment\lib\Service\PaymentMethods;

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;

class WorldpayEcommerceHpp extends WorldpayEcommerce
{

    /**
     * @throws InvalidArgumentException
     * @throws ApiClientException
     * @throws AuthenticationException
     */
    public function initializePayment(): ApiResponse
    {
        $requestData = $this->orderData;
        $order = $this->worldpayService->getOrderData($this->orderData);
        $result_URLs = null;
        if (!empty($requestData['payment']['returnUrls']['success']) &&
            !empty($requestData['payment']['returnUrls']['failure']) &&
            !empty($requestData['payment']['returnUrls']['cancel'])) {
            $result_URLs = $this->worldpayService->getResultUrls(
                $requestData['payment']['returnUrls']['success'],
                $requestData['payment']['returnUrls']['failure'],
                $requestData['payment']['returnUrls']['cancel']
            );
        }

        $api = $this->worldpayService->initializeApi();

        $this->apiRequest = $api->initiatePayment($order->amount)
                                ->withTransactionReference($requestData['payment']['transactionReference'])
                                ->withOptionalOrder($order);
        if ($description = $this->worldpayService->getMerchantDescription()) {
            $this->apiRequest = $this->apiRequest->withDescription($description);
        }
        if (!empty($result_URLs)) {
            $this->apiRequest = $this->apiRequest->withResultURLs($result_URLs);
        }

        return $this->apiRequest->execute();
    }
}
