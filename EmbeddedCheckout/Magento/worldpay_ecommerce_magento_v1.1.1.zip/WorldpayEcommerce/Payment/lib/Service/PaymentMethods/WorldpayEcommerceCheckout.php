<?php

namespace WorldpayEcommerce\Payment\lib\Service\PaymentMethods;

use Exception;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Enums\Api;
use Worldpay\Api\Enums\FraudType;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\ApiResponseException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;

class WorldpayEcommerceCheckout extends WorldpayEcommerce
{

    /**
     * @throws InvalidArgumentException
     * @throws AuthenticationException
     * @throws ApiClientException
     */
    public function initializePayment(): ApiResponse
    {
        $requestData = $this->orderData;
        $order = $this->worldpayService->getOrderData($this->orderData);

        $paymentInstrument = $this->worldpayService->checkoutCreditCard(
            $requestData['additionalInformation']['checkoutSessionHref'],
            $requestData['additionalInformation']['cardHolderName']
        );
        $threeDSObject = $this->worldpayService->createThreeDSObject($this->orderData['threeDSChallengeReturnUrl']);

        $api = $this->worldpayService->initializeApi();

        return $api->initiatePayment($order->amount)
            ->withTransactionReference($requestData['payment']['transactionReference'])
            ->withPaymentInstrument($paymentInstrument)
            ->withThreeDS($threeDSObject)
            ->withAutoSettlement()
            ->withFraudType(FraudType::FRAUD_SIGHT)
            ->withOptionalOrder($order)
            ->execute();
    }

    /**
     * @param  string  $deviceDataCollectionSubmissionEndpoint
     * @param  string  $collectionReference
     *
     * @return ApiResponse
     * @throws ApiClientException
     * @throws AuthenticationException
     */
    public function supply3DSDeviceData(string $deviceDataCollectionSubmissionEndpoint, string $collectionReference): ApiResponse
    {
        $api = $this->worldpayService->initializeApi();

        return $api->provide3DSDeviceData()
            ->withLinkData($deviceDataCollectionSubmissionEndpoint ?? '')
            ->withCollectionReference($collectionReference)
            ->execute();
    }

    /**
     * @param  string  $threeDsSubmissionEndpoint
     *
     * @return ApiResponse
     * @throws ApiClientException
     * @throws AuthenticationException
     */
    public function fetchThreeDsChallengeResult(string $threeDsSubmissionEndpoint): ApiResponse
    {
        $api = $this->worldpayService->initializeApi();

        return $api->challenge3DSResult()->withLinkData($threeDsSubmissionEndpoint)->execute();
    }

    /**
     * Retrieve checkout CreditCard session
     *
     * @param  array  $credentials
     * @param  CreditCard  $creditCardPaymentInstrument
     *
     * @return CreditCard
     * @throws ApiClientException
     * @throws AuthenticationException
     * @throws ApiResponseException
     * @throws Exception
     */
    public function checkoutCreditCardSession(array $credentials, CreditCard $creditCardPaymentInstrument): CreditCard
    {
        $apiConfigProvider = $this->worldpayService::getApiConfigProviderForTest(Api::ACCESS_WORLDPAY_PAYMENT_SESSIONS_API, $credentials);
        $apiConfigProvider->checkoutId = $credentials['checkoutId'];

        $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        $api = $this->worldpayService->initializeApi();

        $apiResponse = $api->createPaymentSession($credentials['checkoutId'])
                           ->withCardNumber($creditCardPaymentInstrument->cardNumber)
                           ->withCardExpiryMonth($creditCardPaymentInstrument->cardExpiryMonth)
                           ->withCardExpiryYear($creditCardPaymentInstrument->cardExpiryYear)
                           ->withCardCvc($creditCardPaymentInstrument->cvc)
                           ->execute();

        if (! $apiResponse->isSuccessful()) {
            if ($apiResponse->hasClientError()) {
                throw new Exception(__('Invalid Checkout ID.'));
            }

            throw new Exception(__('Worldpay Payments could not connect to Access Worldpay API. Please try again later.'));
        }

        $decodedApiResponse = $apiResponse->jsonDecode(true);
        $sessionHref        = $decodedApiResponse['_links']['sessions:session']['href'] ?? '';

        return $this->worldpayService->checkoutCreditCard($sessionHref, $creditCardPaymentInstrument->cardHolderName);
    }
}
