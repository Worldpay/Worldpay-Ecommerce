<?php

namespace Worldpay\Api\Exceptions;

/**
 * Exception thrown when authentication fails while accessing Worldpay APIs.
 */
class AuthenticationException extends \Exception
{

}
