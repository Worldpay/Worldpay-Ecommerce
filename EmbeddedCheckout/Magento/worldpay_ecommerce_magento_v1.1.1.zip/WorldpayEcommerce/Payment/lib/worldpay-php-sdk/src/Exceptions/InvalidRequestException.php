<?php

namespace Worldpay\Api\Exceptions;

class InvalidRequestException extends \Exception
{

}