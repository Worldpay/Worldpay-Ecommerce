<?php

namespace Worldpay\Api\ValueObjects;

class ThreeDS
{
	/**
	 * @var string
	 */
	public string $type = 'integrated';

	/**
	 * @var string
	 */
	public string $mode = 'always';

	/**
	 * @var string
	 */
	public string $deviceDataAcceptHeader = 'text/html';

	/**
	 * @var string
	 */
	public string $challengeReturnUrl;

	/**
	 * @var string
	 */
	public string $deviceDataAgentHeader;

	/**
	 * @var string
	 *
	 * Accepts Worldpay\Api\Enums\ChallengeWindowSize sizes
	 */
	public string $challengeWindowSize;
}
