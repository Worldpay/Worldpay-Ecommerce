<?php

namespace Worldpay\Api\Enums;

class PaymentMethod
{
	/**
	 * CARD payment method
	 */
	public const CARD = 'card';

	/**
	 * APPLEPAY payment method
	 */
	public const APPLEPAY = 'applepay';

	/**
	 * GOOGLEPAY payment method
	 */
	public const GOOGLEPAY = 'googlepay';
}
