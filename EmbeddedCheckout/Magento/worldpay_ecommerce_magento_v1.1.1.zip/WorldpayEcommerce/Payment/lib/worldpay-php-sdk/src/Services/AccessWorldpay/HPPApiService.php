<?php

namespace Worldpay\Api\Services\AccessWorldpay;

use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Builders\PaymentManagement\PaymentManagementBuilder;
use Worldpay\Api\Builders\PaymentProcessing\Payload\HPPApiPayloadBuilder;
use Worldpay\Api\Builders\PaymentProcessing\PaymentProcessingBuilder;
use Worldpay\Api\Builders\PaymentQuery\PaymentQueryBuilder;
use Worldpay\Api\Builders\RequestBuilder;
use Worldpay\Api\Enums\PaymentOperation;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Services\PaymentManagementServiceInterface;
use Worldpay\Api\Services\PaymentProcessingServiceInterface;

class HPPApiService
	extends AccessWorldpay
	implements PaymentProcessingServiceInterface, PaymentManagementServiceInterface
{

	/**
	 * Endpoint to setup a HPP payment request.
	 */
	public const PAYMENTS_ENDPOINT = '/payment_pages';

	/**
	 * Headers for HPP payment request.
	 */
	public const HEADER_PAYMENT_PAGES_SETUP_CONTENT_TYPE = 'application/vnd.worldpay.payment_pages-v1.hal+json';
	public const HEADER_PAYMENT_PAGES_SETUP_ACCEPT = 'application/vnd.worldpay.payment_pages-v1.hal+json';

	/**
	 * @var array
	 */
	public static array $supports = [
		PaymentOperation::REFUND,
		PaymentOperation::PARTIAL_REFUND,
	];

	/**
	 * @param  PaymentProcessingBuilder  $paymentProcessingBuilder
	 *
	 * @return ApiResponse
	 * @throws \Exception
	 */
	public static function submitPayment(PaymentProcessingBuilder $paymentProcessingBuilder): ApiResponse {
		$apiConfigProvider = AccessWorldpayConfigProvider::instance();

		$payloadBuilder = new HPPApiPayloadBuilder($paymentProcessingBuilder);

		return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
		                     ->withContentTypeHeader(self::paymentPagesSetupContentTypeHeader())
		                     ->withAcceptHeader(self::paymentPagesSetupAcceptHeader())
		                     ->withBody($payloadBuilder->createPayload())
		                     ->post(self::submitPaymentUrl($apiConfigProvider->environment));
	}

	/**
	 * @param  string  $environment
	 *
	 * @return string
	 */
	public static function submitPaymentUrl(string $environment): string {
		return parent::rootResource($environment) . self::PAYMENTS_ENDPOINT;
	}

	/**
	 * @return string
	 */
	public static function paymentPagesSetupContentTypeHeader(): string {
		return self::HEADER_PAYMENT_PAGES_SETUP_CONTENT_TYPE;
	}

	/**
	 * @return string
	 */
	public static function paymentPagesSetupAcceptHeader(): string {
		return self::HEADER_PAYMENT_PAGES_SETUP_ACCEPT;
	}

	/*
	 * --------------------------------------
	 * Payment Management
	 * --------------------------------------
	 */
	/**
	 * @param  string  $operationType
	 *
	 * @return bool
	 */
	public static function supports(string $operationType): bool {
		return in_array($operationType, self::$supports);
	}

	/**
	 * @param  PaymentManagementBuilder  $paymentManagementBuilder
	 *
	 * @return ApiResponse
	 * @throws ApiException
	 * @throws \Exception
	 */
	public static function refundPayment(PaymentManagementBuilder $paymentManagementBuilder): ApiResponse {
		$apiConfigProvider = AccessWorldpayConfigProvider::instance();
		if (empty($paymentManagementBuilder->transactionReference)) {
			throw new InvalidArgumentException('Provide a transaction reference to find the matching card payment.');
		}

		$refundUrl = self::queryPaymentForRefundUrl($paymentManagementBuilder, 'refund');

		return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
		                     ->withContentTypeHeader(AccessWorldpay::paymentsEventsContentTypeHeader())
		                     ->withAcceptHeader(AccessWorldpay::paymentsEventsAcceptHeader())
		                     ->post($refundUrl);
	}

	/**
	 * @param  PaymentManagementBuilder  $paymentManagementBuilder
	 *
	 * @return ApiResponse
	 * @throws ApiException
	 * @throws InvalidArgumentException
	 */
	public static function partiallyRefundPayment(PaymentManagementBuilder $paymentManagementBuilder): ApiResponse {
		$apiConfigProvider = AccessWorldpayConfigProvider::instance();
		if (empty($paymentManagementBuilder->transactionReference)) {
			throw new InvalidArgumentException('Provide a transaction reference to find the matching card payment.');
		}

		$partialRefundUrl = self::queryPaymentForRefundUrl($paymentManagementBuilder, 'partialRefund');

		return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
		                     ->withContentTypeHeader(AccessWorldpay::paymentsEventsContentTypeHeader())
		                     ->withAcceptHeader(AccessWorldpay::paymentsEventsAcceptHeader())
							 ->withBody($paymentManagementBuilder->createPayload())
		                     ->post($partialRefundUrl);
	}

	/**
	 * @param  PaymentManagementBuilder  $paymentManagementBuilder
	 * @param  string  $refundType
	 *
	 * @return string
	 * @throws ApiException
	 * @throws \Exception
	 */
	private static function queryPaymentForRefundUrl(PaymentManagementBuilder $paymentManagementBuilder, string $refundType): string {
		// Query payment by transaction reference to get payment id
		$paymentQueryBuilder = (new PaymentQueryBuilder())->withTransactionReference($paymentManagementBuilder->transactionReference);
		$apiResponse = PaymentQueriesApiService::queryPayment($paymentQueryBuilder);
		$decodedApiResponse = json_decode($apiResponse->rawResponse, true);
		$paymentUrlWithPaymentId = $decodedApiResponse['_embedded']['payments'][0]['_links']['self']['href'] ?? null;

		if (empty($paymentUrlWithPaymentId)) {
			throw new ApiException('No payments associated with the given parameters.');
		}

		// Query payment by payment id to get refund url
		$paymentQueryBuilder = $paymentQueryBuilder->withPaymentId(explode('/', $paymentUrlWithPaymentId)[3]);
		$apiResponse = PaymentQueriesApiService::queryPaymentByPaymentId($paymentQueryBuilder);
		$decodedApiResponse = json_decode($apiResponse->rawResponse, true);
		$transactionAmount = $decodedApiResponse["value"]["amount"] ?? null;

		if (!isset($transactionAmount)) {
			throw new ApiException('Invalid transaction amount.');
		}

		$partialOrFullRefundUrl = $decodedApiResponse["_links"]["payments:$refundType"]["href"] ?? null;

		if (empty($partialOrFullRefundUrl)) {
		    $partialOrFullRefundUrl = $decodedApiResponse["_links"]["cardPayments:$refundType"]["href"] ?? null;
		}

		if (empty($partialOrFullRefundUrl)) {
			throw new ApiException('Refund is not available.');
		}

		return $partialOrFullRefundUrl;
	}
}
