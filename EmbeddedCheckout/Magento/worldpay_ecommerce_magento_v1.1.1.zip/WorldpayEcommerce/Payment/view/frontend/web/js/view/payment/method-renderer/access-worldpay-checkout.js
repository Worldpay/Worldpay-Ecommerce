define(
    [
        'Magento_Checkout/js/view/payment/default',
        'jquery',
        'Magento_Ui/js/model/messageList',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Customer/js/customer-data'
    ],
    function (Component, $, messageList, fullScreenLoader, customerData) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'WorldpayEcommerce_Payment/payment/access-worldpay-checkout',
                cardBrands: [],
                tryMode: false,
                checkoutSessionHref: null,
                cardHolderName: null,
                redirectAfterPlaceOrder: false,
                deviceDataCollectionSubmitUrl: null,
                deviceDataCollectionFetchUrl: null,
                threeDSChallengeFetchUrl: null,
            },

            initialize: function () {
                this._super();

                let paymentComponent = this;
                let worldpayCheckoutSdkUrl = window.checkoutConfig.payment.access_worldpay_checkout.checkout_sdk_url;
                this.cardBrands = JSON.parse(window.checkoutConfig.payment.access_worldpay_checkout.merchant_card_brands);
                this.tryMode = window.checkoutConfig.payment.access_worldpay_checkout.is_try_mode;
                this.deviceDataCollectionSubmitUrl = window.checkoutConfig.payment.access_worldpay_checkout.device_data_collection_submit_url;
                this.deviceDataCollectionFetchUrl = window.checkoutConfig.payment.access_worldpay_checkout.device_data_collection_fetch_url;
                this.threeDSChallengeFetchUrl = window.checkoutConfig.payment.access_worldpay_checkout.three_ds_fetch_url;

                this.loadStylesheet(require.toUrl('WorldpayEcommerce_Payment/css/access-worldpay-checkout.css'));
                this.loadExternalScript(worldpayCheckoutSdkUrl)
                    .then(() => {
                        require([
                            'WorldpayEcommerce_Payment/js/view/payment/lib/worldpay-ecommerce-checkout-integration'
                        ], function (worldpayEcommerceCheckoutIntegration) {
                            worldpayEcommerceCheckoutIntegration(
                                window.checkoutConfig.payment.access_worldpay_checkout,
                                paymentComponent,
                                messageList,
                                fullScreenLoader,
                                customerData
                            );
                        });
                    });
            },

            loadExternalScript: function (url) {
                return new Promise((resolve, reject) => {
                    let script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.src = url;
                    script.onload = () => resolve();
                    document.head.appendChild(script);
                });
            },

            loadStylesheet: function (href) {
                let link = document.createElement('link');
                link.rel = 'stylesheet';
                link.type = 'text/css';
                link.href = href;
                document.head.appendChild(link);
            },

            getData: function () {
                var data = {
                    'method': this.getCode(),
                    'additional_data': {
                        'checkoutSessionHref': this.checkoutSessionHref,
                        'cardHolderName': this.cardHolderName,
                    }
                };
                return data;
            },

            setAdditionalPaymentInformation: function (checkoutSessionHref, cardHolderName) {
                this.checkoutSessionHref = checkoutSessionHref;
                this.cardHolderName = cardHolderName;
            },

            afterPlaceOrder: function () {
                let methodRender = this;
                fullScreenLoader.startLoader();
                $.ajax({
                    url: this.deviceDataCollectionFetchUrl,
                    type: 'GET',
                    success: function (result) {
                        methodRender.setupDeviceDataCollectionIframe(result['deviceDataCollectionEndpoint']);
                    },
                    error: function () {
                        fullScreenLoader.stopLoader();
                        messageList.addErrorMessage({
                            message: 'Something went wrong while processing your payment. Please try again.',
                            autoHide: false,
                        });
                    }
                });
            },

            setupDeviceDataCollectionIframe: function (deviceDataCollectionEndpoint) {
                $('#access_worldpay_checkout-ddc-iframe').html(
                    '<iframe height="1" width="1" style="display: none;" src="' + deviceDataCollectionEndpoint + '"></iframe>'
                );
            },

            fetch3DSChallengeUrl: function () {
                let methodRender = this;
                $.ajax({
                    url: this.threeDSChallengeFetchUrl,
                    type: 'GET',
                    success: function (result) {
                        fullScreenLoader.stopLoader();
                        if (result['threeDsChallengeWindowSize']) {
                            $('#access_worldpay_checkout-modal').width(result['threeDsChallengeWindowSize'].width);
                            $('#access_worldpay_checkout-modal').height(result['threeDsChallengeWindowSize'].height);
                        }
                        methodRender.setupThreeDSChallengeIframe(result['threeDsEndpoint']);
                    },
                    error: function () {
                        fullScreenLoader.stopLoader();
                        messageList.addErrorMessage({
                            message: 'Something went wrong while processing your payment. Please try again.',
                            autoHide: false,
                        });
                    }
                });
            },

            setupThreeDSChallengeIframe: function (challengeUrl) {
                $('#access_worldpay_checkout-modal').fadeIn();
                $('#access_worldpay_checkout-modal-overlay').fadeIn();
                $('#access_worldpay_checkout-challenge-iframe').html(
                    '<iframe height="100%" width="100%" src="' + challengeUrl + '"></iframe>');
            }
        });
    }
);
