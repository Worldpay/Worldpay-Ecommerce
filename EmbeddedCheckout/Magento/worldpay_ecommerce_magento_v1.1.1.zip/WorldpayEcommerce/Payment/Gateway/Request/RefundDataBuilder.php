<?php

namespace WorldpayEcommerce\Payment\Gateway\Request;

use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Gateway\Helper\SubjectReader;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class RefundDataBuilder implements BuilderInterface
{
    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var SubjectReader
     */
    protected SubjectReader $subjectReader;

    /**
     * Constructor
     *
     * @param  Config         $config
     * @param  SubjectReader  $subjectReader
     */
    public function __construct(
        Config $config,
        SubjectReader $subjectReader
    ) {
        $this->config = $config;
        $this->subjectReader = $subjectReader;
    }

    /**
     * Build request.
     *
     * @param  array  $buildSubject
     * @return array
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        $payment = $paymentDO->getPayment();
        $order = $paymentDO->getOrder();
        $linkDataDetails = $payment->getAdditionalInformation('linkData') ?? [];

        $toReturn = [
            'paymentMethodCode' => $payment->getMethodInstance()->getCode(),
            'refundAmount' => $this->subjectReader->readAmount($buildSubject),
            'orderGrandTotal' => $order->getGrandTotalAmount(),
            'transactionReference' => $payment->getAdditionalInformation('transactionReference') ?? $payment->getAdditionalInformation('transaction_reference'),
            'currency' => $order->getCurrencyCode(),
            'orderIncrementId' => (int) $order->getOrderIncrementId(),
            'orderId' => $order->getId(),
            'paymentLinkData' => $linkDataDetails['linkData'] ?? '',
        ];

        Logger::setDescription("Payload for REFUND request")->debug($toReturn);

        return $toReturn;
    }
}
