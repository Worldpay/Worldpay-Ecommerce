<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\Helper;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceCheckout;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceHpp;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Framework\Locale\Resolver;

class TransactionRefund implements ClientInterface
{
    /**
     * @var WorldpayService
     */
    private WorldpayService $worldpayService;

    /**
     * @var Resolver
     */
    private Resolver $store;

    /**
     * @param  Config  $config
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  Resolver  $store
     * @param  RequestInterface  $request
     *
     * @throws NoSuchEntityException
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig,
        Resolver $store,
        RequestInterface $request
    ) {
        $this->worldpayService = new WorldpayService($config, $scopeConfig, $request);
        $this->store = $store;
    }

    /**
     * Place request.
     *
     * @param  TransferInterface  $transferObject
     * @return array
     * @throws ClientException
     * @throws \Throwable
     * @throws ApiException
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $requestData = $transferObject->getBody();

        if ($requestData['refundAmount'] <= 0) {
            throw new ClientException(__('Refund amount should be greater than zero.'));
        }

        $requestData['partialRefundReference'] = Helper::generateString(12) . '-' . $requestData['orderIncrementId'];

        try {
            $this->worldpayService->setPaymentMethodCode($requestData['paymentMethodCode']);

            switch ($requestData['paymentMethodCode'] ?? '') {
                case PaymentMethodConfig::ACCESS_WORLDPAY_HPP_CODE:
                    $worldpay = new WorldpayEcommerceHpp($this->worldpayService);
                    break;
                case PaymentMethodConfig::ACCESS_WORLDPAY_CHECKOUT_CODE:
                    $worldpay = new WorldpayEcommerceCheckout($this->worldpayService);
                    break;

                default:
                    Throw new ClientException(__('Invalid payment method code.'));
            }

            $isPartialRefund = false;
            if ($requestData['refundAmount'] < $requestData['orderGrandTotal']) {
                $isPartialRefund = true;
            }

            $apiResponse = $worldpay->refund(
                $requestData['transactionReference'],
                $requestData['refundAmount'],
                $requestData['currency'],
                $this->store->getLocale(),
                $requestData['partialRefundReference'],
                $isPartialRefund,
                $requestData['paymentLinkData'] ?? ''
            );

            $dataToLog = [
                'correlationId' => WorldpayService::getWpCorrelationIdFromHeaders($apiResponse->headers),
                'requestData'   => $requestData,
                'response'      => $apiResponse->rawResponse,
                'statusCode'    => $apiResponse->statusCode,
            ];
            if ($apiResponse->isSuccessful()) {
                Logger::setDescription('Refund request successful. Api call response.')->debug($dataToLog);
                return [
                    'refundAmount'           => $requestData['refundAmount'],
                    'partialRefundReference' => $requestData['partialRefundReference']
                ];
            } else {
                Logger::setDescription('Refund request failed. Api call response.')->alert($dataToLog);
                throw new ClientException(__('Something went wrong while requesting payment refund.'));
            }
        } catch (\Throwable $e) {
            Logger::setDescription('Refund request failed. Exception thrown.')->alert([
                'errorMessage' => $e->getMessage(),
                'requestData'  => $requestData
            ]);
            throw $e;
        }
    }
}
