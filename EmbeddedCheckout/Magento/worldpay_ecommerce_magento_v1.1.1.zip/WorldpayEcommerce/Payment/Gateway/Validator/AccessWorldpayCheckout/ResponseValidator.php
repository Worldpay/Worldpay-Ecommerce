<?php

namespace WorldpayEcommerce\Payment\Gateway\Validator\AccessWorldpayCheckout;

use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Worldpay\Api\Exceptions\ApiException;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Failed\FailedOutcome;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeFactory;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class ResponseValidator extends AbstractValidator
{
    /**
     * Validate response.
     *
     * @param  array  $validationSubject
     *
     * @return ResultInterface
     * @throws \Exception
     */
    public function validate(array $validationSubject): ResultInterface
    {
        $response = SubjectReader::readResponse($validationSubject);
        $isValid = true;
        $errorCode = [];
        $apiResponse = $response['payment']['result'];
        $dataToLog = [
            'request'      => $apiResponse->rawRequest ?? '',
            'response'     => $apiResponse->rawResponse ?? ''
        ];
        try {
            if (!$apiResponse->isSuccessful()) {
                throw new ApiException('Payment response is not successful');
            }
            $apiResponse = $apiResponse->jsonDecode();
            if (empty($apiResponse->outcome) || empty($apiResponse->transactionReference)) {
                throw new ApiException('API breach of contract');
            }

            if ( OutcomeFactory::createOutcome($apiResponse->outcome) instanceof FailedOutcome) {
                throw new \Exception('Payment failed');
            }
        } catch (\Exception $e) {
            $dataToLog['message'] = $e->getMessage();
            $isValid = false;
            $errorCode[] = 'payment_failed_try_again_later';
            if ($e instanceof ApiException) {
                Logger::setDescription("Initialize Payment api request failed")->alert($dataToLog);
            } else {
                Logger::setDescription("Payment failed")->debug($dataToLog);
            }
        }

        return $this->createResult($isValid, [], $errorCode);
    }
}
