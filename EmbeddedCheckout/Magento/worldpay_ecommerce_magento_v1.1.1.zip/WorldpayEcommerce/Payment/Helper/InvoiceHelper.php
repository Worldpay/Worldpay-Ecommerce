<?php

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\Order\InvoiceRepository;

class InvoiceHelper
{
    /**
     * @var InvoiceRepository
     */
    protected InvoiceRepository $invoiceRepository;

    /**
     * @param  InvoiceRepository  $invoiceRepository
     */
    public function __construct(InvoiceRepository $invoiceRepository)
    {
        $this->invoiceRepository = $invoiceRepository;
    }

    /**
     * Create invoice.
     *
     * @param  OrderInterface   $order
     * @param  string  $transactionId
     * @return void
     * @throws LocalizedException
     */
    public function createInvoice(OrderInterface $order, string $transactionId): void
    {
        $invoice = $order->prepareInvoice();
        $invoice->getOrder()->setIsInProcess(true);
        $invoice->setTransactionId($transactionId);
        $invoice->register()->pay();

        $this->invoiceRepository->save($invoice);
    }
}
