<?php

namespace WorldpayEcommerce\Payment\Data\Form\Element;

use Magento\Framework\Data\Form\Element\Text;
use WorldpayEcommerce\Payment\Helper\MaskingHelper;

class PartialObscure extends Text
{
    /**
     * Mask all characters except last four.
     *
     * @param string $index
     * @return string
     */
    public function getEscapedValue($index = null)
    {
        $value = parent::getEscapedValue($index);
        if (!empty($value)) {
            return MaskingHelper::maskValueWithLastFour($value);
        }
        return $value;
    }
}
