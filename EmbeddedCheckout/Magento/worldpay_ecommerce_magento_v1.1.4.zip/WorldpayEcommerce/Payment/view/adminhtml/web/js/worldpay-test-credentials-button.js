define('WorldpayEcommerce_Payment/js/worldpay-test-credentials-button',
    [
        'jquery',
        'Magento_Ui/js/modal/modal',
        'mage/translate'
    ], function ($, modal, $t) {
    'use strict';

    return function (config) {
        $(config.buttonSelector).click(function () {
            let data = {};

            config.fieldIds.forEach(function (field) {
                data[field.key] = $(field.selector).val();
            });

            data['app_mode'] = config.appMode;

            $.ajax({
                url: config.url,
                type: 'POST',
                data: data,
                showLoader: true,
                success: function (response) {
                    let title;

                    if (response.success) {
                        title = $t('Worldpay Payment connected successfully');
                    } else {
                        title = $t('Worldpay Payment could not connect');
                    }

                    let options = {
                        title: title,
                        content: response.message,
                        modalClass: 'worldpay-ecommerce-modal',
                        buttons: [{
                            text: 'Close',
                            class: 'action-primary',
                            click: function () {
                                this.closeModal();
                            }
                        }],
                        buttonsAlign: 'center'
                    };

                    let responseModal = modal(options, $('<div></div>').html(response.message));
                    responseModal.openModal();
                }
            });
        });
    };
});
