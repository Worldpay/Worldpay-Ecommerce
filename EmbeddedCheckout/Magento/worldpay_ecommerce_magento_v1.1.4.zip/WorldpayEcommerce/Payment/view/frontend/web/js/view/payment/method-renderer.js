define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'access_worldpay_hpp',
                component: 'WorldpayEcommerce_Payment/js/view/payment/method-renderer/access-worldpay-hpp'
            },
            {
                type: 'access_worldpay_checkout',
                component: 'WorldpayEcommerce_Payment/js/view/payment/method-renderer/access-worldpay-checkout'
            }
        );

        return Component.extend({});
    }
);
