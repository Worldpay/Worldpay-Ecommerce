<?php

namespace WorldpayEcommerce\Payment\Gateway\Request;

use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Helper\Formatter;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Payment\Gateway\Helper\SubjectReader;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class PaymentDataBuilder implements BuilderInterface
{
    use Formatter;

    /**
     * @var Config
     */
    private Config $config;

    /**
     * @var SubjectReader $subjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * Constructor.
     *
     * @param Config $config
     * @param SubjectReader $subjectReader
     */
    public function __construct(Config $config, SubjectReader $subjectReader)
    {
        $this->config = $config;
        $this->subjectReader = $subjectReader;
    }

    /**
     * Build request.
     *
     * @param  array  $buildSubject
     *
     * @return array
     * @throws LocalizedException
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        $order = $paymentDO->getOrder();

        $result = [
            'paymentMethodCode' => $paymentDO->getPayment()->getMethodInstance()->getCode(),
            'orderId' => $order->getOrderIncrementId(),
            'total' => $order->getGrandTotalAmount(),
            'currency_code' => $order->getCurrencyCode(),
            'customer' => $this->getCustomerData($order),
            'billing' => $this->getAddress($order, 'billing'),
            'additionalInformation' => $paymentDO->getPayment()->getAdditionalInformation()
        ];

		$shippingAddress = $this->getAddress($order, 'shipping');

		if (!empty($shippingAddress)) {
			$result['shipping'] = $shippingAddress;
		}

        Logger::setDescription("Payload for Initialize Payment request")->debug($result);

        return $result;
    }

    /**
     * Get address.
     *
     * @param mixed $order
     * @param string $addressType
     * @return array
     */
    protected function getAddress(mixed $order, string $addressType = ''): array
    {
        if (!in_array($addressType, ["billing", "shipping"], true)) {
            return [];
        }

		$addressData = $this->getAddressData($order, $addressType);

		if (!$addressData) {
			return [];
		}

        return $this->formatAddress($addressData);
    }

    /**
     * Get address data based on type.
     *
     * @param mixed $order
     * @param string $addressType
     * @return mixed
     */
    protected function getAddressData(mixed $order, string $addressType): mixed
    {
	    if ($addressType === 'billing') {
		    return $order->getBillingAddress();
	    }

	    if (method_exists($order, 'getIsVirtual') && $order->getIsVirtual()) {
		    return null;
	    }

	    return $order->getShippingAddress();
    }

    /**
     * Format address data into an array.
     *
     * @param mixed $addressData
     * @return array
     */
    protected function formatAddress(mixed $addressData): array
    {
	    if (!$addressData) {
		    return [];
	    }

        return [
            'firstname' => $addressData->getFirstname(),
            'lastname'  => $addressData->getLastname(),
            'email'     => $addressData->getEmail(),
            'telephone' => $addressData->getTelephone(),
            'street'    => $this->getStreet($addressData),
            'city'      => $addressData->getCity(),
            'country'   => $addressData->getCountryId(),
            'postcode'  => $addressData->getPostcode(),
        ];
    }

    /**
     * Get street from address data.
     *
     * @param mixed $addressData
     * @return string
     */
    protected function getStreet(mixed $addressData): string
    {
        if (method_exists($addressData, 'getStreet') && !empty($addressData->getStreet())) {
            return implode(' ', $addressData->getStreet());
        }

        $streetLines = [
            $addressData->getStreetLine1() ?: '',
            $addressData->getStreetLine2() ?: '',
            $addressData->getStreetLine3() ?: '',
            $addressData->getStreetLine4() ?: '',
        ];

        return implode(' ', array_filter(array_map('trim', $streetLines)));
    }

    /**
     * Get customer data.
     *
     * @param mixed $order
     * @return array
     */
    protected function getCustomerData(mixed $order): array
    {
        $billingAddress = $order->getBillingAddress();

        return [
            'firstName'   => $billingAddress->getFirstname(),
            'lastName'    => $billingAddress->getLastname(),
            'email'       => $billingAddress->getEmail(),
            'phoneNumber' => $billingAddress->getTelephone(),
        ];
    }
}
