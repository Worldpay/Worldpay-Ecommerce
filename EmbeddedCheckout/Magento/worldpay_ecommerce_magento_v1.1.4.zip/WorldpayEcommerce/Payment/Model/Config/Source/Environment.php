<?php

namespace WorldpayEcommerce\Payment\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class Environment implements OptionSourceInterface
{
    /**
     * Options getter.
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            ['value' => 'try', 'label' => __('Try')],
            ['value' => 'live', 'label' => __('Live')],
        ];
    }
}
