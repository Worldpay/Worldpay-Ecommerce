<?php

namespace WorldpayEcommerce\Payment\lib\Service;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Worldpay\Api\Utils\Helper;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Filesystem\DirectoryList;

class Logger
{

    /**
     * @var string
     */
    protected static $log_description = "";

    /**
     * @var string
     */
    protected static $type = "";

    /**
     * @var array
     */
    protected static $log_data = [];

    /**
     * @var string
     */
    protected static $log_raw_data = '';

    /**
     * @var string
     */
    protected static $log_file_path = null;

    /**
     * @var int
     */
    protected static $app_debug = 0;

    /**
     * @var string
     */
    protected static $app_mode = "";

    /**
     * DELIMITER_LOG_VARIABLE
     */
    public const DELIMITER_LOG_VARIABLE = " | ";

    /**
     * @var Logger
     */
    private static $instance;

    /**
     * Get instance.
     *
     * @return Logger
     */
    public static function getInstance(): self
    {
        if (!isset(self::$instance)) {
            self::$instance = new static();
        }

        return self::$instance;
    }

    /**
     * Config logger.
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param DirectoryList $dir
     *
     * @return self
     * @throws FileSystemException|NoSuchEntityException
     */
    public static function config(ScopeConfigInterface $scopeConfig, DirectoryList $dir): self
    {
        if (self::$log_file_path === null) {
            self::$log_file_path = $dir->getPath('log').'/worldpay_ecommerce.log';
        }

        self::$app_debug = (int)$scopeConfig->getValue(
            'payment/access_worldpay_hpp/debug',
            ScopeInterface::SCOPE_STORE,
            WorldpayService::getStoreId()
        );
        self::$app_mode = $scopeConfig->getValue(
            'payment/access_worldpay_hpp/app_mode',
            ScopeInterface::SCOPE_STORE,
            WorldpayService::getStoreId()
        );

        return self::getInstance();
    }

    /**
     * Log Magento version.
     *
     * @return void
     */
    public static function logPlatformVersion(): void
    {
        $data = self::getInstallationVersions();

        self::setDescription("Platforms versions")->debug($data);
    }

    /**
     * Set description for log.
     *
     * @param string $log_description
     *
     * @return Logger
     */
    public static function setDescription(string $log_description): self
    {
        self::$log_description = $log_description;

        return self::getInstance();
    }

    /**
     * Log debug.
     *
     * @param array|string $log_data
     *
     * @return Logger
     */
    public static function debug($log_data): self
    {
        if (self::$app_debug == 0) {
            return self::getInstance();
        }

        $log_data = self::formatLog($log_data);

        return self::setLog(LogLevel::DEBUG, $log_data);
    }

    /**
     * Log alert.
     *
     * @param array|string $log_data
     *
     * @return Logger
     */
    public static function alert($log_data): self
    {
        $log_data = self::formatLog($log_data);

        return self::setLog(LogLevel::ALERT, $log_data);
    }

    /**
     * Set log.
     *
     * @param string $type
     * @param array|string $log_data
     *
     * @return Logger
     */
    protected static function setLog(string $type, $log_data): self
    {
        if (empty($type) || empty($log_data)) {
            return self::getInstance();
        }
        self::$type = $type;

        return self::setLogData($log_data)->send();
    }

    /**
     * Set log data.
     *
     * @param array|string $log_data
     *
     * @return Logger
     */
    protected static function setLogData(mixed $log_data): self
    {
        if (is_string($log_data)) {
            self::$log_raw_data .= $log_data;
        }
        if (is_array($log_data)) {
            self::$log_data = array_merge(self::$log_data, $log_data);
        }
        if (\gettype($log_data) == "object") {
            self::$log_data = array_merge(self::$log_data, (array)$log_data);
        }

        return self::getInstance();
    }

    /**
     * Format log data array.
     *
     * @param array $log_data
     * @param ?string $parent_key
     *
     * @return string
     */
    protected static function formatLogDataArray(array $log_data, ?string $parent_key = null): string
    {
        $payload = [];
        foreach ($log_data as $key => $data) {
            if (is_object($data)) {
                $data = (array)$data;
            }
            if (is_array($data)) {
                $payload[] = self::formatLogDataArray($data, $key);
                continue;
            }
            $payload[] = self::formatLogRecord($data, $key, $parent_key);
        }

        return implode(self::DELIMITER_LOG_VARIABLE, $payload);
    }

    /**
     * Form log data record.
     *
     * @param  int|string  $data
     * @param  int|string  $key
     * @param  string|null $parent_key
     *
     * @return string
     */
    public static function formatLogRecord($data, $key, ?string $parent_key): string
    {
        if (null === $data) {
            $data = "NULL";
        }
        $value  = ((is_numeric($data) || $data == "NULL") ? $data : '"' . (string)$data . '"');
        $result = (is_numeric($key)) ? $value : $key . "=" . $value;
        $result = (is_numeric($key) && $parent_key) ? $result = "=" . $result : $result;

        if ($parent_key) {
            $result = str_replace(
                " ",
                "",
                lcfirst(ucwords($parent_key))
            ) . ucfirst($result);
        }

        return $result;
    }

    /**
     * Format log data raw.
     *
     * @return string
     */
    protected static function formatLogDataRow(): string
    {
        $prepend_log_data = strtoupper(self::$type);

        if (!empty(self::$log_description)) {
            self::$log_data = array_merge(["detailMessage" => self::$log_description], self::$log_data);
        }

        if (!empty(self::$log_raw_data)) {
            self::$log_data = array_merge(self::$log_data, [self::$log_raw_data]);
        }

        return $prepend_log_data . self::DELIMITER_LOG_VARIABLE . self::formatLogDataArray(self::$log_data);
    }

    /**
     * Send buffer to log file.
     *
     * @return Logger
     */
    protected static function send(): self
    {
        file_put_contents(self::$log_file_path, date("Y-m-d H:i:s")." ".self::formatLogDataRow().PHP_EOL, FILE_APPEND);

        self::clearStoredData();

        return self::getInstance();
    }

    /**
     * Cleared stored data.
     *
     * @return void
     */
    protected static function clearStoredData(): void
    {
        self::$type = "";
        self::$log_description = "";
        self::$log_data = [];
    }

    /**
     * Get Magento installed version.
     *
     * @return array
     */
    protected static function getInstallationVersions(): array
    {
        $objectManager = ObjectManager::getInstance();
        $productMetadata = $objectManager->get(ProductMetadataInterface::class);

        return [
            "platform_edition" => $productMetadata->getEdition(),
            "platform_version" => $productMetadata->getVersion(),
            "php_version" => PHP_VERSION,
            "plugin_version" => WorldpayService::PLUGIN_VERSION
        ];
    }

    /**
     * Format log.
     *
     * @param  array|string  $log_data
     *
     * @return string[]
     */
    public static function formatLog($log_data): array
    {
        if (is_array($log_data)) {
            $log_data = Helper::cleanArray($log_data);
        } else {
            $log_data = [$log_data];
        }

        return array_merge(["app_mode" => self::$app_mode], $log_data);
    }
}
