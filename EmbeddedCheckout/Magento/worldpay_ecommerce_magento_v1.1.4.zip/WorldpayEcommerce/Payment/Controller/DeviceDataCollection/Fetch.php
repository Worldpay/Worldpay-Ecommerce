<?php

namespace WorldpayEcommerce\Payment\Controller\DeviceDataCollection;


use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\ResultInterface;
use Worldpay\Api\Enums\PaymentStatus;
use WorldpayEcommerce\Payment\Controller\PaymentActions\FetchAction;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;

class Fetch extends FetchAction
{
    /**
     * @return Json|ResultInterface|ResponseInterface
     */
    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        if (!$this->requestInterface->isGet()) {
            Logger::setDescription('Fetch local device data collection local endpoint failed')->alert(
                [
                    'message' => 'Wrong HTTP method.'
                ]
            );

            return $resultJson->setData(['error' => true]);
        }
        $order = $this->checkoutSession->getLastRealOrder();
        if (! $order->getId()) {
            Logger::setDescription('Fetch local device data collection local endpoint failed')->alert(
                [
                    'message' => 'Order does not exist.'
                ]
            );

            return $resultJson->setData(['error' => true]);
        }

        $orderPayment = $order->getPayment();
        if ($orderPayment === null || $orderPayment->getMethod() != PaymentMethodConfig::ACCESS_WORLDPAY_CHECKOUT_CODE
            || $orderPayment->getAdditionalInformation('paymentOutcome') != PaymentStatus::THREE_DS_DEVICE_DATA_REQUIRED
        ) {
            Logger::setDescription('Fetch local device data collection local endpoint failed')->alert(
                [
                    'empty_order_payment' => (int)is_null($orderPayment),
                    'payment_method_code' => $orderPayment->getMethod() ?? '',
                    'payment_result_outcome' => $orderPayment->getAdditionalInformation('paymentOutcome') ?? '',
                    'message' => 'Payment method outcome not defined or order payment is not defined or wrong payment method code.'
                ]
            );

            return $resultJson->setData(['error' => true]);
        }

        $deviceDataCollectionEndpoint = $orderPayment->getAdditionalInformation('deviceDataCollectionEndpoint');
        if ($deviceDataCollectionEndpoint === null) {
            Logger::setDescription('Fetch local device data collection local endpoint failed')->alert(
                [
                    'message' => 'deviceDataCollectionEndpoint is not defined.'
                ]
            );

            return $resultJson->setData(['error' => true]);
        }

        return $resultJson->setData(['success' => true, 'deviceDataCollectionEndpoint' => $deviceDataCollectionEndpoint]);
    }
}
