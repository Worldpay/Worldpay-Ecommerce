<?php

namespace WorldpayEcommerce\Payment\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;

class AssignPaymentAdditionalData implements ObserverInterface
{

    /**
     * Execute event.
     *
     * @param  Observer  $observer
     *
     * @return void
     */
    public function execute(Observer $observer)
    {
        if ($observer->getEvent()->getData('data')->getMethod() !== PaymentMethodConfig::ACCESS_WORLDPAY_CHECKOUT_CODE) {
            return;
        }
        $paymentMethod = $observer->getEvent()->getData('payment_model');
        $paymentData = $observer->getEvent()->getData('data');
        $paymentAdditionalInformation = $paymentData->getData('additional_data');
        if (empty($paymentAdditionalInformation)) {
            return;
        }
        $paymentMethod->setAdditionalInformation($paymentAdditionalInformation);
    }
}
