<?php

namespace WorldpayEcommerce\Payment\Gateway\Data;

use Magento\Payment\Gateway\Data\Order\AddressAdapter as MagentoAddressAdapter;
use Magento\Sales\Api\Data\OrderAddressInterface;

class AddressAdapter extends MagentoAddressAdapter
{

    /**
     * @var OrderAddressInterface
     */
    private OrderAddressInterface $address;

    /**
     * @param  OrderAddressInterface  $address
     */
    public function __construct(OrderAddressInterface $address)
    {
        $this->address = $address;
        parent::__construct($address);
    }

    /**
     * @return string
     */
    public function getStreetLine3(): string
    {
        $street = $this->address->getStreet();
        return $street[2] ?? '';
    }

    /**
     * @return string
     */
    public function getStreetLine4(): string
    {
        $street = $this->address->getStreet();
        return $street[3] ?? '';
    }
}
