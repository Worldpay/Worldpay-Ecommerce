<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client\AccessWorldpayCheckout;

use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\TransferInterface;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use WorldpayEcommerce\Payment\Gateway\Http\Client\AbstractClient;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceCheckout;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

class TransactionInitialize extends AbstractClient
{

    /**
     * Place request.
     *
     * @param  TransferInterface  $transferObject
     *
     * @return array
     * @throws ClientException
     */
    public function placeRequest(TransferInterface $transferObject): array
    {
        $this->requestData              = $transferObject->getBody();
        $this->requestData['locale']    = $this->store->getLocale();
        $dataToLog                = [];
        $dataToLog['requestData'] = $this->requestData;
        $apiResponse = null;

        try {
            $this->worldpayService->setPaymentMethodCode($this->requestData['paymentMethodCode']);
            $this->setTransactionReference();
            $this->setThreeDSChallengeReturnUrl();
            $this->output['payment']['result'] = $this->sendApiRequest();
            $this->output['payment']['paymentEnv'] = $this->worldpayService->getApiEnvironment();
            $dataToLog['apiResponse'] = $this->output['payment']['result']->rawResponse ?? '';
            Logger::setDescription("Initialize Payment Request & Response")->debug($dataToLog);
        } catch (\Exception $e) {
            $message = __($e->getMessage() ?: 'Sorry, but something went wrong');
            $dataToLog['errorMessage'] = $e->getMessage();
            if ($apiResponse) {
                $dataToLog['request'] = $apiResponse->rawRequest ?? '';
                $dataToLog['response'] = $apiResponse->rawResponse ?? '';
                $dataToLog['correlationId'] = $apiResponse->headers
                    ? WorldpayService::getWpCorrelationIdFromHeaders( $apiResponse->headers ) : '';
            }
            Logger::setDescription("Initialize Payment failed")->alert($dataToLog);
            throw new ClientException($message);
        }

        return $this->output;
    }

    /**
     * @throws InvalidArgumentException
     * @throws ApiClientException
     * @throws AuthenticationException
     * @throws \Exception
     */
    protected function sendApiRequest(): ApiResponse
    {
        return (new WorldpayEcommerceCheckout($this->worldpayService, $this->requestData))->initializePayment();
    }

    /**
     * @return void
     * @throws LocalizedException
     */
    protected function setThreeDSChallengeReturnUrl(): void
    {
        $this->requestData['threeDSChallengeReturnUrl'] = $this->url->getUrl('access_worldpay_hpp/threeDsChallenge/submit/' );
    }
}
