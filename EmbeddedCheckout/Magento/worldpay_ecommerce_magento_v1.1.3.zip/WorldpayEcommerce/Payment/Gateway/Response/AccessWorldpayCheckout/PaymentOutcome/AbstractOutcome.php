<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome;

use Magento\Framework\UrlInterface;
use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\SessionFactory;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Model\QuoteManagement;


abstract class AbstractOutcome implements OutcomeInterface
{

    /**
     * @var string
     */
    protected string $outcome;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlInterface;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepositoryInterface;

    /**
     * @var CartRepositoryInterface
     */
    protected CartRepositoryInterface $cartRepositoryInterface;

    /**
     * @var Session
     */
    protected Session $session;

    /**
     * @var TransactionHelper
     */
    protected TransactionHelper $transactionHelper;

    /**
     * @var InvoiceHelper
     */
    protected InvoiceHelper $invoiceHelper;

    /**
     * @var OrderSender
     */
    protected OrderSender $orderSender;

    protected QuoteIdMaskFactory $quoteIdMaskFactory;

    protected QuoteManagement $quoteManagement;

    /**
     * @param  InfoInterface  $payment
     * @param  object  $response
     *
     * @return void
     */
    abstract public function setPaymentLinks(InfoInterface $payment, object $response): void;

    /**
     * @param  Order  $order
     *
     * @return void
     */
    abstract public function handleOrder(Order $order): void;

    /**
     * @param  string  $outcome
     */
    public function __construct(string $outcome)
    {
        $this->outcome = $outcome;
    }

    public function setQuoteManagement(QuoteManagement $quoteManagement)
    {
        $this->quoteManagement = $quoteManagement;
    }

    public function setQuoteIdMaskFactory(QuoteIdMaskFactory $quoteIdMaskFactory)
    {
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
    }

    /**
     * @param  UrlInterface  $urlInterface
     *
     * @return void
     */
    public function setUrlInterface(UrlInterface $urlInterface): void
    {
        $this->urlInterface = $urlInterface;
    }

    /**
     * @param  TransactionHelper  $transactionHelper
     *
     * @return void
     */
    public function setTransactionHelper(TransactionHelper $transactionHelper): void
    {
        $this->transactionHelper = $transactionHelper;
    }

    /**
     * @param  Session  $session
     *
     * @return void
     */
    public function setSession(Session $session): void
    {
        $this->session = $session;
    }

    /**
     * @param  OrderRepositoryInterface  $orderRepositoryInterface
     *
     * @return void
     */
    public function setOrderRepositoryInterface(OrderRepositoryInterface $orderRepositoryInterface): void
    {
        $this->orderRepositoryInterface = $orderRepositoryInterface;
    }

    /**
     * @param  CartRepositoryInterface  $cartRepositoryInterface
     *
     * @return void
     */
    public function setCartRepositoryInterface(CartRepositoryInterface $cartRepositoryInterface)
    {
        $this->cartRepositoryInterface = $cartRepositoryInterface;
    }

    /**
     * @param  InvoiceHelper  $invoiceHelper
     *
     * @return void
     */
    public function setInvoiceHelper(InvoiceHelper $invoiceHelper): void
    {
        $this->invoiceHelper = $invoiceHelper;
    }

    /**
     * @param  OrderSender  $orderSender
     *
     * @return void
     */
    public function setOrderSender(OrderSender $orderSender): void
    {
        $this->orderSender = $orderSender;
    }

    /**
     * @param  InfoInterface  $payment
     * @param  object  $response
     *
     * @return void
     */
    public function handlePayment(InfoInterface $payment, object $response): void
    {
        if ($payment->getAdditionalInformation('paymentOutcome')) {
            $payment->unsAdditionalInformation('paymentOutcome');
        }
        if (!$payment->getAdditionalInformation('transactionReference')) {
            $payment->setAdditionalInformation('transactionReference', $response->transactionReference);
        }
        $payment->setAdditionalInformation('paymentOutcome', $response->outcome);
        $this->setPaymentLinks($payment, $response);
    }
}
