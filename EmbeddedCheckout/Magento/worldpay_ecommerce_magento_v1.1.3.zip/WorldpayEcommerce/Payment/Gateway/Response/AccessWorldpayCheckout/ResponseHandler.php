<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout;

use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Framework\UrlInterface;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeFactory;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class ResponseHandler implements HandlerInterface
{

    /**
     * @var SubjectReader
     */
    protected SubjectReader $subjectReader;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlInterface;

    /**
     * Constructor
     *
     * @param  SubjectReader  $subjectReader
     * @param  UrlInterface  $urlInterface
     */
    public function __construct(SubjectReader $subjectReader, UrlInterface $urlInterface)
    {
        $this->subjectReader = $subjectReader;
        $this->urlInterface = $urlInterface;
    }

    /**
     * Handle response.
     *
     * @param  array  $handlingSubject
     * @param  array  $response
     *
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDataObject = $this->subjectReader->readPayment($handlingSubject);
        $payment = $paymentDataObject->getPayment();

        $apiResponse = $response['payment']['result']->jsonDecode();

        try {
            $payment->setAdditionalInformation('paymentEnv', $response['payment']['paymentEnv'] ?? '');
            $paymentOutcome = OutcomeFactory::createOutcome($apiResponse->outcome);
            $paymentOutcome->setUrlInterface($this->urlInterface);
            $paymentOutcome->handlePayment($payment, $apiResponse);
        } catch (\Exception $e) {
            $dataToLog = [
                'message' => $e->getMessage(),
                'apiResponse' => $apiResponse->rawResponse ?? '',
                'apiRequest' => $apiResponse->rawRequest ?? '',
            ];
            Logger::setDescription('Unknown payment outcome in response handler')->alert($dataToLog);
        }
    }
}
