<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome;

use Worldpay\Api\Enums\PaymentStatus;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Failed\FailedOutcome;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Pending\PendingOutcome;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Successful\SuccessfulOutcome;

class OutcomeFactory
{
    /**
     * @param  string  $paymentResponseOutcome
     *
     * @return OutcomeInterface
     * @throws \Exception
     */
    public static function createOutcome(string $paymentResponseOutcome): OutcomeInterface
    {
        $paymentOutcome = null;
        switch ($paymentResponseOutcome) {
            case PaymentStatus::SENT_FOR_SETTLEMENT:
            case PaymentStatus::AUTHORIZED:
                $paymentOutcome = new SuccessfulOutcome($paymentResponseOutcome);
                break;
            case PaymentStatus::THREE_DS_DEVICE_DATA_REQUIRED:
            case PaymentStatus::THREE_DS_CHALLENGED:
                $paymentOutcome = new PendingOutcome($paymentResponseOutcome);
                break;
            case PaymentStatus::FRAUD_HIGH_RISK:
            case PaymentStatus::SENT_FOR_CANCELLATION:
            case PaymentStatus::REFUSED:
            case PaymentStatus::THREE_DS_UNAVAILABLE:
            case PaymentStatus::THREE_DS_AUTHENTICATION_FAILED:
                $paymentOutcome = new FailedOutcome($paymentResponseOutcome);
                break;
            default:
                throw new \Exception('Unknown payment method response outcome.');
        }

        return $paymentOutcome;
    }
}
