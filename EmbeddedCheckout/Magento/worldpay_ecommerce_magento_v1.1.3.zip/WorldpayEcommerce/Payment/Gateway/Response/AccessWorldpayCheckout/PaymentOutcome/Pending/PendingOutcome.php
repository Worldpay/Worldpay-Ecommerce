<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Pending;

use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Model\Order;
use Worldpay\Api\Enums\PaymentStatus;
use Worldpay\Api\Enums\ChallengeWindowSize;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\AbstractOutcome;

class PendingOutcome extends AbstractOutcome
{

    /**
     * @param  InfoInterface  $payment
     * @param  object  $response
     *
     * @return void
     */
    public function setPaymentLinks(InfoInterface $payment, object $response): void
    {
        if ($this->outcome === PaymentStatus::THREE_DS_DEVICE_DATA_REQUIRED) {
            $payment->setAdditionalInformation('deviceDataCollectionSubmissionEndpoint',
                $response->_actions->supply3dsDeviceData->href ?? '');
            $payment->setAdditionalInformation('deviceDataCollectionEndpoint',
                $this->getDeviceDataCollectionUrl($response) ?? '');
        } else if ($this->outcome === PaymentStatus::THREE_DS_CHALLENGED) {
            $payment->setAdditionalInformation('threeDsSubmissionEndpoint',
                $response->_actions->complete3dsChallenge->href ?? '');
            $payment->setAdditionalInformation('threeDsEndpoint',
                $this->getThreeDSUrl($payment, $response) ?? '');
            $payment->setAdditionalInformation('threeDsChallengeWindowSize', $this->getChallengeWindowSize($response->challenge->payload ?? ''));
        }
    }

    /**
     * @param  Order  $order
     *
     * @return void
     */
    public function handleOrder(Order $order): void
    {
        if ($this->outcome === PaymentStatus::THREE_DS_DEVICE_DATA_REQUIRED) {
            $payment = $order->getPayment();
            $order->addCommentToStatusHistory(
                sprintf(__('%s awaiting payment via Worldpay. Transaction reference: %s')->render(),
                    $payment->formatPrice($order->getGrandTotal()),
                    $payment->getAdditionalInformation('transactionReference'))
            );
            $order->setCanSendNewEmailFlag(false);
            $order->setState(Order::STATE_PENDING_PAYMENT);
            $order->setStatus(Order::STATE_PENDING_PAYMENT);
            $order->getPayment()->setIsTransactionPending(true);
            $order->getPayment()->setIsTransactionClosed(false);
        }
        $this->orderRepositoryInterface->save($order);
    }


    /**
     * @param  object  $response
     *
     * @return string
     */
    protected function getDeviceDataCollectionUrl(object $response): string
    {
        return $this->urlInterface->getUrl(
            'access_worldpay_hpp/deviceDataCollection/handle',
            [
                '_query' => [
                    'jwt' => $response->deviceDataCollection->jwt ?? '',
                    'url' => $response->deviceDataCollection->url ?? '',
                    'bin' => $response->deviceDataCollection->bin ?? '',
                ]
            ]
        );
    }

    /**
     * @param  InfoInterface  $payment
     * @param  object  $response
     *
     * @return string
     */
    protected function getThreeDSUrl(InfoInterface $payment, object $response): string
    {
        $transactionReference = $payment->getAdditionalInformation('transactionReference');
        $orderIncrementId = explode('_', $transactionReference)[1];
        return $this->urlInterface->getUrl(
            'access_worldpay_hpp/threeDsChallenge/handle',
            [
                '_query' => [
                    'reference' => $response->challenge->reference ?? '',
                    'url' => $response->challenge->url ?? '',
                    'jwt' => $response->challenge->jwt ?? '',
                    'payload' => $response->challenge->payload ?? '',
                    'hash' => base64_encode($orderIncrementId),
                ]
            ]
        );
    }

    /**
     * @param  string  $response
     *
     * @return array|int[]|mixed
     */
    protected function getChallengeWindowSize(string $response): mixed
    {
        $challengeWindowSize = array();

        if (empty($response)) {
            return $challengeWindowSize;
        }

        $response = base64_decode($response);
        if (empty($response)) {
            return $challengeWindowSize;
        }

        $response = json_decode($response,true);
        if (empty($response)) {
            return $challengeWindowSize;
        }

        $challengeWindowMode = $response['challengeWindowSize'] ?? '';
        if (empty($challengeWindowMode)) {
            return $challengeWindowSize;
        }

        $challengeWindowSize = ChallengeWindowSize::$challengeWindowSizeMapping[$challengeWindowMode] ?? [];
        if ('05' === $challengeWindowMode || '5' === $challengeWindowMode) {
            $challengeWindowSize = [
                'width'  => 600,
                'height' => 700,
            ];
        }

        return $challengeWindowSize;
    }
}
