<?php

namespace WorldpayEcommerce\Payment\Model\Config\Source;

use Magento\Framework\Data\OptionSourceInterface;

class CardBrands implements OptionSourceInterface
{
    /**
     * Options getter.
     *
     * @return array
     */
    public function toOptionArray(): array
    {
        return [
            ['value' => "visa", 'label' => __('Visa')],
            ['value' => "mastercard", 'label' => __('Mastercard')],
            ['value' => "amex", 'label' => __('American Express')],
        ];
    }
}
