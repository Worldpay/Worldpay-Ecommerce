<?php

namespace WorldpayEcommerce\Payment\Model\Ui;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Store\Model\StoreManagerInterface;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Enums\Environment;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

class CheckoutConfigProvider implements ConfigProviderInterface
{
    /**
     * @var WorldpayService
     */
    private WorldpayService $worldpayService;

    /**
     * @var UrlInterface
     */
    private UrlInterface $urlInterface;

    /**
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     * @param RequestInterface $request
     * @param UrlInterface $urlInterface
     * @param ProductMetadataInterface $productMetadata
     * @param StoreManagerInterface $storeManager
     *
     * @throws NoSuchEntityException
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig,
        RequestInterface $request,
        UrlInterface $urlInterface,
        ProductMetadataInterface $productMetadata,
        StoreManagerInterface $storeManager
    ) {
        $this->worldpayService = new WorldpayService(
            $config,
            $scopeConfig,
            $request,
            $productMetadata,
            $storeManager,
            $config->getMethodCode()
        );
        $this->urlInterface = $urlInterface;
    }

    /**
     * @inheritDoc
     */
    public function getConfig(): array
    {
        return [
            'payment' => [
                Config::ACCESS_WORLDPAY_CHECKOUT_CODE => [
                    'merchant_checkout_id' => $this->worldpayService->getMerchantCheckoutId(),
                    'merchant_card_brands' => $this->getCardBrands(),
                    'checkout_sdk_url'     => AccessWorldpay::checkoutSdkUrl($this->worldpayService->getApiEnvironment()),
                    'access_worldpay_checkout_code' => Config::ACCESS_WORLDPAY_CHECKOUT_CODE,
                    'is_try_mode'          => $this->worldpayService->getApiEnvironment() === Environment::TRY_MODE,
                    'device_data_collection_third_party_app_url' => $this->worldpayService->getApiEnvironment() === Environment::TRY_MODE ? AccessWorldpay::TRY_CARDINAL_URL : AccessWorldpay::LIVE_CARDINAL_URL,
                    'device_data_collection_fetch_url' => $this->urlInterface->getUrl('access_worldpay_hpp/deviceDataCollection/fetch'),
                    'device_data_collection_submit_url' => $this->urlInterface->getUrl('access_worldpay_hpp/deviceDataCollection/submit'),
                    'three_ds_fetch_url' => $this->urlInterface->getUrl('access_worldpay_hpp/threeDsChallenge/fetch'),
                ],
            ],
        ];
    }

    /**
     * @return string
     */
    private function getCardBrands(): string
    {
        $cardBrandsArr = [];
        $cardBrands = $this->worldpayService->getMerchantCheckoutCardBrands();
        if ($cardBrands) {
            $cardBrandsArr = str_contains($cardBrands, ',') ? explode(',', $cardBrands) : [$cardBrands];
        }
        $cardBrandsArr = array_map('trim', $cardBrandsArr);

        return json_encode($cardBrandsArr);
    }
}
