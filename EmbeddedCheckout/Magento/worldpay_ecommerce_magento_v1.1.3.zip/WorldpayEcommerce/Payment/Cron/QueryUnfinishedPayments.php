<?php

namespace WorldpayEcommerce\Payment\Cron;

use http\Env;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\ResourceModel\Order\Collection;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Enums\PaymentEvent;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceHpp;

class QueryUnfinishedPayments
{
    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var Collection
     */
    protected Collection $orderCollection;

    /**
     * @var WorldpayEcommerceHpp
     */
    protected WorldpayEcommerceHpp $worldpayEcommerce;

    /**
     * @var TransactionHelper
     */
    protected TransactionHelper $transactionHelper;

    /**
     * @var InvoiceHelper
     */
    protected InvoiceHelper $invoiceHelper;

    /**
     * @var OrderSender
     */
    protected OrderSender $orderSender;

    /**
     * @var string
     */
    protected string $startDateTime;

    /**
     * @var string
     */
    protected string $endDateTime ;

    /**
     * HPP try domains.
     */
    protected const TRY_HPP_URLS_DOMAINS = [
        'https://hpp-sandbox.worldpay.com',
        'https://payments-test.worldpay.com'
    ];

    /**
     * @var array
     */
    protected array $transactionSuccessStatuses = [
        PaymentEvent::SALE_SUCCEEDED,
        PaymentEvent::SETTLEMENT_REQUEST_SUBMITTED,
    ];

    /**
     * @var array
     */
    protected array $transactionFailedStatuses = [
        PaymentEvent::AUTHORIZATION_REFUSED,
        PaymentEvent::AUTHORIZATION_FAILED,
        PaymentEvent::AUTHORIZATION_TIMED_OUT,
        PaymentEvent::CANCELLATION_REQUEST_SUBMITTED,
        PaymentEvent::SALE_REFUSED,
        PaymentEvent::SALE_FAILED,
        PaymentEvent::SALE_TIMED_OUT,
        PaymentEvent::SETTLEMENT_REQUEST_SUBMISSION_FAILED,
        PaymentEvent::SETTLEMENT_REQUEST_SUBMISSION_TIMED_OUT,
    ];

    /**
     * @param  OrderRepositoryInterface  $orderRepository
     * @param  Collection  $orderCollection
     * @param  WorldpayEcommerceHpp  $worldpayEcommerce
     * @param  TransactionHelper  $transactionHelper
     * @param  InvoiceHelper  $invoiceHelper
     * @param  OrderSender  $orderSender
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList  $dir
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        OrderRepositoryInterface $orderRepository,
        Collection $orderCollection,
        WorldpayEcommerceHpp $worldpayEcommerce,
        TransactionHelper $transactionHelper,
        InvoiceHelper $invoiceHelper,
        OrderSender $orderSender,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir,
    )
    {
        $this->orderRepository = $orderRepository;
        $this->orderCollection = $orderCollection;
        $this->worldpayEcommerce = $worldpayEcommerce;
        $this->transactionHelper = $transactionHelper;
        $this->invoiceHelper = $invoiceHelper;
        $this->orderSender = $orderSender;
        Logger::config($scopeConfig, $dir);
        $this->startDateTime  = (new \DateTime())->modify('-70 minutes')->format('Y-m-d\TH:i:s\Z');
        $this->endDateTime  = (new \DateTime())->modify('-5 minutes')->format('Y-m-d\TH:i:s\Z');
    }

    /**
     * @return void
     */
    public function execute()
    {
        $pendingUpdateOrders = [];
        try {
            $pendingPaymentOrders = $this->getPendingPaymentOrders();
            $pendingPaymentOrdersData = $this->getIncompleteTransactionsData($pendingPaymentOrders);
            foreach ([Environment::LIVE_MODE, Environment::TRY_MODE] as $env) {
                if (empty($pendingPaymentOrdersData[$env])) {
                    continue;
                }
                $transactionsBatchData = $this->queryTransactionsBatchByDateRange($env);
                if (empty($transactionsBatchData)) {
                    continue;
                }
                foreach ($transactionsBatchData as $transaction) {
                    if (isset($pendingPaymentOrdersData[$env][$transaction->transactionReference])) {
                        $transactionData = $this->queryTransactionByPaymentId($env, $transaction->_links->self->href);
                        if (!empty($transactionData)) {
                            $orderId = $pendingPaymentOrdersData[$env][$transaction->transactionReference]['orderId'];
                            $lastEventReceived = $this->getLastEventReceived($transactionData);
                            if (in_array($lastEventReceived, $this->transactionSuccessStatuses)) {
                                $pendingUpdateOrders[$orderId]['transactionReference'] = $transaction->transactionReference;
                                $pendingUpdateOrders[$orderId]['lastEvent'] = $lastEventReceived;
                                $pendingUpdateOrders[$orderId]['newStatus'] = Order::STATE_PROCESSING;
                            } elseif (in_array($lastEventReceived, $this->transactionFailedStatuses)) {
                                $pendingUpdateOrders[$orderId]['transactionReference'] = $transaction->transactionReference;
                                $pendingUpdateOrders[$orderId]['lastEvent'] = $lastEventReceived;
                                $pendingUpdateOrders[$orderId]['newStatus'] = Order::STATE_CANCELED;
                            }
                        }
                    }
                }
            }
            $this->updatePendingPaymentOrders($pendingUpdateOrders);
        } catch (\Throwable $e) {
            Logger::setDescription('Cron - Reconcile orders failed.')->alert([
                'errorMessage' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }
    }

    /**
     * @return Collection
     * @throws InputException
     */
    public function getPendingPaymentOrders(): Collection
    {
        $this->orderCollection->addFieldToSelect([
            OrderInterface::ENTITY_ID,
            OrderInterface::STATE,
            OrderInterface::STATUS,
            OrderInterface::STORE_ID,
            OrderInterface::CREATED_AT,
            OrderInterface::UPDATED_AT,
        ]);
        $this->orderCollection->addFilter(OrderInterface::STATE, Order::STATE_PENDING_PAYMENT);
        $this->orderCollection->addFieldToFilter(OrderInterface::CREATED_AT, ['lteq' => $this->endDateTime ]);
        $this->orderCollection->addFieldToFilter(OrderInterface::CREATED_AT, ['gteq' => $this->startDateTime ]);
        $sortOrder = new SortOrder();
        $sortOrder->setField(OrderInterface::CREATED_AT)
                  ->setDirection('ASC');

        $this->orderCollection->getSelect()
                              ->join(
                                  ['payment' => 'sales_order_payment'],
                                  'main_table.entity_id = payment.parent_id',
                                  ['method']
                              )
                              ->where('payment.method IN (?)', [Config::ACCESS_WORLDPAY_HPP_CODE, Config::ACCESS_WORLDPAY_CHECKOUT_CODE])
                              ->order('main_table.created_at ASC');

        return $this->orderCollection;
    }

    /**
     * @param  Collection  $pendingPaymentOrders
     *
     * @return array
     */
    public function getIncompleteTransactionsData(Collection $pendingPaymentOrders): array
    {
        $incompleteTransactions = [];
        foreach ($pendingPaymentOrders as $order) {
            $payment = $order->getPayment();
            $additionalInformation = $payment->getAdditionalInformation();

            if (empty($additionalInformation['transaction_reference']) && empty($additionalInformation['transactionReference'])) {
                continue;
            }

            $transactionReference = isset($additionalInformation['transaction_reference']) ? $additionalInformation['transaction_reference'] : $additionalInformation['transactionReference'];
            $incompleteTransactions[$this->getTransactionEnvironment($additionalInformation)][$transactionReference] = [
                'orderId' => $order->getId(),
            ];
        }

        return $incompleteTransactions;
    }

    /**
     * @param  string  $env
     *
     * @return array
     */
    public function queryTransactionsBatchByDateRange(string $env): array
    {
        $transactionsBatch = [];
        try {
            $apiResponse = $this->worldpayEcommerce->queryPayments(
                $env,
                $this->startDateTime,
                $this->endDateTime,
                300,
                $this->getEventsFilter(),
            );
            if (!$apiResponse->isSuccessful()) {
                throw new \Exception($apiResponse->rawResponse);
            }
            $decodedApiResponse = $apiResponse->jsonDecode();
            $transactionsBatch = $decodedApiResponse->_embedded->payments;
        } catch (\Throwable $e) {
            Logger::setDescription('Cron - query transactions batch failed.')->alert([
                'queryEnvironment' => $env,
                'errorMessage' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }

        return $transactionsBatch;
    }

    /**
     * @param  string  $env
     * @param  string  $paymentId
     *
     * @return array
     */
    public function queryTransactionByPaymentId(string $env, string $paymentId): array
    {
        $transactionData = [];
        $paymentId = explode('/', $paymentId)[3];
        try {
            $apiResponse = $this->worldpayEcommerce->queryPaymentByPaymentId($env, $paymentId);
            if (!$apiResponse->isSuccessful()) {
                throw new \Exception($apiResponse->rawResponse);
            }
            $transactionData = $apiResponse->jsonDecode(true);
        } catch (\Throwable $e) {
            Logger::setDescription('Cron - query transaction failed.')->alert([
                'queryEnvironment' => $env,
                'paymentId' => $paymentId,
                'errorMessage' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ]);
        }

        return $transactionData;
    }

    /**
     * @param $pendingUpdateOrders
     *
     * @return void
     * @throws LocalizedException
     */
    public function updatePendingPaymentOrders($pendingUpdateOrders): void
    {
        foreach ($pendingUpdateOrders as $orderId => $orderData) {
            $order = $this->orderRepository->get($orderId);
            $dataToLog['orderId'] = $orderId;
            if ($order->getState() != Order::STATE_PENDING_PAYMENT) {
                Logger::setDescription('Cron - order already updated')->debug($dataToLog);
                continue;
            }
            $payment = $order->getPayment();
            $dataToLog = $orderData;
            $dataToLog = array_merge($dataToLog, $orderData);
            Logger::setDescription('Cron - order update')->debug($dataToLog);

            $order->setState($orderData['newStatus']);
            $order->setStatus($orderData['newStatus']);
            $payment->setAdditionalInformation('lastEventReceived', $orderData['lastEvent']);

            if ($orderData['newStatus'] == Order::STATE_PROCESSING) {
                $order->addCommentToStatusHistory(__(
                    'Payment successful via Worldpay. Transaction reference: %1',
                    $orderData['transactionReference']
                ));
                $this->transactionHelper->createTransaction(
                    $order,
                    $payment,
                    $orderData['transactionReference']
                );
                $this->invoiceHelper->createInvoice($order, $orderData['transactionReference']);
                $order->setCanSendNewEmailFlag(true);
            } else {
                $order->addCommentToStatusHistory(__(
                    'Payment via Worldpay failed. Transaction reference: %1',
                    $orderData['transactionReference']
                ));
            }

            $this->orderRepository->save($order);

            if ($orderData['newStatus'] == Order::STATE_PROCESSING && $order->getCanSendNewEmailFlag()) {
                $this->orderSender->send($order);
            }
        }
    }


    /**
     * @param  array  $additionalInformation
     *
     * @return string
     */
    private function getTransactionEnvironment(array $additionalInformation): string
    {
        if (!empty($additionalInformation['paymentEnv'])) {
            return $additionalInformation['paymentEnv'];
        }
        $hppRedirectUrl = $additionalInformation['hppUrl'] ?? '';
        foreach (self::TRY_HPP_URLS_DOMAINS as $domain) {
            if (str_starts_with($hppRedirectUrl, $domain)) {
                return Environment::TRY_MODE;
            }
        }

        return Environment::LIVE_MODE;
    }

    /**
     * @return string
     */
    private function getEventsFilter(): string
    {
        return implode(',', array_merge(
            $this->transactionSuccessStatuses,
            $this->transactionFailedStatuses
        ));
    }

    /**
     * @param  array  $response
     *
     * @return string
     */
    private function getLastEventReceived(array $response = []): string
    {
        return $response['lastEvent'] ?? '';
    }
}
