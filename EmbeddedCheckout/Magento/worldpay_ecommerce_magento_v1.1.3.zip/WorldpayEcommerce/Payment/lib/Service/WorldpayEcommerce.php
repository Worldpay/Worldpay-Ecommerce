<?php

namespace WorldpayEcommerce\Payment\lib\Service;

use Magento\Framework\Exception\NoSuchEntityException;
use Worldpay\Api\Builders\PaymentProcessing\PaymentProcessingBuilder;
use Worldpay\Api\Enums\Api;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;

abstract class WorldpayEcommerce
{
    /**
     * @var array
     */
    public array $orderData = [];

    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * @var PaymentProcessingBuilder
     */
    protected PaymentProcessingBuilder $apiRequest;

    /**
     * @var ApiResponse
     */
    protected ApiResponse $apiResponse;

    /**
     * Constructor
     *
     * @param WorldpayService $worldpayService
     * @param array           $order
     */
    public function __construct(
        WorldpayService $worldpayService,
        array $order = []
    ) {
        $this->worldpayService = $worldpayService;
        $this->orderData = $order;
    }

    abstract public function initializePayment(): ApiResponse;

    /**
     * Tests the API credentials by making a test request to the Worldpay API.
     *
     * @param CreditCard $creditCardPaymentInstrument
     * @param array $credentials
     *
     * @return ApiResponse
     * @throws ApiClientException
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     * @throws \Exception
     */
    public function testApiCredentials(
        CreditCard $creditCardPaymentInstrument,
        array $credentials
    ): ApiResponse {

        $apiConfigProvider = $this->worldpayService::getApiConfigProviderForTest(Api::ACCESS_WORLDPAY_PAYMENTS_API, $credentials);

        $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        $api = $this->worldpayService->initializeApi();

        return $api->initiatePayment(1)
                   ->withCurrency('GBP')
                   ->withTransactionReference(Helper::generateString(12).'_'.$credentials['appMode'].'_test')
                   ->withPaymentInstrument($creditCardPaymentInstrument)
                   ->execute();
    }

    /**
     * Request for refund.
     *
     * @param string $transactionReference
     * @param mixed $refundAmount
     * @param string $currencyCode
     * @param string $storeLocale
     * @param string $partialRefundReference
     * @param bool $isPartialRefund
     * @param string $linkData
     *
     * @return ApiResponse
     * @throws ApiClientException
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     * @throws NoSuchEntityException
     */
    public function refund(
        string $transactionReference,
        mixed $refundAmount,
        string $currencyCode,
        string $storeLocale,
        string $partialRefundReference = '',
        bool $isPartialRefund = false,
        string $linkData = ''
    ): ApiResponse {
        if (empty($linkData)) {
            $apiConfigProvider = $this->worldpayService->configureApi();
            $apiConfigProvider->api = Api::ACCESS_WORLDPAY_HPP_API;
            $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        }
        $api = $this->worldpayService->initializeApi();

        $convertedAmount = AmountHelper::decimalToExponentDelimiter($refundAmount, $currencyCode, $storeLocale);

        $apiRequest = $isPartialRefund
            ? $api->partialRefund($convertedAmount)->withCurrency($currencyCode)
            : $api->refund($convertedAmount);

        $apiRequest = $apiRequest->withTransactionReference($transactionReference)
                             ->withPartialOperationReference($partialRefundReference);

        if ($linkData) {
            $apiRequest = $apiRequest->withLinkData($linkData);
        }

        return $apiRequest->execute();
    }

    /**
     * @throws NoSuchEntityException
     * @throws ApiClientException
     * @throws AuthenticationException
     */
    public function queryPayments(string $env, string $startDate, string $endDate, int $pageSize = 300, string $receivedEvents = ''): ApiResponse {
        $apiConfigProvider = $this->worldpayService->configureApi();
        $apiConfigProvider->api = Api::ACCESS_WORLDPAY_PAYMENT_QUERIES_API;
        $apiConfigProvider->environment = $env;
        $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        $api = $this->worldpayService->initializeApi();

        $apiRequest = $api->queryPayments()
            ->withStartDate($startDate)
            ->withEndDate($endDate)
            ->withPageSize($pageSize);
        if (! empty($receivedEvents)) {
            $apiRequest = $apiRequest->withReceivedEvents($receivedEvents);
        }

        return $apiRequest->execute();
    }

    /**
     * @throws NoSuchEntityException
     * @throws ApiClientException
     * @throws AuthenticationException
     */
    public function queryPaymentByPaymentId(string $env, string $paymentId): ApiResponse {
        $apiConfigProvider = $this->worldpayService->configureApi();
        $apiConfigProvider->api = Api::ACCESS_WORLDPAY_PAYMENT_QUERIES_API;
        $apiConfigProvider->environment = $env;
        $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        $api = $this->worldpayService->initializeApi();

        $apiRequest = $api->queryPayments()
                          ->withPaymentId($paymentId);

        return $apiRequest->execute();
    }
}
