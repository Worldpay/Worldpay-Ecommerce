<?php

namespace Worldpay\Api\Enums;

class RiskFactors
{
	public const AVS_NOT_MATCHED = 'avsNotMatched';

	public const CVC_NOT_MATCHED = 'cvcNotMatched';
}
