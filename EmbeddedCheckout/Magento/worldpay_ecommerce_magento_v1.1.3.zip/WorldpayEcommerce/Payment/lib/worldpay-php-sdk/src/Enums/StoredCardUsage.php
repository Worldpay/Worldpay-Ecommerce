<?php

namespace Worldpay\Api\Enums;

class StoredCardUsage
{
	/**
	 * When storing card.
	 */
	public const FIRST = 'first';

	/**
	 * When using previously stored card.
	 */
	public const SUBSEQUENT = 'subsequent';
}
