<?php

namespace Worldpay\Api\Exceptions;

class FailedPaymentException extends \Exception {

}
