<?php

namespace Worldpay\Api\Enums;

class Status
{
	public const ENABLED = 'enabled';

	public const DISABLED = 'disabled';
}
