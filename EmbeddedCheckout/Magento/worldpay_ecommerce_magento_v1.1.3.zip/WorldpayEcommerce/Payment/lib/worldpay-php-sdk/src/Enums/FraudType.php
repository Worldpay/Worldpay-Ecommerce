<?php

namespace Worldpay\Api\Enums;

class FraudType {

	/**
	 * FRAUD TYPE FRAUD_SIGHT
	 */
	public const FRAUD_SIGHT = 'fraudSight';
}

