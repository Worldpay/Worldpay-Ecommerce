<?php

namespace WorldpayEcommerce\Payment\Controller\Checkout\Onepage;

use Magento\Checkout\Controller\Onepage\Success as OnepageSuccess;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Registry;
use Magento\Framework\Translate\InlineInterface;
use Magento\Framework\View\LayoutFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\View\Result\LayoutFactory as LayoutResultFactory;

class Success extends OnepageSuccess
{
    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @param  Context                      $context
     * @param  Session                      $customerSession
     * @param  CustomerRepositoryInterface  $customerRepository
     * @param  AccountManagementInterface   $accountManagement
     * @param  Registry                     $coreRegistry
     * @param  InlineInterface              $translateInline
     * @param  Validator                    $formKeyValidator
     * @param  ScopeConfigInterface         $scopeConfig
     * @param  LayoutFactory                $layoutFactory
     * @param  CartRepositoryInterface      $quoteRepository
     * @param  PageFactory                  $resultPageFactory
     * @param  LayoutResultFactory          $resultLayoutFactory
     * @param  RawFactory                   $resultRawFactory
     * @param  JsonFactory                  $resultJsonFactory
     * @param  DirectoryList                $dir
     * @param  OrderRepositoryInterface     $orderRepository
     *
     * @throws FileSystemException
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        CustomerRepositoryInterface $customerRepository,
        AccountManagementInterface $accountManagement,
        Registry $coreRegistry,
        InlineInterface $translateInline,
        Validator $formKeyValidator,
        ScopeConfigInterface $scopeConfig,
        LayoutFactory $layoutFactory,
        CartRepositoryInterface $quoteRepository,
        PageFactory $resultPageFactory,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        RawFactory $resultRawFactory,
        JsonFactory $resultJsonFactory,
        DirectoryList $dir,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->orderRepository = $orderRepository;
        Logger::config($scopeConfig, $dir);
        parent::__construct(
            $context,
            $customerSession,
            $customerRepository,
            $accountManagement,
            $coreRegistry,
            $translateInline,
            $formKeyValidator,
            $scopeConfig,
            $layoutFactory,
            $quoteRepository,
            $resultPageFactory,
            $resultLayoutFactory,
            $resultRawFactory,
            $resultJsonFactory
        );
    }

    /**
     * Overwrite default one-page success controller to redirect to HPP page or allow normal flow.
     *
     * @return Redirect|ResultInterface
     */
    public function execute()
    {
        $orderId = $this->getOnepage()->getCheckout()->getLastOrderId();
        if (!$orderId) {
            return $this->resultRedirectFactory->create()->setPath('access_worldpay_hpp/notfound');
        }
        $order        = $this->orderRepository->get($orderId);
        $orderPayment = $order->getPayment();

        if (null === $orderPayment || $orderPayment->getMethod() !== PaymentMethodConfig::ACCESS_WORLDPAY_HPP_CODE) {
            return parent::execute();
        }

        $dataToLog = [
            "orderId"                => $order->getIncrementId() ?? "",
            "method"                 => $orderPayment->getMethod() ?? "",
            "status"                 => $order->getStatus() ?? "",
            "additional information" => $orderPayment->getAdditionalInformation() ?? "",
        ];
        Logger::setDescription("Success controller data")->debug($dataToLog);

        if (!in_array($order->getStatus(), [Order::STATE_PENDING_PAYMENT,
            WorldpayService::TRANSACTION_STATUS_PENDING])) {
            return parent::execute();
        }

        $additionalInformation = $orderPayment->getAdditionalInformation();
        if (null === $additionalInformation || !isset($additionalInformation['hppUrl'])) {
            return parent::execute();
        }

        $order->addCommentToStatusHistory(__(
            '%1 awaiting payment via Worldpay. Transaction reference: %2',
            $orderPayment->formatPrice($order->getGrandTotal()),
            $additionalInformation['transaction_reference']
        ));
        $this->orderRepository->save($order);

        return $this->resultRedirectFactory->create()->setUrl($additionalInformation['hppUrl']);
    }
}
