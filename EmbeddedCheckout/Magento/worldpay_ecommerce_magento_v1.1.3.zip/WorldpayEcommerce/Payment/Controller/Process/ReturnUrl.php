<?php

namespace WorldpayEcommerce\Payment\Controller\Process;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\App\Request\Http as HttpRequest;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\UrlInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\Validator\GuidValidator;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Exception;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;

class ReturnUrl implements ActionInterface
{
    /**
     * @var Session
     */
    protected Session $checkoutSession;

    /**
     * @var ResultFactory
     */
    protected ResultFactory $resultFactory;

    /**
     * @var HttpRequest
     */
    protected HttpRequest $request;

    /**
     * @var GuidValidator
     */
    protected GuidValidator $guidValidator;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var TransactionHelper
     */
    protected TransactionHelper $transactionHelper;

    /**
     * @var InvoiceHelper
     */
    protected InvoiceHelper $invoiceHelper;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlInterface;

    /**
     * @var RedirectFactory
     */
    protected RedirectFactory $resultRedirectFactory;

    /**
     * @var MessageManager
     */
    protected MessageManager $messageManager;

    /**
     * @var OrderSender
     */
    protected OrderSender $orderSender;

    /**
     * @param Session $checkoutSession
     * @param ResultFactory $resultFactory
     * @param HttpRequest $request
     * @param GuidValidator $guidValidator
     * @param OrderRepositoryInterface $orderRepository
     * @param TransactionHelper $transactionHelper
     * @param InvoiceHelper $invoiceHelper
     * @param UrlInterface $urlInterface
     * @param RedirectFactory $redirectFactory
     * @param MessageManager $messageManager
     * @param ScopeConfigInterface $scopeConfig
     * @param DirectoryList $dir
     * @param OrderSender $orderSender
     * @throws FileSystemException
     */
    public function __construct(
        Session $checkoutSession,
        ResultFactory $resultFactory,
        HttpRequest $request,
        GuidValidator $guidValidator,
        OrderRepositoryInterface $orderRepository,
        TransactionHelper  $transactionHelper,
        InvoiceHelper $invoiceHelper,
        UrlInterface $urlInterface,
        RedirectFactory $redirectFactory,
        MessageManager $messageManager,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir,
        OrderSender $orderSender
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->resultFactory = $resultFactory;
        $this->request = $request;
        $this->guidValidator = $guidValidator;
        $this->orderRepository = $orderRepository;
        $this->transactionHelper = $transactionHelper;
        $this->invoiceHelper = $invoiceHelper;
        $this->urlInterface = $urlInterface;
        $this->resultRedirectFactory = $redirectFactory;
        $this->messageManager = $messageManager;
        $this->orderSender = $orderSender;

        Logger::config($scopeConfig, $dir);
    }

    /**
     * Execute action.
     *
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        $urlGuid = $this->request->getParam('guid') ?? '';
        $validationResult = $this->guidValidator->validate(['guid' => $urlGuid]);

        try {
            if (!$validationResult->isValid()) {
                Logger::setDescription("Return url - invalid guid")->alert(["urlGuid" => $urlGuid]);
                throw new Exception($validationResult->getFailsDescription()[0]);
            }
            $order = $this->checkoutSession->getLastRealOrder();
            $orderPayment = $order->getPayment();
            $dataToLog = [
                "urlGuid" => $urlGuid,
                "orderId" => $order->getIncrementId() ?? ""
            ];
            if (null === $orderPayment) {
                Logger::setDescription("Return url - Order payment is not in session")->alert($dataToLog);
                throw new Exception(__('Order payment is not in session.'));
            }

            $paymentAdditionalInformation = $orderPayment->getAdditionalInformation();

            if (!in_array($urlGuid, $paymentAdditionalInformation)) {
                Logger::setDescription("Return url - Guid is not for this payment/order")->alert($dataToLog);
                throw new Exception(__('Guid is not for this payment/order.'));
            }
            if ($order->getStatus() !== Order::STATE_PENDING_PAYMENT) {
                Logger::setDescription("Return url - Guid is for an order that is not in pending payment")
                      ->alert($dataToLog);
                throw new Exception(__('Guid is for an order that is not in pending payment.'));
            }

            $dataToLog = [
                ...$dataToLog,
                "paymentAdditionalInformation" => $paymentAdditionalInformation
            ];
            switch ($urlGuid) {
                case $paymentAdditionalInformation['success_guid']:
                    $this->handleSuccessResult($order, $orderPayment);

                    $dataToLog["order_status"] = $order->getStatus();
                    Logger::setDescription("Return url - handle success")->debug($dataToLog);
                    return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath(
                        'checkout/onepage/success',
                        ['_secure' => true]
                    );
                case $paymentAdditionalInformation['failure_guid']:
                    $this->handleFailureResult($order, $orderPayment);

                    $dataToLog["order_status"] = $order->getStatus();
                    Logger::setDescription("Return url - handle failure")->debug($dataToLog);
                    return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath(
                        'checkout/cart',
                        ['_secure' => true]
                    );
                case $paymentAdditionalInformation['cancel_guid']:
                    $this->handleCancelResult($order, $orderPayment);

                    $dataToLog["order_status"] = $order->getStatus();
                    Logger::setDescription("Return url - handle cancel")->debug($dataToLog);
                    return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath(
                        'checkout/cart',
                        ['_secure' => true]
                    );
            }
        } catch (Exception $e) {
            return $this->resultRedirectFactory->create()->setPath('access_worldpay_hpp/notfound');
        }
    }

    /**
     * Handle success payment result.
     *
     * @param  Order                  $order
     * @param  OrderPaymentInterface  $orderPayment
     * @return void
     * @throws LocalizedException
     */
    public function handleSuccessResult(Order $order, OrderPaymentInterface $orderPayment)
    {
        $order->setState(Order::STATE_PROCESSING);
        $order->setStatus(Order::STATE_PROCESSING);
        $paymentAdditionalInformation = $orderPayment->getAdditionalInformation();
        $order->addCommentToStatusHistory(__(
            'Payment successful via Worldpay. Transaction reference: %1',
            $paymentAdditionalInformation['transaction_reference']
        ));

        $this->transactionHelper->createTransaction(
            $order,
            $orderPayment,
            $paymentAdditionalInformation['transaction_reference']
        );
        $this->invoiceHelper->createInvoice($order, $paymentAdditionalInformation['transaction_reference']);

        $this->orderRepository->save($order);

        $this->sendOrderConfirmationEmail($order);

        $this->checkoutSession->setLastSuccessQuoteId($order->getQuoteId());
    }

    /**
     * Handle cancel payment result.
     *
     * @param  Order                  $order
     * @param  OrderPaymentInterface  $orderPayment
     * @return void
     */
    public function handleCancelResult(Order $order, OrderPaymentInterface $orderPayment)
    {
        $this->checkoutSession->restoreQuote();

        $order->setState(Order::STATE_CANCELED);
        $order->setStatus(Order::STATE_CANCELED);
        $paymentAdditionalInformation = $order->getPayment()->getAdditionalInformation();
        $order->addCommentToStatusHistory(__(
            'Payment via Worldpay canceled by customer. Transaction reference: %1',
            $paymentAdditionalInformation['transaction_reference']
        ));

        $this->orderRepository->save($order);
    }

    /**
     * Handles failure payment result.
     *
     * @param  Order                  $order
     * @param  OrderPaymentInterface  $orderPayment
     * @return void
     */
    public function handleFailureResult(Order $order, OrderPaymentInterface $orderPayment)
    {
        $this->checkoutSession->restoreQuote();

        $order->setState(Order::STATE_CANCELED);
        $order->setStatus(Order::STATE_CANCELED);
        $paymentAdditionalInformation = $order->getPayment()->getAdditionalInformation();
        $order->addCommentToStatusHistory(__(
            'Payment via Worldpay failed. Transaction reference: %1',
            $paymentAdditionalInformation['transaction_reference']
        ));

        $this->orderRepository->save($order);

        $this->messageManager->addErrorMessage(__('Payment failed. Please try again.'));
    }

    /**
     * Send the order confirmation mail after the user is redirected back
     *
     * @param Order $order
     * @return void
     */
    private function sendOrderConfirmationEmail(Order $order): void
    {
        if ($order->getCanSendNewEmailFlag()) {
            $this->orderSender->send($order);
        }
    }
}
