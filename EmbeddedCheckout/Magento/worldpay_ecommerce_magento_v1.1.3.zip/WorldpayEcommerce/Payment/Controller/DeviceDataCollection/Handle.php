<?php

namespace WorldpayEcommerce\Payment\Controller\DeviceDataCollection;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Raw;
use Magento\Framework\Controller\ResultInterface;
use Worldpay\Api\Forms\DeviceDataCollection;
use WorldpayEcommerce\Payment\Controller\PaymentActions\HandleAction;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class Handle extends HandleAction
{

    /**
     * @return ResultInterface|ResponseInterface|Raw
     */
    public function execute()
    {
        $result = $this->rawFactory->create();
        if (!$this->requestInterface->isGet()) {
            Logger::setDescription('Setup device data collection form failed')->alert(
                [
                    'message' => 'Wrong HTTP method.'
                ]
            );

            $result->setHeader('Content-Type', 'text/html');
            $result->setContents('<p>Wrong HTTP method.</p>');
            $result->setHttpResponseCode(405);

            return $result;
        }

        return $result->setContents(
            (new DeviceDataCollection(
            'access_worldpay_checkout-ddc-form',
            $this->requestInterface->getParam('url') ?? '',
            $this->requestInterface->getParam('bin') ?? '',
            $this->requestInterface->getParam('jwt') ?? ''
        ))->render());
    }
}
