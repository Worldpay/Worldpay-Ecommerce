<?php

namespace WorldpayEcommerce\Payment\Controller\PaymentActions;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Sales\Api\OrderRepositoryInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

abstract class FetchAction implements ActionInterface
{
    /**
     * @var Session
     */
    protected Session $checkoutSession;

    /**
     * @var JsonFactory
     */
    protected JsonFactory $resultJsonFactory;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var RequestInterface
     */
    protected RequestInterface $requestInterface;

    /**
     * @return Json|ResultInterface|ResponseInterface
     */
    abstract public function execute();

    /**
     * @param  JsonFactory  $resultJsonFactory
     * @param  Session  $checkoutSession
     * @param  OrderRepositoryInterface  $orderRepository
     * @param  RequestInterface  $requestInterface
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList  $directoryList
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        JsonFactory $resultJsonFactory,
        Session $checkoutSession,
        OrderRepositoryInterface $orderRepository,
        RequestInterface $requestInterface,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $directoryList
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        $this->requestInterface = $requestInterface;
        Logger::config($scopeConfig, $directoryList);
    }
}
