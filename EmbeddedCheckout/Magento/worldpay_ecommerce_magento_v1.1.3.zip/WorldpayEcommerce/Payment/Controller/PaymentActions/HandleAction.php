<?php

namespace WorldpayEcommerce\Payment\Controller\PaymentActions;

use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Raw;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use WorldpayEcommerce\Payment\lib\Service\Logger;

abstract class HandleAction implements ActionInterface
{
    /**
     * @var RequestInterface
     */
    protected RequestInterface $requestInterface;

    /**
     * @var RawFactory
     */
    protected RawFactory $rawFactory;

    /**
     * @return ResultInterface|ResponseInterface|Raw
     */
    abstract public function execute();

    /**
     * @param  RequestInterface  $requestInterface
     * @param  RawFactory  $rawFactory
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList  $directoryList
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        RequestInterface $requestInterface,
        RawFactory $rawFactory,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $directoryList
    ) {
        $this->requestInterface = $requestInterface;
        $this->rawFactory = $rawFactory;
        Logger::config($scopeConfig, $directoryList);
    }
}
