<?php

namespace WorldpayEcommerce\Payment\Controller\DeviceDataCollection;

use Exception;
use Magento\Framework\Controller\Result\Json;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\ApiResponseException;
use Worldpay\Api\Exceptions\AuthenticationException;
use WorldpayEcommerce\Payment\Controller\PaymentActions\SubmitAction;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Failed\FailedOutcome;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeFactory;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Pending\PendingOutcome;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Successful\SuccessfulOutcome;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceCheckout;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class Submit extends SubmitAction
{
    /**
     * @return Json
     * @throws ApiResponseException
     * @throws Exception
     */
    public function execute(): Json
    {
        $resultJson = $this->resultJsonFactory->create();
        $apiResponse = null;
        try {
            if (!$this->requestInterface->isPost()) {
                throw new Exception( 'Wrong HTTP method.' );
            }

            $order = $this->checkoutSession->getLastRealOrder();
            if (! $order->getId()) {
                throw new \Exception( 'Order does not exist.');
            }

            $orderPayment = $order->getPayment();
            if (! $orderPayment->getEntityId()) {
                throw new \Exception( 'Order payment does not exist.');
            }

            $collectionReference = $this->requestInterface->getPost('collectionReference') ?? '';
            $deviceDataCollectionSubmissionEndpoint = $orderPayment->getAdditionalInformation('deviceDataCollectionSubmissionEndpoint') ?? '';
            if ($deviceDataCollectionSubmissionEndpoint === null) {
                throw new \Exception( 'Device data submission url does not exist for orderId= '.$order->getIncrementId());
            }

            $apiResponse = $this->sendApiRequest($deviceDataCollectionSubmissionEndpoint, $collectionReference);
            if (! $apiResponse->isSuccessful()) {
                throw new ApiException( 'Payment response is not successful' );
            }

            $apiResponse = $apiResponse->jsonDecode();
            if (empty($apiResponse->outcome) || empty($apiResponse->transactionReference)) {
                throw new ApiException('API breach of contract');
            }
            $paymentOutcome = OutcomeFactory::createOutcome($apiResponse->outcome);
            $paymentOutcome = $this->setPaymentOutcomeDependencies($paymentOutcome);
            $paymentOutcome->handlePayment($orderPayment, $apiResponse);
            $paymentOutcome->handleOrder($order);

            if ($paymentOutcome instanceof SuccessfulOutcome || $paymentOutcome instanceof PendingOutcome) {
                return $resultJson->setData([
                    'success' => true,
                    'status' => $apiResponse->outcome,
                    'redirect' => $this->urlInterface->getUrl('checkout/onepage/success')
                ]);
            } else if ($paymentOutcome instanceof FailedOutcome) {
                return $resultJson->setData(['error' => true, 'message' => 'Payment failed. Please try again.']);
            }
        } catch (Exception $e) {
            Logger::setDescription('Supply 3DS device data collection failed')->alert(
                [
                    'message' => $e->getMessage(),
                    'apiRequest' => $apiResponse->rawRequest ?? '',
                    'apiResponse' => $apiResponse->rawResponse ?? ''
                ]);

            return $resultJson->setData(['error' => true]);
        }
    }

    /**
     * @throws AuthenticationException
     * @throws ApiClientException
     */
    protected function sendApiRequest(string $deviceDataCollectionSubmissionEndpoint, string $collectionReference): ApiResponse
    {
        return (new WorldpayEcommerceCheckout($this->worldpayService, []))->supply3DSDeviceData($deviceDataCollectionSubmissionEndpoint, $collectionReference);
    }
}
