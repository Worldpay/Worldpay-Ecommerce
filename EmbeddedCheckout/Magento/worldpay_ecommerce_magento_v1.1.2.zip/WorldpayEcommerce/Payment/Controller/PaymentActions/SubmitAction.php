<?php

namespace WorldpayEcommerce\Payment\Controller\PaymentActions;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\UrlInterface;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Quote\Model\QuoteManagement;
use Magento\Store\Model\StoreManagerInterface;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\OutcomeInterface;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

abstract class SubmitAction implements ActionInterface
{
    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * @var Session
     */
    protected Session $checkoutSession;

    /**
     * @var JsonFactory
     */
    protected JsonFactory $resultJsonFactory;

    /**
     * @var RawFactory
     */
    protected RawFactory $rawFactory;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * @var CartRepositoryInterface
     */
    protected CartRepositoryInterface $cartRepository;

    /**
     * @var RequestInterface
     */
    protected RequestInterface $requestInterface;

    /**
     * @var TransactionHelper
     */
    protected TransactionHelper $transactionHelper;

    /**
     * @var InvoiceHelper
     */
    protected InvoiceHelper $invoiceHelper;

    /**
     * @var UrlInterface
     */
    protected UrlInterface $urlInterface;

    /**
     * @var OrderSender
     */
    protected OrderSender $orderSender;

    /**
     * @var OrderFactory
     */
    protected OrderFactory $orderFactory;

    protected QuoteIdMaskFactory $quoteIdMaskFactory;

    protected QuoteManagement $quoteManagement;

    /**
     * @return mixed
     */
    abstract public function execute(): mixed;

    /**
     * @param JsonFactory $resultJsonFactory
     * @param RawFactory $rawFactory
     * @param Session $checkoutSession
     * @param OrderRepositoryInterface $orderRepository
     * @param RequestInterface $requestInterface
     * @param ScopeConfigInterface $scopeConfig
     * @param Config $gatewayConfig
     * @param TransactionHelper $transactionHelper
     * @param InvoiceHelper $invoiceHelper
     * @param UrlInterface $urlInterface
     * @param OrderSender $orderSender
     * @param DirectoryList $directoryList
     * @param OrderFactory $orderFactory
     * @param CartRepositoryInterface $cartRepository
     * @param QuoteIdMaskFactory $quoteIdMaskFactory
     * @param QuoteManagement $quoteManagement
     * @param ProductMetadataInterface $productMetadata
     * @param StoreManagerInterface $storeManager
     *
     * @throws FileSystemException
     * @throws NoSuchEntityException
     */
    public function __construct(
        JsonFactory $resultJsonFactory,
        RawFactory $rawFactory,
        Session $checkoutSession,
        OrderRepositoryInterface $orderRepository,
        RequestInterface $requestInterface,
        ScopeConfigInterface $scopeConfig,
        Config $gatewayConfig,
        TransactionHelper $transactionHelper,
        InvoiceHelper $invoiceHelper,
        UrlInterface $urlInterface,
        OrderSender $orderSender,
        DirectoryList $directoryList,
        OrderFactory $orderFactory,
        CartRepositoryInterface $cartRepository,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        QuoteManagement $quoteManagement,
        ProductMetadataInterface $productMetadata,
        StoreManagerInterface $storeManager
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->rawFactory = $rawFactory;
        $this->checkoutSession = $checkoutSession;
        $this->orderRepository = $orderRepository;
        $this->requestInterface = $requestInterface;
        $this->transactionHelper = $transactionHelper;
        $this->invoiceHelper = $invoiceHelper;
        $this->urlInterface = $urlInterface;
        $this->orderSender = $orderSender;
        $this->orderFactory = $orderFactory;
        $this->cartRepository = $cartRepository;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->quoteManagement = $quoteManagement;
        $this->worldpayService = new WorldpayService(
            $gatewayConfig,
            $scopeConfig,
            $requestInterface,
            $productMetadata,
            $storeManager,
            $gatewayConfig->getMethodCode()
        );
        Logger::config($scopeConfig, $directoryList);
    }

    /**
     * @param  OutcomeInterface  $paymentOutcome
     *
     * @return OutcomeInterface
     */
    protected function setPaymentOutcomeDependencies(OutcomeInterface $paymentOutcome): OutcomeInterface
    {
        $paymentOutcome->setOrderRepositoryInterface($this->orderRepository);
        $paymentOutcome->setSession($this->checkoutSession);
        $paymentOutcome->setTransactionHelper($this->transactionHelper);
        $paymentOutcome->setInvoiceHelper($this->invoiceHelper);
        $paymentOutcome->setOrderSender($this->orderSender);
        $paymentOutcome->setUrlInterface($this->urlInterface);
        $paymentOutcome->setCartRepositoryInterface($this->cartRepository);
        $paymentOutcome->setQuoteManagement($this->quoteManagement);
        $paymentOutcome->setQuoteIdMaskFactory($this->quoteIdMaskFactory);

        return $paymentOutcome;
    }
}
