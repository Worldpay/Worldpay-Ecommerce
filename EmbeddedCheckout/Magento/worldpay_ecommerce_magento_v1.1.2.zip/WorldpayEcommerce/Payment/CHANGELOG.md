## Worldpay eCommerce for Magento Community Edition Changelog

### Version 1.1.2
* added User-Agent header to all requests
* fix for try credentials passing validation when setting live mode
* disabled settlement cancellation on AVS not matched
* added user friendly message at checkout for HPP failed payment request due client/server errors

### Version 1.1.1
* added fallback refund keys
* added csp whitelist policy for frame-src
* fixed issue where the street address was not always found

### Version 1.1.0
* added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment
* fixed log for checkout success to log details only for our payment methods
* added cronjob to reconcile orders with no payment results

### Version 1.0.5
* fix for reading street address (or other order fields) in case of prefix existence

### Version 1.0.4
* added backwards compatibility with Magento 2.4.5-p9

### Version 1.0.3
* the plugin now supports multiple stores
* fix for refunding negative values
* fix for updating mini-cart if payment failure or cancellation

### Version 1.0.2
* changed wording for some of the merchant settings inputs
* fixed billing and shipping address not being sent to the gateway
* delayed the order confirmation mails to only be sent after a successful payment

### Version 1.0.1
* fixed bug for empty merchant settings fields at fresh module install

### Version 1.0.0
* initial release
