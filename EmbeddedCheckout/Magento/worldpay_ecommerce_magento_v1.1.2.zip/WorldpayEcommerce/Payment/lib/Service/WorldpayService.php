<?php

namespace WorldpayEcommerce\Payment\lib\Service;

use Exception;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\State;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Worldpay\Api\Enums\Api;
use Worldpay\Api\Enums\PaymentInstrumentType;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\ValueObjects\PaymentMethods\CreditCard;
use Worldpay\Api\ValueObjects\ThreeDS;
use Worldpay\Api\ValueObjects\UserAgent;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;
use Magento\Framework\App\Config\ScopeConfigInterface;

class WorldpayService
{
    /**
     * Plugin version
     */
    public const PLUGIN_VERSION = "1.1.2";

    /**
     * TRANSACTION_STATUS_SUCCESS
     */
    public const TRANSACTION_STATUS_SUCCESS = 'success';

    /**
     * TRANSACTION_STATUS_FAILED
     */
    public const TRANSACTION_STATUS_FAILED  = 'failed';

    /**
     * TRANSACTION_STATUS_PENDING
     */
    public const TRANSACTION_STATUS_PENDING = 'pending';

    /**
     * TRANSACTION_STATUS_CANCELED
     */
    public const TRANSACTION_STATUS_CANCELED = 'canceled';

    /**
     * @var null
     */
    public $apiConfigProvider = null;

    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    protected StoreManagerInterface $storeManager;

    /**
     * @var int $storeId;
     */
    protected int $storeId;

    /**
     * @var string
     */
    protected string $paymentMethodCode;

    /**
     * @var RequestInterface
     */
    protected RequestInterface $request;

    /**
     * @var ProductMetadataInterface
     */
    private ProductMetadataInterface $productMetadata;

    /**
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     * @param RequestInterface $request
     * @param ProductMetadataInterface $productMetadata
     * @param StoreManagerInterface $storeManager
     * @param string $paymentMethodCode
     *
     * @throws NoSuchEntityException
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig,
        RequestInterface $request,
        ProductMetadataInterface $productMetadata,
        StoreManagerInterface $storeManager,
        string $paymentMethodCode = '',
    ) {
        $this->config           = $config;
        $this->scopeConfig      = $scopeConfig;
        $this->request          = $request;
        $this->productMetadata  = $productMetadata;
        $this->storeManager     = $storeManager;
        $this->setPaymentMethodCode($paymentMethodCode);
        $this->storeId          = self::getStoreId();
    }

    /**
     * @param  string  $paymentMethodCode
     *
     * @return void
     */
    public function setPaymentMethodCode(string $paymentMethodCode): void
    {
        $this->paymentMethodCode = $paymentMethodCode;
        $this->config->setMethodCode($paymentMethodCode);
    }

    /**
     * Get store ID dynamically using ObjectManager.
     *
     * @return int
     * @throws NoSuchEntityException
     */
    public static function getStoreId(): int
    {
        $storeManager = ObjectManager::getInstance()->get(StoreManagerInterface::class);
        return $storeManager->getStore()->getId();
    }

    /**
     * Initialize api.
     *
     * @return AccessWorldpay
     * @throws AuthenticationException
     * @throws NoSuchEntityException
     */
    public function initializeApi(): AccessWorldpay
    {
        $this->initUserAgent($this->isProduction());

        $this->configureProxy();
        if ($this->apiConfigProvider instanceof AccessWorldpayConfigProvider) {
            return AccessWorldpay::config($this->apiConfigProvider);
        }

        return AccessWorldpay::config($this->configureApi());
    }

    /**
     * Configure api for requests.
     *
     * @return AccessWorldpayConfigProvider|mixed|null
     */
    public function configureApi(): mixed
    {
        $apiConfigProvider                    = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->environment       = $this->getApiEnvironment();
        $apiConfigProvider->username          = $this->getApiUsername();
        $apiConfigProvider->password          = $this->getApiPassword();
        $apiConfigProvider->merchantEntity    = $this->getMerchantEntity();
        $apiConfigProvider->merchantNarrative = $this->getMerchantNarrative();
        $apiConfigProvider->api               = $this->paymentMethodCode === Config::ACCESS_WORLDPAY_HPP_CODE ? Api::ACCESS_WORLDPAY_HPP_API : Api::ACCESS_WORLDPAY_PAYMENTS_API;

        return $apiConfigProvider;
    }

    /**
     * Get addresses from order.
     *
     * @param array  $orderData
     * @param string $addressType
     *
     * @return BillingAddress|ShippingAddress|null
     */
    public static function getOrderAddress(
        array $orderData = [],
        string $addressType = ''
    ): BillingAddress|ShippingAddress|null {
        if (!in_array($addressType, ["billing", "shipping"]) || empty($orderData)) {
            return null;
        }

        $address = $addressType === 'billing' ? new BillingAddress() : new ShippingAddress();
        $address->address1      = $orderData[$addressType]['street'] ?? '';
        $address->postalCode    = $orderData[$addressType]['postcode'] ?? '';
        $address->city          = $orderData[$addressType]['city'] ?? '';
        $address->countryCode   = $orderData[$addressType]['country'] ?? '';

        return $address;
    }

    /**
     * Get customer from order.
     *
     * @param array $orderData
     *
     * @return Customer
     */
    public static function getOrderCustomer(array $orderData = []): Customer
    {
        $customer = new Customer();
        $customer->firstName   = $orderData['customer']['firstName'] ?? '';
        $customer->lastName    = $orderData['customer']['lastName'] ?? '';
        $customer->email       = $orderData['customer']['email'] ?? '';
        $customer->phoneNumber = $orderData['customer']['phoneNumber'] ?? '';

        return $customer;
    }

    /**
     * Get order data.
     *
     * @param array $orderData
     *
     * @throws InvalidArgumentException
     *
     * @return Order
     */
    public function getOrderData(array $orderData = []): Order
    {
        $order = new Order();
        $order->id              = $orderData["id"] ?? "";
        $order->billingAddress  = self::getOrderAddress($orderData, 'billing');
        $order->shippingAddress = self::getOrderAddress($orderData, 'shipping');
        $order->customer        = self::getOrderCustomer($orderData);
        $order->currency        = $orderData["currency_code"] ?? "";
        $order->amount          = AmountHelper::decimalToExponentDelimiter($orderData["total"],
                $orderData['currency_code'], $orderData['locale']) ?? "";

        return $order;
    }

    /**
     * Get result URLs.
     *
     * @param string $success_return_url
     * @param string $failure_return_url
     * @param string $cancel_return_url
     *
     * @return ResultURLs
     */
    public function getResultUrls(
        string $success_return_url,
        string $failure_return_url,
        string $cancel_return_url
    ): ResultURLs {
        $resultUrls = new ResultURLs();
        $resultUrls->successURL = $success_return_url;
        $resultUrls->errorURL   = $failure_return_url;
        $resultUrls->failureURL = $failure_return_url;
        $resultUrls->pendingURL = $failure_return_url;
        $resultUrls->expiryURL  = $failure_return_url;
        $resultUrls->cancelURL  = $cancel_return_url;

        return $resultUrls;
    }

    /**
     * Get transaction reference for requests.
     *
     * @param string $orderId
     *
     * @throws \Exception
     *
     * @return string
     */
    public static function getTransactionReferenceByOrderId(string $orderId): string
    {
        return Helper::generateString(12) . '_' . $orderId;
    }

    /**
     * Create 3DS object.
     *
     * @param  string  $threeDSChallengeReturnUrl
     *
     * @return ThreeDS
     */
    public function createThreeDSObject(string $threeDSChallengeReturnUrl): ThreeDS
    {
        $threeDSObject = new ThreeDS();
        $threeDSObject->challengeReturnUrl    = $threeDSChallengeReturnUrl;
        $threeDSObject->deviceDataAgentHeader = $this->request->getServer('HTTP_USER_AGENT');

        return $threeDSObject;
    }

    /**
     * Configure proxy for requests.
     *
     * @return void
     */
    public function configureProxy(): void
    {
        $proxyConfigProvider = ProxyConfigProvider::instance();

        if ($this->scopeConfig->getValue(
            'web/proxy/use_proxy',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        )) {
            $proxyConfigProvider->host = $this->scopeConfig->getValue(
                'web/proxy/proxy_host',
                ScopeInterface::SCOPE_STORE,
                $this->storeId
            );
            $proxyConfigProvider->port = $this->scopeConfig->getValue(
                'web/proxy/proxy_port',
                ScopeInterface::SCOPE_STORE,
                $this->storeId
            );
        }
    }

    /**
     * Get API environment from config value.
     *
     * @return string
     */
    public function getApiEnvironment(): string
    {
        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/app_mode',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) === 'live' ? Environment::LIVE_MODE : Environment::TRY_MODE;
    }

    /**
     * Get API username from config value.
     *
     * @return string
     */
    public function getApiUsername(): string
    {
        if ($this->getApiEnvironment() === Environment::LIVE_MODE) {
            return $this->scopeConfig->getValue(
                'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/api_live_username',
                ScopeInterface::SCOPE_STORE,
                $this->storeId
            ) ?? '';
        }

        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/api_try_username',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) ?? '';
    }

    /**
     * Get API password from config value.
     *
     * @return string
     */
    public function getApiPassword(): string
    {
        if ($this->getApiEnvironment() === Environment::LIVE_MODE) {
            return $this->scopeConfig->getValue(
                'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/api_live_password',
                ScopeInterface::SCOPE_STORE,
                $this->storeId
            ) ?? '';
        }

        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/api_try_password',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) ?? '';
    }

    /**
     * Get merchant entity from config value.
     *
     * @return string
     */
    public function getMerchantEntity(): string
    {
        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/merchant_entity',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) ?? '';
    }

    /**
     * Get merchant narrative from config value.
     *
     * @return string
     */
    public function getMerchantNarrative(): string
    {
        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_HPP_CODE.'/merchant_narrative',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) ?? '';
    }

    /**
     * Get merchant description from config value.
     *
     * @return string
     */
    public function getMerchantDescription(): string
    {
        return $this->config->getValue('description', $this->storeId) ?? '';
    }

    /**
     * Get merchant checkout id from config value.
     *
     * @return string
     */
    public function getMerchantCheckoutId(): string
    {
        if ($this->getApiEnvironment() === Environment::LIVE_MODE) {
            return $this->scopeConfig->getValue(
                'payment/'.Config::ACCESS_WORLDPAY_CHECKOUT_CODE.'/api_live_checkout_id',
                ScopeInterface::SCOPE_STORE,
                $this->storeId
            ) ?? '';
        }

        return $this->scopeConfig->getValue(
            'payment/'.Config::ACCESS_WORLDPAY_CHECKOUT_CODE.'/api_try_checkout_id',
            ScopeInterface::SCOPE_STORE,
            $this->storeId
        ) ?? '';
    }

    /**
     * @return string
     */
    public function getMerchantCheckoutCardBrands(): string
    {
        return $this->config->getValue('card_brands', $this->storeId) ?? '';
    }


    /**
     * @param  string  $sessionHref
     * @param $cardHolderName
     *
     * @return CreditCard
     */
    public function checkoutCreditCard(string $sessionHref, $cardHolderName): CreditCard
    {
        $paymentInstrument                 = new CreditCard(PaymentInstrumentType::CHECKOUT);
        $paymentInstrument->sessionHref    = $sessionHref;
        $paymentInstrument->cardHolderName = $cardHolderName;

        return $paymentInstrument;
    }

    /**
     * Initiate and build the User-Agent to be sent with the API on each request.
     *
     * @param bool $isEnabled
     *
     * @return void
     * @throws NoSuchEntityException
     */
    public function initUserAgent(bool $isEnabled): void {
        if(!$isEnabled) {
            UserAgent::disable();

            return;
        }

        UserAgent::enable();

        $userAgent                         = UserAgent::getInstance();
        $userAgent->platformName           = $this->productMetadata->getName();
        $userAgent->platformVersion        = $this->productMetadata->getVersion();
        $userAgent->storeUrl               = parse_url($this->storeManager->getStore($this->storeId)->getBaseUrl(), PHP_URL_HOST);
        $userAgent->pluginName             = 'worldpay-ecommerce-magento';
        $userAgent->pluginVersion          = self::PLUGIN_VERSION;
        $userAgent->integrationType        = $this->paymentMethodCode === Config::ACCESS_WORLDPAY_HPP_CODE ? 'Offsite' : 'Onsite';
        $userAgent->integrationEnvironment = $this->getApiEnvironment() === Environment::LIVE_MODE ? 'Live' : 'Try';
    }

    /**
     * Check whether we are on production environment
     *
     * @return bool true = (production); false = (dev/test/local)
     */
    public function isProduction(): bool {
        $state = ObjectManager::getInstance()->get(State::class);
        return $state->getMode() === State::MODE_PRODUCTION;
    }

    /**
     * @param  string  $api
     * @param  array  $credentials
     *
     * @return AccessWorldpayConfigProvider
     * @throws Exception
     */
    public static function getApiConfigProviderForTest(string $api, array $credentials = []): AccessWorldpayConfigProvider
    {
        $apiConfigProvider                    = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->api               = $api;
        $apiConfigProvider->environment       = $credentials['appMode'] === 'live' ? Environment::LIVE_MODE : Environment::TRY_MODE;
        $apiConfigProvider->username          = $credentials['apiUsername'] ?? '';
        $apiConfigProvider->password          = $credentials['apiPassword'] ?? '';
        $apiConfigProvider->merchantEntity    = $credentials['merchantEntity'] ?? '';
        $apiConfigProvider->merchantNarrative = 'Test API Credentials';

        return $apiConfigProvider;
    }


    /**
     * Get WP Correlation id from headers.
     *
     * @param array $headers
     *
     * @return string
     */
    public static function getWpCorrelationIdFromHeaders(array $headers = []): string
    {
        $output = '';

        if (empty($headers)) {
            return $output;
        }

        if (isset($headers['wp-correlationid'])) {
            $output = $headers['wp-correlationid'];
        }

        if (isset($headers['WP-CorrelationId'])) {
            $output = $headers['WP-CorrelationId'];
        }

        if (is_array($output)) {
            $output = array_pop($output);
        }

        return $output;
    }

    /**
     * Load worldpay-php sdk.
     *
     * @return void
     */
    public static function includeSdk(): void
    {
        require_once __DIR__ . '/../worldpay-php-sdk/autoload.php';
    }
}
