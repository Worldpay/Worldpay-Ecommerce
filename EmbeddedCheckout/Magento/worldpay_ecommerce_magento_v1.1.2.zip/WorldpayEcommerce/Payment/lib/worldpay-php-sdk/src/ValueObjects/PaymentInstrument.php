<?php

namespace Worldpay\Api\ValueObjects;

class PaymentInstrument
{

}
