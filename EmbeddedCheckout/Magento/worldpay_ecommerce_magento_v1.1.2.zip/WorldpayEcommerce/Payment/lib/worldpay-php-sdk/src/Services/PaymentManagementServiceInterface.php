<?php

namespace Worldpay\Api\Services;

interface PaymentManagementServiceInterface
{
	/**
	 * @param  string  $operationType
	 *
	 * @return bool
	 */
	public static function supports(string $operationType): bool;
}
