<?php

namespace Worldpay\Api\Enums;

/**
 * HTTP request valid methods.
 */
class RequestMethods
{
    /**
     * HTTP POST method.
     */
    public const POST = 'POST';

    /**
     * HTTP GET method.
     */
    public const GET = 'GET';

	/**
	 * HTTP PUT method.
	 */
	public const PUT = 'PUT';

	/**
	 * HTTP DELETE method.
	 */
	public const DELETE = 'DELETE';
}
