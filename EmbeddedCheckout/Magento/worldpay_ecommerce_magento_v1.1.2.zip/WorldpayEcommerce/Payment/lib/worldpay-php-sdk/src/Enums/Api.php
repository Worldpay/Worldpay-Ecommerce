<?php

namespace Worldpay\Api\Enums;

/**
 * Integrated Worldpay APIs.
 */
class Api
{
	public const ACCESS_WORLDPAY_HPP_API = 'Hosted Payment Pages (HPP) API';

	public const ACCESS_WORLDPAY_PAYMENTS_API = 'Payments API';

	public const ACCESS_WORLDPAY_PAYMENT_QUERIES_API = 'Payment Queries API';

	public const ACCESS_WORLDPAY_PAYMENT_SESSIONS_API = 'Payment Sessions API';

	public const ACCESS_WORLDPAY_TOKENS_API = 'Tokens API';
}
