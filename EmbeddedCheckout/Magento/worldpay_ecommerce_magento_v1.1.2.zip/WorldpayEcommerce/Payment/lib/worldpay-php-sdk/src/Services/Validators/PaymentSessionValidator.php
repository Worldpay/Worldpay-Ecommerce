<?php

namespace Worldpay\Api\Services\Validators;

class PaymentSessionValidator
{
	/**
	 * CARD_EXPIRY_MONTH_MIN
	 */
	public const CARD_EXPIRY_MONTH_MIN = 1;

	/**
	 * CARD_EXPIRY_MONTH_MAX
	 */
	public const CARD_EXPIRY_MONTH_MAX = 12;

	/**
	 * CARD_EXPIRY_YEAR_MAX
	 */
	public const CARD_EXPIRY_YEAR_MAX = 9999;

}
