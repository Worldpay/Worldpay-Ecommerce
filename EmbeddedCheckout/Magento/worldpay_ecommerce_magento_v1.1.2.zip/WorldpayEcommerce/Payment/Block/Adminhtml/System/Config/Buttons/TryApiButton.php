<?php

namespace WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons;

use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class TryApiButton
 *
 * This class provides the button for testing try API credentials in the Magento admin panel.
 */
class TryApiButton extends BaseApiButton
{
    /**
     * Generates the HTML for the button.
     *
     * @param AbstractElement $element
     * @return string
     */
    public function getButtonHtml(AbstractElement $element): string
    {
        $url = $this->getUrl('worldpay_ecommerce/payment/testApiCredentialsRequest', ['type' => 'try']);
        $fieldIds = [
            'api_try_username' => 'api_try_username',
            'api_try_password' => 'api_try_password',
            'merchant_entity' => 'merchant_entity',
            'api_try_checkout_id' => 'api_try_checkout_id'
        ];

        return $this->configButtonHelper->generateButtonHtml(
            $element,
            __('Validate Try Credentials'),
            $url,
            $fieldIds,
            'try'
        );
    }
}
