<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client\AccessWorldpayHpp;

use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\TransferInterface;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\Helper;
use WorldpayEcommerce\Payment\Gateway\Http\Client\AbstractClient;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\PaymentMethods\WorldpayEcommerceHpp;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

class TransactionInitialize extends AbstractClient
{
    /**
     * Place request.
     *
     * @param  TransferInterface  $transferObject
     *
     * @return array
     * @throws ClientException
     */
    public function placeRequest(TransferInterface $transferObject): array
    {
        $this->requestData           = $transferObject->getBody();
        $this->requestData['locale'] = $this->store->getLocale();
        $dataToLog = [];
        $dataToLog['requestData'] = $this->requestData;
        $apiResponse = null;

        try {
            $this->worldpayService->setPaymentMethodCode($this->requestData['paymentMethodCode']);
            $this->setGuidsAndReturnUrls();
            $this->setTransactionReference();
            $dataToLog = array_merge($dataToLog, $this->output);

            $apiResponse = $this->sendApiRequest();
            if (!$apiResponse->isSuccessful()) {
                throw new \Exception('Something went wrong while processing your payment. Please contact support.');
            }

            $decodedApiResponse = $apiResponse->jsonDecode();
            $this->output['payment']['hppUrl'] = $decodedApiResponse->url ?? '';

            $dataToLog['hppUrl'] = $this->output['payment']['hppUrl'];
            Logger::setDescription('Retrieve Hpp url')->debug($dataToLog);
        } catch (\Exception $e) {
            $message = __($e->getMessage() ?: 'Sorry, but something went wrong');
            $dataToLog['errorMessage'] = $e->getMessage();
            if (isset($apiResponse)) {
                $dataToLog['correlationId'] = $apiResponse->headers
                    ? WorldpayService::getWpCorrelationIdFromHeaders( $apiResponse->headers ) : '';
                $dataToLog['request']       = $apiResponse->rawRequest ?? '';
                $dataToLog['response']      = $apiResponse->rawResponse ?? '';
            }
            Logger::setDescription('HPP response validator - invalid HPP response')->alert($dataToLog);
            throw new ClientException($message);
        }

        return $this->output;
    }

    /**
     * @return ApiResponse
     * @throws AuthenticationException
     * @throws InvalidArgumentException|ApiClientException
     */
    protected function sendApiRequest(): ApiResponse
    {
        return (new WorldpayEcommerceHpp($this->worldpayService, $this->requestData))->initializePayment();
    }

    /**
     * @return void
     * @throws \Exception
     */
    protected function setGuidsAndReturnUrls(): void
    {
        $guids = [
            'success' => Helper::guidv4(),
            'failure' => Helper::guidv4(),
            'cancel'  => Helper::guidv4()
        ];
        $returnUrls = [
            'success' => $this->getReturnUrl($guids['success']),
            'failure' => $this->getReturnUrl($guids['failure']),
            'cancel' => $this->getReturnUrl($guids['cancel']),
        ];
        $this->output['payment']['guids'] = $guids;
        $this->requestData['payment']['returnUrls'] = $returnUrls;
    }

    /**
     * @param  string  $guid
     *
     * @return string
     */
    private function getReturnUrl(string $guid): string
    {
        return $this->url->getUrl(
            'access_worldpay_hpp/process/returnUrl/',
            ['guid' => $guid]
        );
    }
}
