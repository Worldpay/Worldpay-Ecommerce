<?php

namespace WorldpayEcommerce\Payment\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Payment\Gateway\Config\Config as MagentoPaymentConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use Magento\Framework\Filesystem\DirectoryList;

class Config extends MagentoPaymentConfig
{
    /**
     * Payment methods codes.
     */
    public const ACCESS_WORLDPAY_HPP_CODE = "access_worldpay_hpp";
    public const ACCESS_WORLDPAY_CHECKOUT_CODE = "access_worldpay_checkout";

    /**
     * @var string|null
     */
    private ?string $wpMethodCode;

    /**
     * Constructor.
     *
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList         $dir
     * @param  string|null           $methodCode
     * @param  string                $pathPattern
     *
     * @throws FileSystemException
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir,
        ?string $methodCode = null,
        string $pathPattern = MagentoPaymentConfig::DEFAULT_PATH_PATTERN
    ) {
        parent::__construct($scopeConfig, $methodCode, $pathPattern);
        $this->wpMethodCode = $methodCode;
        Logger::config($scopeConfig, $dir);
    }

    public function getMethodCode(): string {
        return (string) $this->wpMethodCode;
    }
}
