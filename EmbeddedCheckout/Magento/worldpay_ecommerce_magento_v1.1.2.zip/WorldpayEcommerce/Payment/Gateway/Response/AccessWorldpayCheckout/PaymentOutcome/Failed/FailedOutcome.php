<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Failed;

use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\AbstractOutcome;
use Worldpay\Api\Enums\PaymentStatus;

class FailedOutcome extends AbstractOutcome
{

    /**
     * @param  InfoInterface  $payment
     * @param  object  $response
     *
     * @return void
     */
    public function setPaymentLinks(InfoInterface $payment, object $response): void {}

    /**
     * @param  Order  $order
     *
     * @return void
     */
    public function handleOrder(Order $order): void
    {
        $this->session->restoreQuote();
        $order->setState(Order::STATE_CANCELED);
        $order->setStatus(Order::STATE_CANCELED);
        $paymentAdditionalInformation = $order->getPayment()->getAdditionalInformation();
        $order->addCommentToStatusHistory($this->handleOrderComment($paymentAdditionalInformation['transactionReference']));
        $this->orderRepositoryInterface->save($order);
    }

    /**
     * @param  string  $transactionReference
     *
     * @return string
     */
    protected function handleOrderComment(string $transactionReference): string
    {
        $comment = 'Payment via Worldpay failed';
        if ($this->outcome === PaymentStatus::THREE_DS_UNAVAILABLE) {
            $comment .= ' because 3DS is unavailable';
        } else if ($this->outcome === PaymentStatus::THREE_DS_AUTHENTICATION_FAILED) {
            $comment .= ' because 3DS authentication failed';
        }

        return sprintf(__($comment.'. Transaction reference: %s')->render(),
            $transactionReference);
    }
}
