<?php
namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayHpp;

use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class ResponseHandler implements HandlerInterface
{

    /**
     * @var SubjectReader
     */
    protected SubjectReader $subjectReader;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     */
    public function __construct(SubjectReader $subjectReader)
    {
        $this->subjectReader = $subjectReader;
    }

    /**
     * Handle response.
     *
     * @param array $handlingSubject
     * @param array $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);
        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();
        $payment->setAdditionalInformation('hppUrl', $response['payment']['hppUrl'] ?? "");
        $payment->setAdditionalInformation('success_guid', $response['payment']['guids']['success'] ?? "");
        $payment->setAdditionalInformation('failure_guid', $response['payment']['guids']['failure'] ?? "");
        $payment->setAdditionalInformation('cancel_guid', $response['payment']['guids']['cancel'] ?? "");
        $payment->setAdditionalInformation('transaction_reference', $response['payment']['transactionReference'] ?? "");

        Logger::setDescription('Details Handler Additional Information')->debug($payment->getAdditionalInformation());
    }
}
