define([
    'jquery'
], function ($) {
    'use strict';
    return function (target) {
        $.validator.addMethod(
            'worldpay-validate-entity',
            function (value) {
                if (value) {
                    return /^[*A-Za-z0-9]+[A-Za-z0-9 ]+$/.test(value);
                }
                return true;
            },
            $.mage.__('Please enter a valid merchant entity.')
        );
        return target;
    };
});
