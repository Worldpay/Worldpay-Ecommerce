define([
    'jquery'
], function ($) {
    'use strict';
    return function (target) {
        $.validator.addMethod(
            'worldpay-validate-narrative',
            function (value) {
                if (value) {
                    return /^[a-zA-Z0-9\-., ]+$/.test(value);
                }
                return true;
            },
            $.mage.__('Please enter a valid merchant narrative. Valid characters are: A-Z, a-z, 0-9, hyphen(-), full stop(.), commas(,), space.')
        );
        return target;
    };
});
