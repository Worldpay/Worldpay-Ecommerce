<?php

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\lib\Service\Logger;

/**
 * Class ConfigButtonHelper
 *
 * This class provides helper methods to generate button HTML
 * and JavaScript for configuration buttons in the Magento admin panel.
 */
class ConfigButtonHelper
{
    /**
     * Retrieves html id for parent container.
     *
     * @param  AbstractElement  $element  The form element.
     * @return array|mixed|null
     */
    public function getContainerHtmlId(AbstractElement $element) {
        $containerHtmlId = $element->getData('container/html_id');
        if (empty($containerHtmlId)) {
            Logger::setDescription('Unable to retrieve system config container id')->debug(['elementId'=>$element->getHtmlId()]);
            return '';
        }

        return $containerHtmlId;
    }

    /**
     * Retrieves field html id from parent container.
     *
     * @param  AbstractElement  $element
     * @param  string  $fieldId
     * @return string
     */
    public function getHtmlIdForFieldId(AbstractElement $element, string $fieldId) {
        $containerHtmlId = $this->getContainerHtmlId($element);

        return !empty($containerHtmlId) ? $containerHtmlId . '_' . $fieldId : '';
    }

    /**
     * Generates HTML for a button with accompanying JavaScript to handle the button's click event.
     *
     * @param  AbstractElement $element     The element from which to derive IDs.
     * @param  string          $buttonText The text to display on the button.
     * @param  string          $url        The URL to target with the AJAX request.
     * @param  array           $fieldIds   Additional fields to include in the AJAX data.
     * @param  string          $mode
     * @return string The complete HTML for the button with script.
     * @return string The complete HTML for the button with script.
     */
    public function generateButtonHtml(
        AbstractElement $element,
        string $buttonText,
        string $url,
        array $fieldIds,
        string $mode
    ): string {
        // Generate the button HTML
        $buttonHtml = '<button id="' . $element->getHtmlId() . '_button" type="button" style="margin-top: 5px;">';
        $buttonHtml .= __($buttonText);
        $buttonHtml .= '</button>';

        // Prepare button selector and field mappings for the JavaScript
        $buttonSelector = '#' . $element->getHtmlId() . '_button';
        $fields = [];
        foreach ($fieldIds as $key => $id) {
            $fields[] = ['key' => $key, 'selector' => '#' . $this->getHtmlIdForFieldId($element, $id)];
        }

        // Generate the JavaScript for handling the button click
        $script = "<script type='text/javascript'>
                        require(['jquery', 'WorldpayEcommerce_Payment/js/worldpay-test-credentials-button'],
                        function ($, configButton) {
                            configButton({
                                buttonSelector: '$buttonSelector',
                                url: '$url',
                                fieldIds: " . json_encode($fields) . ",
                                appMode: '$mode'
                            });
                        });
                    </script>";

        // Return the combined button HTML and script
        return $buttonHtml . $script;
    }

    /**
     * Generates the complete HTML for an element, including the button HTML.
     *
     * @param AbstractElement $element The form element.
     * @param callable $getButtonHtml A callable that generates the button HTML.
     * @return string The complete HTML for the element with the button.
     */
    public function appendButtonHtml(AbstractElement $element, callable $getButtonHtml): string
    {
        // Append the custom button HTML to the existing element HTML
        return $element->getElementHtml() . $getButtonHtml($element);
    }
}
