<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ShippingAddress;
use Worldpay\Api\Entities\Order;

abstract class WC_Worldpay_Payment_Method extends WC_Payment_Gateway {

	use WC_Access_Worldpay_Field_Validators;
	use WC_Access_Worldpay_Credentials_Validators;
	use WC_Worldpay_Ecommerce_String_Utils;

	/**
	 * @var string
	 */
	public $api;

	/**
	 * Api config provider.
	 *
	 * @var AccessWorldpayConfigProvider
	 */
	protected $api_config_provider;

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->init_form_fields();
		$this->init_settings();

		if ( is_admin() && ( strtolower( $this->id ) === wc_clean( sanitize_text_field( wp_unslash( $_GET['section'] ?? '' ) ) ) ) ) {
			woocommerce_worldpay_ecommerce_compatibility_check();
		}

		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		if ( is_admin() ) {
			$this->add_admin_hooks();
		}

		$error = empty( $_GET[ $this->id ] ) ? '' : wc_clean( sanitize_text_field( wp_unslash( $_GET[ $this->id ] ) ) );
		if ( ! empty( $error ) ) {
			add_filter(
				'woocommerce_checkout_init',
				function () {
					wc_print_notice( 'Something went wrong while processing your payment. Please try again.', 'error' );
				}
			);
		}
		add_action(
			'woocommerce_api_worldpay_ecommerce_test_api_credentials',
			array(
				$this,
				'test_api_credentials_request',
			)
		);
	}

	/**
	 * Add admin hooks.
	 *
	 * @return void
	 */
	public function add_admin_hooks() {
		add_action(
			'woocommerce_update_options_payment_gateways_' . $this->id,
			array( $this, 'process_admin_options' )
		);

		add_filter( 'woocommerce_generate_masked_totally_html', array( $this, 'generate_masked_totally_html' ) );
		add_filter( 'woocommerce_generate_masked_partially_html', array( $this, 'generate_masked_partially_html' ) );

		add_filter( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		add_action(
			'woocommerce_update_options_payment_gateways_' . $this->id,
			array( $this, 'test_api_credentials_save' )
		);
	}

	/**
	 * Generate html for custom masked password type.
	 *
	 * @param $key
	 * @param $data
	 *
	 * @return false|string
	 */
	public function generate_masked_totally_html( $key, $data ) {
		return $this->generate_masked_partially_html( $key, $data );
	}

	/**
	 * Generate html for custom masked text type.
	 *
	 * @param $key
	 * @param $data
	 *
	 * @return false|string
	 */
	public function generate_masked_partially_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data        = wp_parse_args( $data, $defaults );
		$field_value = $this->get_option( $key );
		if ( 'masked_totally' === $data['type'] ) {
			$field_value = $this->limit(
				$this->mask( $field_value, '*', 0, $this->length( $field_value, 'UTF-8' ) ),
				64,
				''
			);
		} else {
			$field_value = $this->mask( $field_value, '*', 0, $this->length( $field_value, 'UTF-8' ) - 4 );
		}
		$data['type'] = 'text';
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?>
					<?php
					echo wp_kses_post( $this->get_tooltip_html( $data ) );
					?>
				</label>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span>
					</legend>
					<input class="input-text regular-input <?php echo esc_attr( $data['class'] ); ?>"
							type="<?php echo esc_attr( $data['type'] ); ?>" name="<?php echo esc_attr( $field_key ); ?>"
							id="<?php echo esc_attr( $field_key ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>"
							value="<?php echo esc_html( $field_value ); ?>"
							placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>"
						<?php disabled( $data['disabled'] ); ?>
						<?php
						echo wp_kses_post( $this->get_custom_attribute_html( $data ) ); // WPCS: XSS ok.
						?>
					/>
					<?php echo wp_kses_post( $this->get_description_html( $data ) ); ?>
				</fieldset>
			</td>
		</tr>
		<?php

		return ob_get_clean();
	}

	/**
	 * Add admin scripts.
	 *
	 * @param string $hook_suffix current admin page.
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts( $hook_suffix ) {
		if ( 'woocommerce_page_wc-settings' !== $hook_suffix ) {
			return;
		}
		$current_tab = sanitize_text_field( wp_unslash( $_GET['tab'] ?? '' ) );
		if ( 'checkout' !== $current_tab ) {
			return;
		}

		$current_section = sanitize_text_field( wp_unslash( $_GET['section'] ?? '' ) );
		if ( $this->id !== $current_section ) {
			return;
		}

		wp_enqueue_script(
			'worldpay-ecommerce-admin',
			woocommerce_worldpay_ecommerce_url( '/assets/admin/js/worldpay-ecommerce-admin.js' ),
			array( 'jquery' ),
			WC()->version,
			true
		);
		wp_localize_script(
			'worldpay-ecommerce-admin',
			'worldpay_ecommerce_admin_params',
			array(
				'_wpnonce'                 => wp_create_nonce( 'worldpay-ecommerce-test_api_credentials' ),
				'test_api_credentials_url' => WC()->api_request_url( 'worldpay_ecommerce_test_api_credentials' ),
				'payment_method_id'        => $this->id,
			)
		);
	}

	/**
	 * Initialize PHP SDK for payment gateway.
	 *
	 * @return AccessWorldpay
	 * @throws AuthenticationException
	 */
	public function initiliaze_api() {
		$this->configure_proxy();

		if ( $this->api_config_provider instanceof AccessWorldpayConfigProvider ) {
			return AccessWorldpay::config( $this->api_config_provider );
		}

		return AccessWorldpay::config( $this->configure_api() );
	}

	/**
	 * Configure API for payment gateway request.
	 *
	 * @return AccessWorldpayConfigProvider|null
	 */
	public function configure_api() {
		$api_config_provider                    = AccessWorldpayConfigProvider::instance();
		$api_config_provider->environment       = $this->get_api_environment();
		$api_config_provider->username          = $this->get_api_username();
		$api_config_provider->password          = $this->get_api_password();
		$api_config_provider->merchantEntity    = $this->get_merchant_entity();
		$api_config_provider->merchantNarrative = $this->get_merchant_narrative();
		$api_config_provider->api               = $this->api;

		return $api_config_provider;
	}

	/**
	 * Configure proxy for API requests.
	 *
	 * @return void
	 */
	public function configure_proxy() {
		$proxy_config_provider = ProxyConfigProvider::instance();

		$wp_proxy = new WP_HTTP_Proxy();
		if ( $wp_proxy->is_enabled() ) {
			$proxy_config_provider->host = $wp_proxy->host();
			$proxy_config_provider->port = $wp_proxy->port();
			if ( $wp_proxy->use_authentication() ) {
				$proxy_config_provider->proxyUsername = $wp_proxy->username();
				$proxy_config_provider->proxyPassword = $wp_proxy->password();
			}
		}
	}

	/**
	 * Get API environment - test or live.
	 *
	 * @return string
	 */
	public function get_api_environment() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			Environment::LIVE_MODE :
			Environment::TRY_MODE;
	}

	/**
	 * Get API username for test or live environment.
	 *
	 * @return string
	 */
	public function get_api_username() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			$this->get_option( 'app_api_live_username' ) :
			$this->get_option( 'app_api_try_username' );
	}

	/**
	 * Get API password for test or live environment.
	 *
	 * @return string
	 */
	public function get_api_password() {
		return wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) ?
			$this->get_option( 'app_api_live_password' ) :
			$this->get_option( 'app_api_try_password' );
	}

	/**
	 * Get API merchant entity.
	 *
	 * @return string
	 */
	public function get_merchant_entity() {
		return $this->get_option( 'app_merchant_entity' );
	}

	/**
	 * Get API merchant narrative.
	 *
	 * @return string
	 */
	public function get_merchant_narrative() {
		return $this->get_option( 'app_merchant_narrative' );
	}

	/**
	 * Get APP debug mode
	 *
	 * @return bool
	 */
	public function get_merchant_debug_mode() {
		return wc_string_to_bool( $this->get_option( 'app_debug' ) );
	}

	/**
	 * Get order data for API order initialization.
	 *
	 * @param  WC_Order $wc_order
	 *
	 * @return Order
	 */
	public function get_order_data( WC_Order $wc_order ) {
		$wc_order_data              = $wc_order->get_data();
		$api_order                  = new Order();
		$api_order->id              = $wc_order->get_id();
		$api_order->billingAddress  = $this->get_order_address( $wc_order_data, 'billing' );
		$api_order->shippingAddress = $this->get_order_address( $wc_order_data, 'shipping' );
		$api_order->customer        = $this->get_order_customer( $wc_order_data );
		$api_order->currency        = $wc_order->get_currency();

		return $api_order;
	}

	/**
	 * Get billing/shipping address for API order initialization.
	 *
	 * @param  int    $order_id
	 * @param  array  $wc_order_data
	 * @param  string $address_type
	 *
	 * @return BillingAddress|ShippingAddress
	 */
	public function get_order_address( array $wc_order_data, string $address_type ) {
		$api_address              = 'billing' === $address_type ?
			new BillingAddress() :
			new ShippingAddress();
		$api_address->address1    = $wc_order_data[ $address_type ]['address_1'] ?? '';
		$api_address->address2    = $wc_order_data[ $address_type ]['address_2'] ?? '';
		$api_address->address3    = '';
		$api_address->postalCode  = $wc_order_data[ $address_type ]['postcode'] ?? '';
		$api_address->city        = $wc_order_data[ $address_type ]['city'] ?? '';
		$api_address->state       = $wc_order_data[ $address_type ]['state'] ?? '';
		$api_address->countryCode = $wc_order_data[ $address_type ]['country'] ?? '';

		return $api_address;
	}

	/**
	 * Get customer details for API order initialization.
	 *
	 * @param  array $wc_order_data
	 *
	 * @return Customer
	 */
	public function get_order_customer( array $wc_order_data ) {
		$api_customer              = new Customer();
		$api_customer->firstName   = $wc_order_data['billing']['first_name'] ?? '';
		$api_customer->lastName    = $wc_order_data['billing']['last_name'] ?? '';
		$api_customer->email       = $wc_order_data['billing']['email'] ?? '';
		$api_customer->phoneNumber = $wc_order_data['billing']['phone'] ?? '';

		return $api_customer;
	}
}
