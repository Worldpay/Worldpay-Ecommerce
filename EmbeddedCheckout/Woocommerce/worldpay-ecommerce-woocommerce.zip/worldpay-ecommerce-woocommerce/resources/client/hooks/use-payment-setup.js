/**
 * External dependencies.
 */
import { __ } from '@wordpress/i18n';
import { useEffect } from '@wordpress/element';

/**
 * Internal dependencies.
 */
import { generatePaymentSession } from "../checkout-sdk/generate-session";
import { getCardHolderName } from "../form/helper";

/**
 *
 * @param checkout
 * @param emitResponse
 * @param onPaymentSetup
 * @param cardHolderName
 * @param setCardHolderName
 * @constructor
 */
const UseOnPaymentSetup = (
	checkout,
	emitResponse,
	onPaymentSetup,
	cardHolderName,
	setCardHolderName
) => {
	useEffect( () => {
		const unsubscribe = onPaymentSetup( async () => {
			if ( typeof checkout === 'undefined' || checkout === null ) {
				return {
					type: emitResponse.responseTypes.ERROR,
					message: __(
						'Something went wrong while processing your payment. Please try again.',
						'worldpay-ecommerce-woocommerce'
					),
				};
			}

			try {
				let cardHolderName = getCardHolderName();
				const sessionResponse = await generatePaymentSession( checkout );

				return {
					type: emitResponse.responseTypes.SUCCESS,
					meta: {
						paymentMethodData: {
							sessionState: sessionResponse,
							card_holder_name: cardHolderName
						}
					}
				};
			} catch ( error ) {
				let errorMessage = __(
					'Something went wrong while processing your payment. Please try again.',
					'worldpay-ecommerce-woocommerce'
				);
				console.error( error );
				if ( ( typeof error === 'string' || error instanceof String ) && error.includes( 'invalidForm' )
					|| ( error.hasOwnProperty( 'message' ) && error.message.includes( 'invalidForm' ) ) ) {
					errorMessage = __(
						'The payment form is invalid or incomplete.',
						'worldpay-ecommerce-woocommerce'
					);
				}

				return {
					type: emitResponse.responseTypes.ERROR,
					message: errorMessage,
				};
			}
		} );

		return unsubscribe;
	}, [
		checkout,
		onPaymentSetup
	] );
};

export { UseOnPaymentSetup }
