/**
 * External dependencies
 */
import { useEffect } from '@wordpress/element';

/**
 * Internal dependencies
 */
import { listen3dsChallengeMessage } from "../checkout-sdk/challenge";
import { listen3dsDeviceDataMessage } from "../checkout-sdk/ddc";
import { submit3dsDeviceData } from "../api";
import {
	disableBlocksCheckoutForm,
	enableBlocksCheckoutForm
} from "../form/helper";

/**
 *
 * @param onCheckoutSuccess
 * @param emitResponse
 * @param checkout
 * @param setDdcFormUrl
 * @param setChallengeFormUrl
 * @param setChallengeFormWidth
 * @param setChallengeFormHeight
 * @param setCardHolderName
 * @constructor
 */
const UseOnCheckoutSuccess = (
	onCheckoutSuccess,
	emitResponse,
	checkout,
	setDdcFormUrl,
	setChallengeFormUrl,
	setChallengeFormWidth,
	setChallengeFormHeight,
	setCardHolderName
) => {
	useEffect( () => {
		const unsubscribe = onCheckoutSuccess( async ( { processingResponse: { paymentDetails, paymentStatus } } ) => {
			if ( 'pending' !== paymentStatus ) {
				return true;
			}

			if ( access_worldpay_checkout_params.threeDSDataRequiredStatus === paymentDetails.outcome ) {
				disableBlocksCheckoutForm();
				setDdcFormUrl( paymentDetails.deviceDataCollectionUrl );
				const result = await listen3dsDeviceDataMessage()
					.then( async( ddcResponse ) => {
						return await submit3dsDeviceData( ddcResponse );
					});

				if ( 'success' === result.result ) {
					if ( access_worldpay_checkout_params.authorizedStatus === result.outcome
						|| access_worldpay_checkout_params.sentForSettlementStatus === result.outcome ) {
						return true;
					}
					if ( access_worldpay_checkout_params.threeDSDataChallengedStatus == result.outcome
						&& result.challengeUrl ) {
						// setup challenge form iframe
						let challengeWindowSize = result.challengeWindowSize ?? '';
						if ( challengeWindowSize ){
							setChallengeFormWidth( challengeWindowSize.width );
							setChallengeFormHeight( challengeWindowSize.height );
						}
						setChallengeFormUrl( result.challengeUrl );
						enableBlocksCheckoutForm();
						const challengeResponse = await listen3dsChallengeMessage();
						if ( 'success' === challengeResponse.result ) {
							return true;
						}

						setDdcFormUrl();
						setChallengeFormUrl();
						return {
							type: emitResponse.responseTypes.FAIL,
							messageContext: emitResponse.noticeContexts.PAYMENTS,
							message: challengeResponse.messages,
						};
					}
				} else {
					enableBlocksCheckoutForm();
					setDdcFormUrl();
					return {
						type: emitResponse.responseTypes.FAIL,
						messageContext: emitResponse.noticeContexts.PAYMENTS,
						message: result.messages,
					};
				}
			}

			return true;
		} );
		return unsubscribe;
	}, [ checkout, onCheckoutSuccess ] );
};

export { UseOnCheckoutSuccess }
