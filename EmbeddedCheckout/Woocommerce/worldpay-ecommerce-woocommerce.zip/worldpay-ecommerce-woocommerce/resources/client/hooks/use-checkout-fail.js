/**
 * External dependencies
 */
import { useEffect } from '@wordpress/element';

/**
 *
 * @param onCheckoutFail
 * @param emitResponse
 * @param checkout
 * @param setDdcFormUrl
 * @param setCardHolderName
 * @constructor
 */
const UseOnCheckoutFail = (
	onCheckoutFail,
	emitResponse,
	checkout,
	setDdcFormUrl,
	setCardHolderName
) => {
	useEffect( () => {
		const unsubscribe = onCheckoutFail( ( { processingResponse: { paymentDetails, paymentStatus } } ) => {
			if ( 'failure' !== paymentStatus ) {
				return true;
			}
			setDdcFormUrl();
			return {
				type: emitResponse.responseTypes.FAIL,
				messageContext: emitResponse.noticeContexts.PAYMENTS,
				message: paymentDetails.messages,
			};
		} );
		return unsubscribe;
	}, [ checkout, onCheckoutFail ] );
};

export { UseOnCheckoutFail }
