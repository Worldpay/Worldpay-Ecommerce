/**
 * External dependencies
 */
import $ from 'jquery';

/**
 *
 * @param sessionId
 * @returns {*|jQuery}
 */
export const submit3dsDeviceData = ( sessionId ) => {
	return $.ajax( {
		type: 'POST',
		url: access_worldpay_checkout_params.submitThreeDsDeviceDataEndpoint,
		data: { collectionReference: sessionId },
		dataType: 'json',
	} );
}
