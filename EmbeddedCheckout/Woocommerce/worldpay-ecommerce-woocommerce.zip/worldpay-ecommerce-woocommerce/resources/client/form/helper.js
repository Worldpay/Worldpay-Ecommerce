/**
 * External dependencies
 */
import $ from 'jquery';
import { __ } from '@wordpress/i18n';

/**
 * Disable checkout form.
 */
export const disableBlocksCheckoutForm = () => {
	document.querySelector( 'form.wc-block-components-form.wc-block-checkout__form' ).classList.add( 'wc-block-components-checkout-step--disabled' );
	document.querySelectorAll( 'form.wc-block-components-form.wc-block-checkout__form > *' ).forEach( ( input ) => {
		input.style.pointerEvents = 'none';
	} );
};

/**
 * Enable checkout form.
 */
export const enableBlocksCheckoutForm = () => {
	document.querySelector( 'form.wc-block-components-form.wc-block-checkout__form' ).classList.remove( 'wc-block-components-checkout-step--disabled' );
	document.querySelectorAll( 'form.wc-block-components-form.wc-block-checkout__form > *' ).forEach( ( input ) => {
		input.style.pointerEvents = '';
	} );
};

/**
 *
 * @returns {*|jQuery}
 */
export const getCardHolderName = () => {
	let cardHolderName = $( '#access_worldpay_checkout-card-holder-name' ).val();
	if ( cardHolderName.trim().length === 0 || cardHolderName.length > 255 ) {
		throw new Error( __( 'invalidForm: Card holder name is invalid.' ) );
	}

	return cardHolderName;
}
