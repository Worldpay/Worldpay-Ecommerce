/**
 * External dependencies
 */
import clsx from 'clsx';
import { __ } from '@wordpress/i18n';
import { TextInput } from '@woocommerce/blocks-components';

/**
 * Get a class name for a card field.
 *
 * @param id
 */
const getCardFieldClassName = ( id ) => {
	return `wc-${ id }-element`;
};

/**
 * Get an Id for a card field.
 *
 * @param id
 */
const getCardFieldId = ( id ) => {
	return `access_worldpay_checkout-${ id }`;
};

/**
 * Renders payment method title.
 *
 * @param text
 * @param icons
 * @returns {Element}
 * @constructor
 */
export const PaymentMethodTitle = ( { text, icons =[] } ) => {
	return (
		<>
			<span className={ 'wc-block-components-payment-method-label' }
				  style={ { width: '100%' } } >
				{ text }
				<span className="access_worldpay_checkout-payment-method-images">
					{ icons.map( ( icon ) => {
						return (
							<img
								key={ 'access_worldpay_checkout-' + icon.id }
								src={ icon.src }
								alt={ icon.alt }
								className={ icon.class } />
						)
					} ) }
				</span>
			</span>
		</>
	);
}

/**
 * Renders environment indicator when in Try mode.
 *
 * @returns {Element}
 * @constructor
 */
export const EnvironmentIndicator = () => {
	return (
		<div className={ 'woocommerce-access_worldpay_checkout-info' }>
			<strong>Test Mode</strong> - This is not a live transaction.
		</div>
	);
}

/**
 * Renders payment form.
 *
 * @param children
 * @returns {JSX.Element}
 * @constructor
 */
export const PaymentMethodFields = ( { children } ) => {
	return (
		<div className="wc-block-card-elements"> { children } </div>
	);
}

/**
 * Renders payment field.
 *
 * @param id
 * @param label
 * @returns {JSX.Element}
 * @constructor
 */
export const PaymentMethodField = ( { id, label } ) => {
	const className = clsx( 'wc-block-gateway-container', getCardFieldClassName( id ) );
	const fieldId = getCardFieldId( id );

	return (
		<div className={ className }>
			<div id={ fieldId } className="wc-block-gateway-input field"></div>
			<label htmlFor={ fieldId }>
				{ label }
			</label>
		</div>
	);
}

/**
 * Renders cardholder name input.
 *
 * @param cardHolderName
 * @param setCardHolderName
 * @returns {Element}
 * @constructor
 */
export const CardHolderName = ( { cardHolderName, setCardHolderName } ) => {
	return (
		<TextInput
			className={ 'wc-card-holder-name-element' }
			id={ 'access_worldpay_checkout-card-holder-name' }
			type={ 'text' }
			autoComplete={ 'off' }
			required={ true }
			label={ __( 'Card Holder Name', 'worldpay-ecommerce-woocommerce' ) }
			value={ cardHolderName }
			onChange={ ( value ) => { setCardHolderName( value ) } }
			maxLength={ '255' }
		/>
	);
};
