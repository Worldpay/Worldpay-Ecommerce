const generatePaymentSession = ( checkout )  => {
	return new Promise(( resolve, reject ) => {
		( function () {
			checkout.generateSessionState(
				function ( error, session ) {
					if ( error ) {
						reject( error );
					}
					resolve( session );
				} );
		} )();
	} );
};

export { generatePaymentSession };
