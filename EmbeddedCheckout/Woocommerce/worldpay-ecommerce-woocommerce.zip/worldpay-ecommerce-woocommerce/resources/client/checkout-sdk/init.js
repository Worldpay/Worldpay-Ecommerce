const checkoutSDKInitPromise = ( checkoutId )  => {
	return new Promise(( resolve, reject ) => {
		( function () {
			window.Worldpay.checkout.init(
				{
					id: checkoutId,
					form: "form.wc-block-components-form",
					fields: {
						pan: {
							selector: "#access_worldpay_checkout-card-number",
							placeholder: "4444 3333 2222 1111"
						},
						expiry: {
							selector: "#access_worldpay_checkout-card-expiry",
							placeholder: "MM/YY"
						},
						cvv: {
							selector: "#access_worldpay_checkout-card-cvc",
							placeholder: "123"
						}
					},
					styles: {
						"input": {
							"color": "black",
							"font-weight": "bold",
							"font-size": "15px",
							"letter-spacing": "3px"
						},
						"input.is-valid": {
							"color": "green !important"
						},
						"input.is-invalid": {
							"color": "red !important"
						},
						"input.is-onfocus": {
							"color": "black !important"
						}
					},
					acceptedCardBrands: access_worldpay_checkout_params.card_brands,
					enablePanFormatting: true
				},
				function ( error, checkout ) {
					if ( error ) {
						reject( error );
					} else {
						resolve( checkout );
					}
				},
			);
		})();
	});
};

export { checkoutSDKInitPromise };