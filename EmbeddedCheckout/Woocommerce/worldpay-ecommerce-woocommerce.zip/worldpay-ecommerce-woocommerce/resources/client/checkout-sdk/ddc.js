const listen3dsDeviceDataMessage = () => new Promise( ( resolve ) => {
	let timeoutID;
	const listener = ( event ) => {
		if ( access_worldpay_checkout_params.threeDSAuthenticationApplicationUrl !== event.origin ) {
			return false;
		}
		let postMessage = JSON.parse( event.data );
		if ( 'undefined' === postMessage.MessageType || 'profile.completed' !== postMessage.MessageType ) {
			return false;
		}

		clearTimeout( timeoutID );
		if ( 'undefined' !== postMessage.Status && true === postMessage.Status ) {
			resolve( postMessage.SessionId );
		}

		resolve( null );
	}
	window.addEventListener( 'message', listener, false );

	timeoutID = setTimeout(function() {
		window.removeEventListener( 'message', listener, false );
		resolve( null );
	}, 10000 );


	return () => {
		clearTimeout( timeoutID );
		window.removeEventListener( 'message', listener, false );
	};
} );

const SetupDDCFormIframe = ( props ) => {
	return (
		<div id="access_worldpay_checkout-ddc-iframe">
			<iframe height="1" width="1" style={{ display: 'none' }} src={ props.ddcFormUrl }></iframe>
		</div>
	);
}

export { listen3dsDeviceDataMessage, SetupDDCFormIframe };
