/**
 *
 * @returns {Promise<unknown>}
 */
const listen3dsChallengeMessage = () => new Promise( ( resolve ) => {
	const listener = ( event ) => {
		if ( typeof event.detail.data === 'undefined' ) {
			return false;
		}
		let challengeResponseData = JSON.parse( event.detail.data );
		resolve( challengeResponseData );
	}
	window.addEventListener( 'access_worldpay_checkout_payment_3ds_completed', listener, false );

	return () => {
		window.removeEventListener( 'access_worldpay_checkout_payment_3ds_completed', listener, false );
	};
} );

/**
 *
 * @param challengeFormUrl
 * @param challengeFormWidth
 * @param challengeFormHeight
 * @returns {JSX.Element}
 * @constructor
 */
const SetupChallengeFormIframe = ( { challengeFormUrl, challengeFormWidth, challengeFormHeight } ) => {
	const modalStyle = {
		width: challengeFormWidth ? `${ challengeFormWidth }px` : '',
		height: challengeFormHeight ? `${ challengeFormHeight }px` : '',
		display: 'block',
	}

	return (
		<>
			<div id="access_worldpay_checkout-modal-overlay" style={ { display: 'block' } }></div>
			<div id="access_worldpay_checkout-modal" style={ modalStyle }>
				<div id="access_worldpay_checkout-modal-content">
					<iframe width="100%" height="100%" src={ challengeFormUrl }></iframe>
				</div>
			</div>
		</>
	);
}

export { SetupChallengeFormIframe, listen3dsChallengeMessage };
