<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Access_Worldpay_Form_Fields {

	/**
	 * Initialise settings form fields.
	 *
	 * @return array
	 */
	public static function init_form_fields() {
		return array(
			'general_settings'         => array(
				'type'  => 'title',
				'title' => __( 'General Settings', 'worldpay-ecommerce-woocommerce' ),
			),
			'enabled'                  => array(
				'title'   => __( 'Enable/Disable', 'worldpay-ecommerce-woocommerce' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Worldpay Payments Offsite', 'worldpay-ecommerce-woocommerce' ),
				'default' => false,
			),
			'title'                    => array(
				'title'       => __( 'Title', 'worldpay-ecommerce-woocommerce' ),
				'type'        => 'text',
				'description' => __(
					'Payment method title that the customer will see at checkout.',
					'worldpay-ecommerce-woocommerce'
				),
				'default'     => __( 'Pay with Card (Worldpay)', 'worldpay-ecommerce-woocommerce' ),
				'desc_tip'    => true,
			),
			'description'              => array(
				'title'       => __( 'Description', 'worldpay-ecommerce-woocommerce' ),
				'type'        => 'textarea',
				'description' => __(
					'Payment method description that the customer will see at checkout.',
					'worldpay-ecommerce-woocommerce'
				),
				'default'     => __( 'Pay with Credit Card or Mobile Wallets ', 'worldpay-ecommerce-woocommerce' ),
				'desc_tip'    => true,
			),
			'is_live_mode'             => array(
				'title'       => __( 'Enable live mode', 'worldpay-ecommerce-woocommerce' ),
				'type'        => 'checkbox',
				'description' => __(
					'Choose between try/test or live/production mode which will influence the used credentials.',
					'worldpay-ecommerce-woocommerce'
				),
			),
			'app_webhooks'             => array(
				'title'       => __( 'Enable webhooks', 'worldpay-ecommerce-woocommerce' ),
				'type'        => 'checkbox',
				'description' => __(
					'Log into your <a href="https://dashboard.worldpay.com/" target="_blank" rel="noopener noreferrer">Worldpay Dashboard</a> and set the following URL ' . self::get_events_url(),
					'worldpay-ecommerce-woocommerce'
				),
				'label'       => __(
					'Receive status updates from Access Worldpay by setting up a webhook.',
					'worldpay-ecommerce-woocommerce'
				),
			),
			'Merchant Settings'        => array(
				'type'  => 'title',
				'title' => __( 'Merchant Settings', 'worldpay-ecommerce-woocommerce' ),
			),
			'app_merchant_entity'      => array(
				'title'             => __( 'Merchant entity *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'masked_partially',
				'description'       => __(
					'Format: POxxxxxxx <br> You can find your entity in your <a href="https://dashboard.worldpay.com/" target="_blank" rel="noopener noreferrer">Worldpay Dashboard</a> under the Developer Tools tab.',
					'worldpay-ecommerce-woocommerce'
				),
				'custom_attributes' => array(
					'required'     => 'required',
					'minlength'    => 1,
					'maxlength'    => 32,
					'autocomplete' => 'off',
				),
			),
			'app_merchant_narrative'   => array(
				'title'             => __( 'Merchant narrative *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'text',
				'description'       => __(
					'Helps your customers better identify you on their statement.' .
					' Valid characters are: A-Z, a-z, 0-9, hyphen(-), full stop(.), commas(,), space.',
					'worldpay-ecommerce-woocommerce'
				),
				'custom_attributes' => array(
					'required'  => 'required',
					'minlength' => 1,
					'maxlength' => 24,
				),
			),
			'app_merchant_description' => array(
				'title'             => __( 'Merchant description', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'text',
				'description'       => __(
					'An optional text, when supplied is displayed to your customer on payment pages',
					'worldpay-ecommerce-woocommerce'
				),
				'custom_attributes' => array(
					'minlength' => 1,
					'maxlength' => 128,
				),
			),
			'try_settings'             => array(
				'type'  => 'title',
				'title' => __( 'Try API Credentials', 'worldpay-ecommerce-woocommerce' ),
			),
			'app_api_try_username'     => array(
				'title'             => __( 'Username *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'text',
				'custom_attributes' => array(
					'required'     => 'required',
					'autocomplete' => 'off',
				),
			),
			'app_api_try_password'     => array(
				'title'             => __( 'Password *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'masked_totally',
				'description'       => __(
					'Get your credentials from your <a href="https://dashboard.worldpay.com/" target="_blank" rel="noopener noreferrer">Worldpay Dashboard</a> under the Developer Tools tab.',
					'worldpay-ecommerce-woocommerce'
				),
				'custom_attributes' => array(
					'required'     => 'required',
					'autocomplete' => 'off',
				),
			),
			'test_try_credentials'     => array(
				'label'             => __( 'Test try credentials', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'button',
				'class'             => 'button-primary worldpay-ecommerce-test-credentials',
				'default'           => __( 'Test try credentials', 'worldpay-ecommerce-woocommerce' ),
				'css'               => 'width: 150px',
				'custom_attributes' => array( 'data-app-mode' => 'try' ),
			),
			'live_settings'            => array(
				'type'  => 'title',
				'title' => __( 'Live API Credentials', 'worldpay-ecommerce-woocommerce' ),
			),
			'app_api_live_username'    => array(
				'title'             => __( 'Username *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'text',
				'custom_attributes' => array( 'autocomplete' => 'off' ),
			),
			'app_api_live_password'    => array(
				'title'             => __( 'Password *', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'masked_totally',
				'description'       => __(
					'Get your credentials from your <a href="https://dashboard.worldpay.com/" target="_blank" rel="noopener noreferrer">Worldpay Dashboard</a> under the Developer Tools tab.',
					'worldpay-ecommerce-woocommerce'
				),
				'custom_attributes' => array( 'autocomplete' => 'off' ),
			),
			'test_live_credentials'    => array(
				'label'             => __( 'Test live credentials', 'worldpay-ecommerce-woocommerce' ),
				'type'              => 'button',
				'class'             => 'button-primary worldpay-ecommerce-test-credentials',
				'default'           => __( 'Test live credentials', 'worldpay-ecommerce-woocommerce' ),
				'css'               => 'width: 150px',
				'custom_attributes' => array( 'data-app-mode' => 'live' ),
			),
			'debug_settings'           => array(
				'type'  => 'title',
				'title' => __( 'Debug', 'worldpay-ecommerce-woocommerce' ),
			),
			'app_debug'                => array(
				'title'       => __( 'Debug mode', 'worldpay-ecommerce-woocommerce' ),
				'type'        => 'checkbox',
				'label'       => __( 'Debug', 'worldpay-ecommerce-woocommerce' ),
				'description' => __( 'Debug your connection to Worldpay.', 'worldpay-ecommerce-woocommerce' ),
			),
		);
	}

	/**
	 * Returns the webhook destination (URL) for receiving status updates from Access Worldpay via webhooks.
	 *
	 * @return string
	 */
	public static function get_events_url() {
		return WC()->api_request_url( 'worldpay_events' );
	}
}
