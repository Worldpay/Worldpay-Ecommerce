<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library;

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';

use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\Address;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;

class WorldpayService {
	public const TRANSACTION_STATUS_SUCCESS 	= 'success';
	public const TRANSACTION_STATUS_FAILED 		= 'failed';
	public const TRANSACTION_STATUS_PENDING 	= 'pending';
	public const TRANSACTION_STATUS_CANCELED 	= 'canceled';

	/**
	 * OpenCart order statuses ids.
	 */
	public const OC_ORDER_STATUS_ID_PROCESSING = 2;
	public const OC_ORDER_STATUS_ID_FAILED = 10;
	public const OC_ORDER_STATUS_ID_PENDING = 1;

	/**
	 * @var object|\Opencart\System\Engine\Registry
	 */
	protected $registry;

	/**
	 * Constructor
	 *
	 * @param object $registry
	 */
	public function __construct(\Opencart\System\Engine\Registry $registry) {
		$this->registry = $registry;
	}

	/**
	 * @param $key
	 *
	 * @return mixed|object|null
	 */
	public function __get($key) {
		return $this->registry->get($key);
	}

	/**
	 * @return AccessWorldpay
	 */
	public function initializeApi() {
		$this->configureProxy();
		if ($this->api_config_provider instanceof AccessWorldpayConfigProvider) {
			return AccessWorldpay::config($this->api_config_provider);
		}

		return AccessWorldpay::config($this->configureApi());
	}

	/**
	 * @return AccessWorldpayConfigProvider|mixed|null
	 */
	public function configureApi() {
		$api_config_provider                    = AccessWorldpayConfigProvider::instance();
		$api_config_provider->environment       = $this->getApiEnvironment();
		$api_config_provider->username          = $this->getApiUsername();
		$api_config_provider->password          = $this->getApiPassword();
		$api_config_provider->merchantEntity    = $this->getMerchantEntity();
		$api_config_provider->merchantNarrative = $this->getMerchantNarrative();

		return $api_config_provider;
	}

	/**
	 * @param array  $order_data
	 * @param string $address_type
	 *
	 * @return Address|null
	 */
	public static function getOrderAddress(array $order_data = [], string $address_type = ''): ?Address {
		if (!in_array($address_type, ["payment", "shipping"]) || empty($order_data)) {
			return null;
		}

		$address = $address_type === 'payment' ? new BillingAddress() : new ShippingAddress();
		$address->address1		= $order_data[$address_type . '_address_1'] ?? '';
		$address->address2		= $order_data[$address_type . '_address_2'] ?? '';
		$address->address3		= '';
		$address->postalCode	= $order_data[$address_type . '_postcode'] ?? '';
		$address->city			= $order_data[$address_type . '_city'] ?? '';
		$address->state			= $order_data[$address_type . '_zone'] ?? '';
		$address->countryCode	= $order_data[$address_type . '_iso_code_2'] ?? '';

		return $address;
	}

	/**
	 * @param array $order_data
	 *
	 * @return Customer
	 */
	public static function getOrderCustomer(array $order_data = []): Customer {
		$customer = new Customer();
		$customer->firstName	= $order_data['firstname'] ?? '';
		$customer->lastName		= $order_data['lastname'] ?? '';
		$customer->email		= $order_data['email'] ?? '';
		$customer->phoneNumber	= $order_data['telephone'] ?? '';

		return $customer;
	}

	/**
	 * @param array $order_data
	 *
	 * @throws \Worldpay\Api\Exceptions\InvalidArgumentException
	 *
	 * @return Order
	 */
	public function getOrderData(array $order_data = []): Order {
		$order = new Order();
		$order->id				= $order_data["id"] ?? "";
		$order->billingAddress	= self::getOrderAddress($order_data, 'payment');
		$order->shippingAddress	= self::getOrderAddress($order_data, 'shipping');
		$order->customer		= self::getOrderCustomer($order_data);
		$order->currency		= $order_data["currency_code"] ?? "";
		$order->amount			= AmountHelper::decimalToExponentDelimiter($order_data["total"]) ?? "";

		return $order;
	}

	/**
	 * @param string $success_return_url
	 * @param string $failure_return_url
	 * @param string $cancel_return_url
	 *
	 * @return ResultURLs
	 */
	public function getResultUrls(string $success_return_url, string $failure_return_url, string $cancel_return_url): ResultURLs {
		$resultUrls = new ResultURLs();
		$resultUrls->successURL	= $success_return_url;
		$resultUrls->errorURL	= $failure_return_url;
		$resultUrls->failureURL	= $failure_return_url;
		$resultUrls->pendingURL	= $failure_return_url;
		$resultUrls->expiryURL	= $failure_return_url;
		$resultUrls->cancelURL	= $cancel_return_url;

		return $resultUrls;
	}

	/**
	 * @param int $order_id
	 *
	 * @throws \Exception
	 *
	 * @return string
	 */
	public static function getTransactionReferenceByOrderId(int $order_id): string {
		return Helper::generateString(12) . '_' . $order_id;
	}

	/**
	 * @return Order
	 */
	public static function orderForGatewayCredentialsTest(): Order {
		$order = new Order();
		$order->amount = 1;
		$order->currency = 'GBP';

		return $order;
	}

	/**
	 * @return void
	 */
	protected static function configureProxy(): void {
		if (defined('PROXY_HOST') && defined('PROXY_PORT')) {
			$proxy_config_provider = ProxyConfigProvider::instance();
			$proxy_config_provider->host = PROXY_HOST;
			$proxy_config_provider->port = PROXY_PORT;
			if (defined('PROXY_USERNAME') && defined('PROXY_PASSWORD')) {
				$proxy_config_provider->proxyUsername = PROXY_USERNAME;
				$proxy_config_provider->proxyPassword = PROXY_PASSWORD;
			}
		}
	}

	/**
	 * @return string
	 */
	public function getApiEnvironment(): string {
		return $this->config->get('payment_access_worldpay_hpp_app_mode') === "live"
			? Environment::LIVE_MODE
			: Environment::TRY_MODE;
	}

	/**
	 * @return string
	 */
	public function getApiUserName(): string {
		return $this->config->get('payment_access_worldpay_hpp_app_mode') === "live"
			? $this->config->get('payment_access_worldpay_hpp_app_live_username')
			: $this->config->get('payment_access_worldpay_hpp_app_try_username');
	}

	/**
	 * @return string
	 */
	public function getApiPassword(): string {
		return $this->config->get('payment_access_worldpay_hpp_app_mode') === "live"
			? $this->config->get('payment_access_worldpay_hpp_app_live_password')
			: $this->config->get('payment_access_worldpay_hpp_app_try_password');
	}

	/**
	 * @return string
	 */
	public function getMerchantEntity(): string {
		return $this->config->get('payment_access_worldpay_hpp_app_merchant_entity');
	}

	/**
	 * @return string
	 */
	public function getMerchantNarrative(): string {
		return $this->config->get('payment_access_worldpay_hpp_app_merchant_narrative');
	}
}
