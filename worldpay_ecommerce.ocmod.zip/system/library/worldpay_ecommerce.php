<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library;

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';

use Worldpay\Api\Entities\Order;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\ValueObjects\ResultURLs;

class WorldpayEcommerce {
	/**
	 * @var array
	 */
	protected $order_data = [];
	protected $worldpay_service;

	/**
	 * @param WorldpayService $worldpay_service
	 * @param array           $order
	 */
	public function __construct(WorldpayService $worldpay_service, array $order = []) {
		$this->worldpay_service = $worldpay_service;
		$this->order_data = $order;
	}

	/**
	 * @param string $transaction_reference
	 * @param string $success_return_url
	 * @param string $failure_return_url
	 * @param string $cancel_return_url
	 *
	 * @throws \Worldpay\Api\Exceptions\AuthenticationException
	 * @throws \Worldpay\Api\Exceptions\InvalidArgumentException
	 *
	 * @return string|null
	 */
	public function retrieveHppUrl(string $transaction_reference, string $success_return_url, string $failure_return_url = '', string $cancel_return_url = ''): ?string {
		$order = $this->worldpay_service->getOrderData($this->order_data);
		$result_URLs = null;
		if (!empty($success_return_url) && !empty($failure_return_url) && !empty($cancel_return_url)) {
			$result_URLs = $this->worldpay_service->getResultUrls($success_return_url, $failure_return_url, $cancel_return_url);
		}

		return $this->requestHppUrl($transaction_reference, $order, $result_URLs);
	}

	/**
	 * @param string          $transaction_reference
	 * @param Order           $order
	 * @param ResultURLs|null $result_URLs
	 *
	 * @throws \Worldpay\Api\Exceptions\AuthenticationException
	 *
	 * @return string|null
	 */
	public function requestHppUrl(string $transaction_reference, Order $order, ?ResultURLs $result_URLs = null): ?string {
		$api = $this->worldpay_service->initializeApi();

		$api_request = $api->HPPSetup($order->amount)
			->withTransactionReference($transaction_reference)
			->withOptionalOrder($order);
		if (!empty($result_URLs)) {
			$api_request = $api_request->withResultURLs($result_URLs);
		}

		$api_response = $api_request->execute();

		$data_to_log = [
			"api_request"      => $api_response->rawRequest,
			"api_response"     => $api_response->rawResponse,
			"wp-correlationid" => $this->getWpCorrelationId($api_response->headers),
		];
		Logger::setDescription("Retrieve Hpp url - HPP API Response")->debug($data_to_log);

		if ($api_response->statusCode !== 200) {
			throw new \Exception($api_response->rawResponse);
		}

		$decoded_api_response = json_decode($api_response->rawResponse);
		if ($decoded_api_response === null && json_last_error() !== JSON_ERROR_NONE) {
			throw new \Exception('Malformed JSON response received.');
		}

		return $decoded_api_response->url ?? '';
	}

	/**
	 * @param       $order_id
	 * @param mixed $refund_amount
	 * @param mixed $refund_currency
	 * @param       $transaction_reference
	 * @param mixed $partial_refund_reference
	 * @param       $transaction_amount
	 *
	 * @throws \Worldpay\Api\Exceptions\ApiException
	 * @throws \Worldpay\Api\Exceptions\AuthenticationException
	 * @throws \Worldpay\Api\Exceptions\InvalidArgumentException
	 *
	 * @return true
	 */
	public function refund($order_id, $refund_amount, $refund_currency, $transaction_reference, $partial_refund_reference) {
		$api = $this->worldpay_service->initializeApi();

		$converted_amount = AmountHelper::decimalToExponentDelimiter($refund_amount);

		$api_response = $api->refund($converted_amount)
			->withCurrency($refund_currency)
			->withTransactionReference($transaction_reference)
			->withPartialRefundReference($partial_refund_reference)
			->execute();

		$data_to_log = [
			"partial_refund_reference" => $partial_refund_reference,
			"order_id"                 => $order_id,
			"transaction_amount"       => $refund_amount,
			"transaction_reference"    => $transaction_reference,
			"api_request"              => $api_response->rawRequest,
			"api_response"             => $api_response->rawResponse,
			"wp-correlationid"         => $this->getWpCorrelationId($api_response->headers),
		];

		if ($api_response->statusCode !== 202) {
			Logger::setDescription("Refund failed")->alert($data_to_log);

			throw new \Exception('Something went wrong while requesting payment refund.');
		} else {
			Logger::setDescription("Refund success")->debug($data_to_log);
		}

		return true;
	}

	/**
	 * @param array $headers
	 *
	 * @return string
	 */
	protected function getWpCorrelationId(array $headers = []): string {
		$output = "";

		if (isset($headers["wp-correlationid"])) {
			$output =  $headers["wp-correlationid"];
		}

		if (isset($headers["WP-CorrelationId"])) {
			$output =  $headers["WP-CorrelationId"];
		}

		if (is_array($output)) {
			$output = array_pop($output);
		}

		return $output;
	}
}
