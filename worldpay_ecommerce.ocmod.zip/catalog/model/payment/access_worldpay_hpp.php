<?php

namespace Opencart\Catalog\Model\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;

class AccessWorldpayHpp extends \Opencart\System\Engine\Model {
	/**
	 * getMethods
	 *
	 * @param mixed $address
	 *
	 * @return array
	 */
	public function getMethods(array $address = []): array {
		$this->load->language('extension/worldpay_ecommerce/payment/access_worldpay_hpp');

		$totals = [];
		$taxes = $this->cart->getTaxes();
		$total = 0;

		$this->load->model('checkout/cart');
		($this->model_checkout_cart->getTotals)($totals, $taxes, $total);
		$total_data = [
			'totals' => $totals,
			'taxes'  => $taxes,
			'total'  => $total
		];

		$status = true;
		if ($this->session->data['currency'] != 'GBP') {
			$status = false;
		} elseif ($total_data['total'] < 0) {
			$status = false;
		} elseif ($this->cart->hasSubscription()) {
			$status = false;
		}

		$method_data = [];

		if ($status) {
			$option_data['access_worldpay_hpp'] = [
				'code' => 'access_worldpay_hpp.access_worldpay_hpp',
				'name' => $this->language->get('heading_title')
			];

			$method_data = [
				'code'       => 'access_worldpay_hpp',
				'name'       => $this->language->get('heading_title'),
				'option'     => $option_data,
				'sort_order' => $this->config->get('payment_access_worldpay_hpp_sort_order')
			];
		}

		return $method_data;
	}

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 *
	 * @return bool
	 */
	public function saveTransactionInitialDetails(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url): bool {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `order_id` = '" . (int)$order_data["order_id"] . "', `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW();");

		return true;
	}

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 *
	 * @return bool
	 */
	public function updateTransactionInitialDetailsByOcOrderId(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url): bool {
		$query = $this->db->query("UPDATE `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW() WHERE `order_id` = " . (int)$order_data["order_id"] . ";");

		return true;
	}

	/**
	 * @param string $guid
	 *
	 * @return array
	 */
	public function getTransactionDetailsByGuid(string $guid): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "access_worldpay_hpp_transactions` WHERE (`success_guid` = '" . $this->db->escape($guid) . "' OR `failure_guid` = '" . $this->db->escape($guid) . "') AND `finalized` = false AND `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "' ORDER BY `id` DESC LIMIT 1;");

		return $query->row;
	}

	/**
	 * @param int    $id
	 * @param string $status
	 *
	 * @return bool
	 */
	public function changeTransactionStatus(int $id, string $status): bool {
		if (!in_array($status, [WorldpayService::TRANSACTION_STATUS_SUCCESS, WorldpayService::TRANSACTION_STATUS_FAILED])) {
			return false;
		}
		$finalized = (int)($status === WorldpayService::TRANSACTION_STATUS_SUCCESS ? true : false);

		$query = $this->db->query("UPDATE `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `finalized` = " . $finalized . ", `order_status` = '" . $status . "' WHERE `id` = " . $id . ";");

		return true;
	}
}
