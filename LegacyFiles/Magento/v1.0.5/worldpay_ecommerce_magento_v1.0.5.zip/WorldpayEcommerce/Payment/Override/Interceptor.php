<?php
declare(strict_types=1);

namespace WorldpayEcommerce\Payment\Override;

use Magento\Framework\Code\Generator\Io;
use WorldpayEcommerce\Payment\Helper\VersionHelper;
use Magento\Framework\Code\Generator\DefinedClasses;
use Magento\Framework\Code\Generator\CodeGeneratorInterface;
use Magento\Framework\Interception\Code\Generator\Interceptor as BaseInterceptor;

class Interceptor extends BaseInterceptor
{
    /**
     * @var VersionHelper
     */
    private $versionHelper;

    public function __construct(
        VersionHelper $versionHelper,
        $sourceClassName = null,
        $resultClassName = null,
        Io $ioObject = null,
        CodeGeneratorInterface $classGenerator = null,
        DefinedClasses $definedClasses = null
    ) {
        $this->versionHelper = $versionHelper;
        parent::__construct($sourceClassName, $resultClassName, $ioObject, $classGenerator, $definedClasses);
    }

    /**
     * Returns return type with handling for older versions (below 2.4.6)
     *
     * @param \ReflectionMethod $method
     * @return null|string
     */
    protected function getReturnTypeValue(\ReflectionMethod $method): ?string
    {
        if (!$this->versionHelper->isMagentoVersionBelow246()) {
            // For Magento 2.4.6 and above, use the original behavior
            return $this->getStandardReturnTypeValue($method);
        }

        // Handle union types for Magento 2.4.5 without calling the deprecated getName() method
        $returnType = $method->getReturnType();

        if ($returnType instanceof \ReflectionUnionType) {
            $types = $returnType->getTypes();
            $typeNames = array_map(fn($type) => $type->getName(), $types);
            return implode('|', $typeNames);
        }

        return $this->getStandardReturnTypeValue($method);
    }

    /**
     * Standard return type logic for versions above 2.4.6.
     *
     * @param \ReflectionMethod $method
     * @return null|string
     */
    private function getStandardReturnTypeValue(\ReflectionMethod $method): ?string
    {
        $returnTypeValue = null;
        $returnType = $method->getReturnType();
        if ($returnType) {
            $returnTypeValue = ($returnType->allowsNull() ? '?' : '');
            $returnTypeValue .= ($returnType->getName() === 'self')
                ? $this->_getFullyQualifiedClassName($method->getDeclaringClass()->getName())
                : $returnType->getName();
        }

        return $returnTypeValue;
    }
}
