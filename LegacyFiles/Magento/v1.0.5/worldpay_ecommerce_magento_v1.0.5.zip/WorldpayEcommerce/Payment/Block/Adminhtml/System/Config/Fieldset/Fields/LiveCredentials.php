<?php

namespace WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Fieldset\Fields;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;
use WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons\LiveApiButton;

/**
 * Class LiveCredentials
 *
 * This class provides the live credentials configuration fieldset in the Magento admin panel.
 */
class LiveCredentials extends Field
{
    /**
     * @var LiveApiButton
     */
    protected LiveApiButton $buttonRenderer;

    /**
     * @var ConfigButtonHelper
     */
    protected ConfigButtonHelper $configButtonHelper;

    /**
     * LiveCredentials constructor.
     *
     * @param Context $context
     * @param LiveApiButton $buttonRenderer
     * @param ConfigButtonHelper $configButtonHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        LiveApiButton $buttonRenderer,
        ConfigButtonHelper $configButtonHelper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->buttonRenderer = $buttonRenderer;
        $this->configButtonHelper = $configButtonHelper;
    }

    /**
     * Appends the button HTML to the element HTML.
     *
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        $html = parent::_getElementHtml($element);
        $prefix = $this->configButtonHelper->getPrefixFromElementId($element->getId());
        $passwordFieldId = $prefix . '_api_live_password';

        if ($element->getId() === $passwordFieldId) {
            $html .= $this->buttonRenderer->getButtonHtml($element);
        }

        $html .= $this->getJavascript($element, $prefix);

        return $html;
    }

    /**
     * Generates JavaScript for the element to add required-entry validation based on app mode.
     *
     * @param AbstractElement $element The form element.
     * @param string $prefix The prefix for the element ID.
     * @return string The JavaScript code.
     */
    private function getJavascript(AbstractElement $element, string $prefix): string
    {
        $appModeElement = $element->getForm()->getElement($prefix . '_app_mode');
        $usernameElement = $element->getForm()->getElement($prefix . '_api_live_username');

        $appModeFieldId = $appModeElement ? $appModeElement->getHtmlId() : '';
        $usernameFieldId = $usernameElement ? $usernameElement->getHtmlId() : '';
        $passwordFieldId = $element->getHtmlId();

        if (!$appModeFieldId || !$usernameFieldId) {
            return '';
        }

        return "<script type='text/javascript'>
            require(['jquery'], function ($) {
                let appModeField = $('#" . $appModeFieldId . "');
                let usernameField = $('#" . $usernameFieldId . "');
                let passwordField = $('#" . $passwordFieldId . "');
                appModeField.change(function() {
                    if ($(this).val() === 'live') {
                        usernameField.addClass('required-entry');
                        passwordField.addClass('required-entry');
                    } else {
                        usernameField.removeClass('required-entry');
                        passwordField.removeClass('required-entry');
                    }
                }).change();
            });
        </script>";
    }

    public function getElementHtmlForTest(AbstractElement $element): string
    {
        return $this->_getElementHtml($element);
    }

    public function getJavascriptForTest(AbstractElement $element, string $prefix): string
    {
        return $this->getJavascript($element, $prefix);
    }
}
