<?php

namespace WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons;

use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;
use Magento\Backend\Block\Template\Context;

/**
 * Class BaseApiButton
 *
 * This class serves as a base for API buttons in the Magento admin panel.
 */
abstract class BaseApiButton extends Field
{
    /**
     * @var ConfigButtonHelper
     */
    protected ConfigButtonHelper $configButtonHelper;

    /**
     * BaseApiButton constructor.
     *
     * @param Context $context
     * @param ConfigButtonHelper $configButtonHelper
     * @param array $data
     */
    public function __construct(Context $context, ConfigButtonHelper $configButtonHelper, array $data = [])
    {
        parent::__construct($context, $data);
        $this->configButtonHelper = $configButtonHelper;
    }

    /**
     * Appends the button HTML to the element HTML.
     *
     * @param AbstractElement $element
     * @return string
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        return $this->configButtonHelper->appendButtonHtml($element, [$this, 'getButtonHtml']);
    }

    /**
     * Abstract method to generate the button HTML, to be implemented by subclasses.
     *
     * @param AbstractElement $element
     * @return string
     */
    abstract public function getButtonHtml(AbstractElement $element): string;
}
