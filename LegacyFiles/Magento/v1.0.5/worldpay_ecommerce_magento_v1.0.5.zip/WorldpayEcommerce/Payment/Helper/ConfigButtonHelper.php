<?php

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Framework\Data\Form\Element\AbstractElement;

/**
 * Class ConfigButtonHelper
 *
 * This class provides helper methods to generate button HTML
 * and JavaScript for configuration buttons in the Magento admin panel.
 */
class ConfigButtonHelper
{
    /**
     * Extracts the prefix from an element's ID.
     * Handles cases with or without "payment", optional country codes (2 or 3 letters), and "worldpay_ecommerce" prefixes.
     *
     * @param string $elementId The HTML ID of the form element.
     * @return string The prefix extracted from the element ID.
     */
    public function getPrefixFromElementId(string $elementId): string
    {
        // Normalize the element ID: lowercase and replace unexpected characters
        $normalizedId = strtolower(str_replace('-', '_', $elementId)); // Replace hyphens with underscores

        // Patterns for matching
        $patterns = [
            '/^payment_([a-z]{2,3}|other)_worldpay_ecommerce/i' => 4, // payment_<country_code|other>_worldpay_ecommerce
            '/^payment_worldpay_ecommerce/i' => 3, // payment_worldpay_ecommerce
            '/^([a-z]{2,3}|other)_worldpay_ecommerce/i' => 3, // <country_code|other>_worldpay_ecommerce
            '/^worldpay_ecommerce/i' => 2, // worldpay_ecommerce
            '/^payment_[a-z0-9_]+_worldpay_ecommerce/i' => null, // Custom "payment_<customcode>_worldpay_ecommerce"
        ];

        $parts = explode('_', $normalizedId);

        foreach ($patterns as $pattern => $length) {
            if (preg_match($pattern, $normalizedId)) {
                return $this->getPrefix($parts, $length);
            }
        }

        // Default case: Use the first 4 parts or fewer if not available
        return $this->getPrefix($parts, 4);
    }

    /**
     * Generates HTML for a button with accompanying JavaScript to handle the button's click event.
     *
     * @param  AbstractElement $element     The element from which to derive IDs.
     * @param  string          $buttonText The text to display on the button.
     * @param  string          $url        The URL to target with the AJAX request.
     * @param  array           $fieldIds   Additional fields to include in the AJAX data.
     * @param  string          $mode
     * @return string The complete HTML for the button with script.
     * @return string The complete HTML for the button with script.
     */
    public function generateButtonHtml(
        AbstractElement $element,
        string $buttonText,
        string $url,
        array $fieldIds,
        string $mode
    ): string {
        // Get the prefix from the element ID
        $prefix = $this->getPrefixFromElementId($element->getId());

        // Generate the button HTML
        $buttonHtml = '<button id="' . $element->getHtmlId() . '_button" type="button" style="margin-top: 5px;">';
        $buttonHtml .= __($buttonText);
        $buttonHtml .= '</button>';

        // Prepare button selector and field mappings for the JavaScript
        $buttonSelector = '#' . $element->getHtmlId() . '_button';
        $fields = [];
        foreach ($fieldIds as $key => $id) {
            $fields[] = ['key' => $key, 'selector' => '#' . $prefix . '_' . $id];
        }

        // Generate the JavaScript for handling the button click
        $script = "<script type='text/javascript'>
                        require(['jquery', 'WorldpayEcommerce_Payment/js/worldpay-test-credentials-button'],
                        function ($, configButton) {
                            configButton({
                                buttonSelector: '$buttonSelector',
                                url: '$url',
                                fieldIds: " . json_encode($fields) . ",
                                appMode: '$mode'
                            });
                        });
                    </script>";

        // Return the combined button HTML and script
        return $buttonHtml . $script;
    }

    /**
     * Generates the complete HTML for an element, including the button HTML.
     *
     * @param AbstractElement $element The form element.
     * @param callable $getButtonHtml A callable that generates the button HTML.
     * @return string The complete HTML for the element with the button.
     */
    public function appendButtonHtml(AbstractElement $element, callable $getButtonHtml): string
    {
        // Append the custom button HTML to the existing element HTML
        return $element->getElementHtml() . '<br>' . $getButtonHtml($element);
    }

    /**
     * Builds the prefix string from the provided parts up to the specified length.
     * If the specified length exceeds the available parts, it uses the maximum available.
     *
     * @param array $parts The exploded parts of the element ID.
     * @param int|null $length The number of parts to include in the prefix. Defaults to null for all parts.
     * @return string The constructed prefix.
     */
    private function getPrefix(array $parts, ?int $length = null): string
    {
        return implode('_', array_slice($parts, 0, $length ?? count($parts)));
    }
}
