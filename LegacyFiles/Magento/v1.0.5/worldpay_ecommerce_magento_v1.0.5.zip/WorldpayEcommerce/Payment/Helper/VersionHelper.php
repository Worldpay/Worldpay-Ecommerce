<?php
declare(strict_types=1);

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Framework\App\ProductMetadataInterface;

class VersionHelper
{
    /**
     * @var ProductMetadataInterface
     */
    private $productMetadata;

    /**
     * VersionHelper constructor.
     * @param ProductMetadataInterface $productMetadata
     */
    public function __construct(ProductMetadataInterface $productMetadata)
    {
        $this->productMetadata = $productMetadata;
    }

    /**
     * Check if current Magento version is below 2.4.6.
     *
     * @return bool
     */
    public function isMagentoVersionBelow246(): bool
    {
        $version = $this->productMetadata->getVersion();

        return version_compare($version, '2.4.6', '<');
    }
}
