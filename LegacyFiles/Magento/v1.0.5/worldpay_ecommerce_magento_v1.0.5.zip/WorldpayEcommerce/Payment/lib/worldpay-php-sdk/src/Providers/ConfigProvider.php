<?php

namespace Worldpay\Api\Providers;

use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Enums\Api;

abstract class ConfigProvider
{
    /**
     * @var null
     */
    private static $instances = [];

    /**
     * @var string
     */
    protected string $api = Api::ACCESS_WORLDPAY_API;

    /**
     * @var Environment
     */
    public string $environment;

    /**
     * @return mixed|static
     */
    public static function instance() {
        $class = static::class;
        if (!isset(self::$instances[$class])) {
            self::$instances[$class] = new static();
        }

        return self::$instances[$class];
    }

    /**
     * @return string
     */
    public function getApi() {
        return $this->api;
    }
}
