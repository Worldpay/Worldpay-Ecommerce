<?php

namespace Worldpay\Api\Exceptions;

/**
 * Exception thrown when Access Worldpay APIs respond with status codes in the 5xx range.
 */
class ApiClientException extends \Exception
{

}
