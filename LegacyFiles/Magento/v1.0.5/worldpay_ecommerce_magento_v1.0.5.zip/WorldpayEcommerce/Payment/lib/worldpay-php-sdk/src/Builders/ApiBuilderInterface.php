<?php

namespace Worldpay\Api\Builders;

interface ApiBuilderInterface
{
    /**
     * Create API request payload.
     *
     * @return mixed
     */
    public function createPayload();
}
