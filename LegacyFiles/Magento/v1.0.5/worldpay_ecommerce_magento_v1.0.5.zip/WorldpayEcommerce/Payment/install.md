## Worldpay eCommerce for Magento Community Edition installation guide

### Prerequisites:
- Magento 2.4.6 or later version
- PHP 8.1 or later version
- FTP/SFTP access to the merchant’s website server
- SSH access to the merchant’s website server

### Step 1

Download the archive ‘WorldpayEcommerce’ from https://github.com/Worldpay/Worldpay-Ecommerce/tree/main and unzip it in the folder you have downloaded it.
Make sure that the resulting folder from the archive is named ‘WorldpayEcommerce’ and that it contains the ‘Payment’ folder.

### Step 2

Access the merchant server via FTP/SFTP and go to where Magento is installed (project root).
Once you get there, go to app/code/ and upload the ‘WorldpayEcommerce’ folder so that the folder’s path should be [Magento_installation_root]/app/code/WorldpayEcommerce.

### Step 3

Access the merchant server via SSH and go to where Magento is installed (project root).
Make sure you have the right permissions to run the following commands:

--- php bin/magento module:enable WorldpayEcommerce_Payment
--- php bin/magento setup:upgrade
--- php bin/magento setup:di:compile
--- php bin/magento setup:static-content:deploy

These are all the steps required to install WorldpayEcommerce_Payment module on Magento. If you encounter any issues, please contact our support teams.
