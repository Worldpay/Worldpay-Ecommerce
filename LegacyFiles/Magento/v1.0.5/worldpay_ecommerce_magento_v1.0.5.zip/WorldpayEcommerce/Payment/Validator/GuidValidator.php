<?php

namespace WorldpayEcommerce\Payment\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Magento\Payment\Gateway\Validator\ResultInterfaceFactory;
use Worldpay\Api\Utils\Helper as WorldpaySdkHelper;

class GuidValidator extends AbstractValidator
{
    /**
     * @var ResultInterfaceFactory
     */
    protected ResultInterfaceFactory $resultFactory;

    /**
     * @param  ResultInterfaceFactory  $resultFactory
     */
    public function __construct(ResultInterfaceFactory $resultFactory)
    {
        $this->resultFactory = $resultFactory;
    }

    /**
     * Validate subject.
     *
     * @param  array  $validationSubject
     *
     * @return ResultInterface
     */
    public function validate(array $validationSubject): ResultInterface
    {
        $isValid       = true;
        $errorMessages = [];

        if (!WorldpaySdkHelper::isValidGuid($validationSubject['guid'])) {
            $isValid         = false;
            $errorMessages[] = __('Invalid guid for payment result.');
        }

        return $this->resultFactory->create(['isValid' => $isValid, 'failsDescription' => $errorMessages]);
    }
}
