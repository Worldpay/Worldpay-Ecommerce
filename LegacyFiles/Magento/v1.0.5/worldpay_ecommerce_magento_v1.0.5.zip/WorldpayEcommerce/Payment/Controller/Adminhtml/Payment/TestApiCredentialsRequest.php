<?php

namespace WorldpayEcommerce\Payment\Controller\Adminhtml\Payment;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\ScopeInterface;
use Worldpay\Api\Enums\Environment;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Gateway\Config\Config as WorldpayConfig;

/**
 * Class TestApiCredentialsRequest
 *
 * This class handles the API credentials test request in the Magento admin panel.
 * It extends the Magento Action class and uses WorldpayService to perform the API setup and validation.
 */
class TestApiCredentialsRequest extends Action
{
    /**
     * @var JsonFactory
     */
    protected JsonFactory $resultJsonFactory;

    /**
     * @var WorldpayEcommerce
     */
    protected WorldpayEcommerce $worldpayEcommerce;

    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param WorldpayEcommerce $worldpayEcommerce
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     * @param DirectoryList $dir
     * @throws FileSystemException
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        WorldpayEcommerce $worldpayEcommerce,
        Config $config,
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->worldpayEcommerce = $worldpayEcommerce;
        $this->config = $config;
        $this->scopeConfig = $scopeConfig;
        Logger::config($scopeConfig, $dir);
    }

    /**
     * Execute the API credentials test.
     *
     * @return Json
     */
    public function execute(): Json
    {
        Logger::logPlatformVersion();

        $result = $this->resultJsonFactory->create();
        $postData = $this->getRequest()->getPostValue();

        try {
            $credentials = $this->getCredentials($postData);
            $this->validateCredentials($credentials);

            $apiConfigProvider = AccessWorldpayConfigProvider::instance();
            $apiConfigProvider->environment =
                $credentials['appMode'] === 'live' ?  Environment::LIVE_MODE : Environment::TRY_MODE;
            $apiConfigProvider->username = $credentials['apiUsername'];
            $apiConfigProvider->password = $credentials['apiPassword'];
            $apiConfigProvider->merchantEntity = $credentials['merchantEntity'];
            $apiConfigProvider->merchantNarrative = 'Test API Credentials';

            $apiResponse = $this->worldpayEcommerce->testApiCredentials($apiConfigProvider, $credentials['appMode']);

            $dataToLog = [
                "request_app_mode" => $credentials['appMode'],
                "correlationId" => WorldpayService::getWpCorrelationIdFromHeaders($apiResponse->headers),
                "api request" => $apiResponse->rawRequest,
                "api response" => $apiResponse->rawResponse,
                "api status code" => $apiResponse->statusCode,
                "api is successful" => (int)$apiResponse->isSuccessful(),
                "api has server error" => (int)$apiResponse->hasServerError(),
                "api has client error" => $apiResponse->hasClientError(),
                "api curl error" => $apiResponse->curlError,
            ];
            Logger::setDescription("Test Api Credentials Request")->debug($dataToLog);

            if ($apiResponse->isSuccessful()) {
                return $result->setData(
                    [
                        'success' => true,
                        'message' => __('Worldpay Payments connected successfully
                        to the payment gateway with your provided credentials.')
                    ]
                );
            }

            if ($apiResponse->hasServerError()) {
                Logger::setDescription("Test Api Credentials Request - failed")->alert($dataToLog);
                throw new Exception(__('Worldpay Payments could not connect
                        to Access Worldpay API. Please try again later.'));
            }

            return $result->setData(
                [
                    'success' => false,
                    'message' => __('Worldpay Payments could not connect
                    to the payment gateway with your provided credentials.')
                ]
            );
        } catch (Exception $e) {
            return $result->setData(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * Retrieve the API credentials from the post data.
     *
     * @param array $postData
     *
     * @return array
     * @throws NoSuchEntityException
     */
    private function getCredentials(array $postData): array
    {
        $type = $this->getRequest()->getParam('type');
        $appMode = $postData['app_mode'] ?? 'try';
        $configPathPrefix = 'payment/' . WorldpayConfig::CODE . '/';

        $apiUsername = $postData[$type === 'live' ? 'api_live_username' : 'api_try_username'] ?? '';
        $apiPassword = $postData[$type === 'live' ? 'api_live_password' : 'api_try_password'] ?? '';
        $merchantEntity = $postData['merchant_entity'] ?? '';

        if (preg_match('/^\*{6}$/', $apiPassword)) {
            $apiPassword = $this->scopeConfig->getValue(
                $configPathPrefix . ($type === 'live' ? 'api_live_password' : 'api_try_password'),
                ScopeInterface::SCOPE_STORE,
                WorldpayService::getStoreId()
            );
        }

        if (preg_match('/^\*+[^*]{4}$/', $merchantEntity)) {
            $merchantEntity = $this->scopeConfig->getValue(
                $configPathPrefix . 'merchant_entity',
                ScopeInterface::SCOPE_STORE,
                WorldpayService::getStoreId()
            );
        }

        return compact('appMode', 'apiUsername', 'apiPassword', 'merchantEntity');
    }

    /**
     * Validate the provided API credentials.
     *
     * @param array $credentials
     * @throws Exception
     */
    private function validateCredentials(array $credentials): void
    {
        $missingFields = [];
        $requiredFields = [
            'apiUsername' => __('Username'),
            'apiPassword' => __('Password'),
            'merchantEntity' => __('Merchant Entity')
        ];

        foreach ($requiredFields as $key => $label) {
            if (empty($credentials[$key])) {
                $missingFields[] = $label;
            }
        }

        if (!empty($missingFields)) {
            throw new Exception(__('Missing required fields: %1', implode(', ', $missingFields)));
        }
    }
}
