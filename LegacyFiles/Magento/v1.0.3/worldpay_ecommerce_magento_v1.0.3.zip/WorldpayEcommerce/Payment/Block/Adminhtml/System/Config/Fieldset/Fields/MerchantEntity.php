<?php

namespace WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Fieldset\Fields;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Exception\NoSuchEntityException;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

/**
 * Class MerchantEntity
 *
 * This class provides a masked display for the merchant entity configuration field in the Magento admin panel.
 */
class MerchantEntity extends Field
{
    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * MerchantEntity constructor.
     *
     * @param Context $context
     * @param WorldpayService $worldpayService
     * @param array $data
     */
    public function __construct(
        Context $context,
        WorldpayService $worldpayService,
        array $data = []
    ) {
        $this->worldpayService = $worldpayService;
        parent::__construct($context, $data);
    }

    /**
     * Add extra HTML attributes and mask the value if present.
     *
     * @param AbstractElement $element
     *
     * @return string
     * @throws NoSuchEntityException
     */
    protected function _getElementHtml(AbstractElement $element): string
    {
        // Check if there is a value from the element (from the database)
        $savedValue = $element->getData('value');

        // If there is no saved value, retrieve the original value from WorldpayService
        if (!$savedValue) {
            $savedValue = $this->worldpayService->getMerchantEntity();
        }

        // Set the value and a placeholder
        $element->setValue($savedValue);
        $element->setData('placeholder', __('POxxxxxxxxx'));

        return parent::_getElementHtml($element);
    }
}
