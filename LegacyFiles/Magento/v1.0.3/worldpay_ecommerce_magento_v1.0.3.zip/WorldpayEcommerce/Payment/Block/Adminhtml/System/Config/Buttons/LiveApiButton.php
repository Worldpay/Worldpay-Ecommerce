<?php

namespace WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons;

use Magento\Backend\Block\Template\Context;
use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;

/**
 * Class LiveApiButton
 *
 * This class provides the button for testing live API credentials in the Magento admin panel.
 */
class LiveApiButton extends BaseApiButton
{
    /**
     * LiveApiButton constructor.
     *
     * @param Context $context
     * @param ConfigButtonHelper $configButtonHelper
     * @param array $data
     */
    public function __construct(Context $context, ConfigButtonHelper $configButtonHelper, array $data = [])
    {
        parent::__construct($context, $configButtonHelper, $data);
    }

    /**
     * Generates the HTML for the button.
     *
     * @param AbstractElement $element
     * @return string
     */
    public function getButtonHtml(AbstractElement $element): string
    {
        $url = $this->getUrl('worldpay_ecommerce/payment/testApiCredentialsRequest', ['type' => 'live']);
        $fieldIds = [
            'api_live_username' => 'api_live_username',
            'api_live_password' => 'api_live_password',
            'merchant_entity' => 'merchant_entity'
        ];

        return $this->configButtonHelper->generateButtonHtml(
            $element,
            __('Validate Live Credentials'),
            $url,
            $fieldIds,
            'live'
        );
    }
}
