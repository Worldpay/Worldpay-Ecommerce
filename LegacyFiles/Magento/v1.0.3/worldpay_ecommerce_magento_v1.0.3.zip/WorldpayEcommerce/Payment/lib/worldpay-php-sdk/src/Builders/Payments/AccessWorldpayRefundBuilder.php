<?php

namespace Worldpay\Api\Builders\Payments;

use Worldpay\Api\Builders\ApiBuilderInterface;
use Worldpay\Api\Exceptions\InvalidArgumentException;

class AccessWorldpayRefundBuilder implements ApiBuilderInterface
{
    /**
     * @var RefundsBuilder
     */
    private RefundsBuilder $baseBuilder;

    public function __construct(RefundsBuilder $builder) {
        $this->baseBuilder = $builder;
    }

    /**
     * @return string
     * @throws InvalidArgumentException
     */
    public function createPayload(): string {
        $payload = [];

        $payload['value']['amount'] = $this->baseBuilder->amount ?? null;
        $payload['value']['currency'] = $this->baseBuilder->currency ?? null;
        if(empty($this->baseBuilder->partialRefundReference)) {
            throw new InvalidArgumentException('Invalid partial refund reference. Must supply a non empty-string. Maximum of 128 characters.');
        }
        $payload['reference'] = $this->baseBuilder->partialRefundReference;

        return json_encode($payload);
    }
}
