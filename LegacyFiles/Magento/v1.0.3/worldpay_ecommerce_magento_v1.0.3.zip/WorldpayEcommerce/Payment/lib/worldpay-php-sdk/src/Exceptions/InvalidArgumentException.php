<?php

namespace Worldpay\Api\Exceptions;

/**
 * Exception thrown if an argument is not of the expected type or length.
 */
class InvalidArgumentException extends \Exception
{

}
