<?php

namespace WorldpayEcommerce\Payment\Plugin\Config;

use Magento\Config\Model\Config;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Gateway\Config\Config as WorldpayConfig;

class MerchantEntity
{
    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * Constructor.
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Check if merchant entity is not changed to strip off masking.
     *
     * @param Config $subject
     * @return void
     * @throws NoSuchEntityException
     */
    public function beforeSave(Config $subject): void
    {
        $groups = $subject->getGroups();

        if (
            !isset($groups['worldpay_ecommerce']['fields']['merchant_entity']['value']) ||
            !preg_match('/^\*+[^*]{4}$/', $groups['worldpay_ecommerce']['fields']['merchant_entity']['value'])
        ) {
            return;
        }

        $configPath = 'payment/' . WorldpayConfig::CODE . '/merchant_entity';

        $merchantEntityOldValue = $this->scopeConfig->getValue(
            $configPath,
            ScopeInterface::SCOPE_STORE,
            WorldpayService::getStoreId()
        );

        if (empty($merchantEntityOldValue)) {
            return;
        }

        $subject->setDataByPath($configPath, $merchantEntityOldValue);
    }
}
