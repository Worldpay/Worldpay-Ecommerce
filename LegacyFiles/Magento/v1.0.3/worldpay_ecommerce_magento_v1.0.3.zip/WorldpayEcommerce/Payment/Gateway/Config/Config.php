<?php

namespace WorldpayEcommerce\Payment\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Payment\Gateway\Config\Config as MagentoPaymentConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use Magento\Framework\Filesystem\DirectoryList;

class Config extends MagentoPaymentConfig
{
    /**
     * CODE
     */
    public const CODE = "access_worldpay_hpp";

    /**
     * Constructor.
     *
     * @param  ScopeConfigInterface  $scopeConfig
     * @param  DirectoryList         $dir
     * @param  string|null           $methodCode
     * @param  string                $pathPattern
     *
     * @throws FileSystemException
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        DirectoryList $dir,
        string|null $methodCode = null,
        string $pathPattern = MagentoPaymentConfig::DEFAULT_PATH_PATTERN
    ) {
        parent::__construct($scopeConfig, self::CODE, $pathPattern);
        Logger::config($scopeConfig, $dir);
    }
}
