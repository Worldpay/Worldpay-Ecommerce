<?php

namespace WorldpayEcommerce\Payment\Gateway\Request;

use Magento\Payment\Gateway\Request\BuilderInterface;
use Magento\Payment\Helper\Formatter;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Payment\Gateway\Helper\SubjectReader;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class PaymentDataBuilder implements BuilderInterface
{
    use Formatter;

    /**
     * @var Config
     */
    private Config $config;

    /**
     * @var SubjectReader $subjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * Constructor.
     *
     * @param Config $config
     * @param SubjectReader $subjectReader
     */
    public function __construct(Config $config, SubjectReader $subjectReader)
    {
        $this->config = $config;
        $this->subjectReader = $subjectReader;
    }

    /**
     * Build request.
     *
     * @param array $buildSubject
     * @return array
     */
    public function build(array $buildSubject): array
    {
        $paymentDO = $this->subjectReader->readPayment($buildSubject);

        $order = $paymentDO->getOrder();

        $result = [
            'amount' => $order->getGrandTotalAmount(),
            'currency' => $order->getCurrencyCode(),
            'orderId' => $order->getOrderIncrementId(),
            'shipping' => $this->getAddress($order, 'shipping'),
            'billing' => $this->getAddress($order, 'billing'),
            'customer' => $this->getCustomerData($order)
        ];

        Logger::setDescription("Payload for HPP Url request")->debug($result);

        return $result;
    }

    /**
     * Get address.
     *
     * @param mixed $order
     * @param string $address_type
     * @return array
     */
    protected function getAddress(mixed $order, string $address_type = '') : array
    {
        if (!in_array($address_type, ["billing", "shipping"], true)) {
            return [];
        }

        $output = [];
        $addressData = [];
        if ($address_type === "billing") {
            $addressData = $order->getBillingAddress();
        }

        if ($address_type === "shipping") {
            $addressData = $order->getShippingAddress();
        }

        if ($addressData) {
            $output = [
                'firstname' => $addressData->getFirstname(),
                'lastname'  => $addressData->getLastname(),
                'email'     => $addressData->getEmail(),
                'telephone' => $addressData->getTelephone(),
                'street'    => implode(' ', $addressData->getStreet()),
                'city'      => $addressData->getCity(),
                'country'   => $addressData->getCountryId(),
                'postcode'  => $addressData->getPostcode(),
            ];
        }

        return $output;
    }

    /**
     * Get customer data.
     *
     * @param mixed $order
     * @return array
     */
    protected function getCustomerData(mixed $order): array
    {
        $billingAddress = $order->getBillingAddress();

        return [
            'firstName'   => $billingAddress->getFirstname(),
            'lastName'    => $billingAddress->getLastname(),
            'email'       => $billingAddress->getEmail(),
            'phoneNumber' => $billingAddress->getTelephone(),
        ];
    }
}
