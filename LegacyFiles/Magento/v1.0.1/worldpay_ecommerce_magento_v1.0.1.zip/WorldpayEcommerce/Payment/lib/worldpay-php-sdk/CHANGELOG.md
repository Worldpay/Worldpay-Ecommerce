# Worldpay eCommerce PHP SDK change log
## [v1.0.5]
* Added validation for merchant narrative field

## [v1.0.4]
* Added helper validation method for GUIDs

## [v1.0.3]
* Added API response helpers.

## [v1.0.2]
* Fix generateString returned length.

## [v1.0.1]
* Added length validations for customer phone number, first name, last name, email.
* Added helper for guid generation.
* Updated config provider singleton.
* Removed whitelist of IPS.

## [v1.0.0]
* Initial release.
