<?php

namespace Worldpay\Api\Builders;

abstract class BaseBuilder
{
    /**
     * @var null
     */
    private static $instance = null;

    protected function __construct() { }

    /**
     * @return static|null
     */
    public static function instance() {
        if (!isset(self::$instance)) {
            self::$instance = new static();
        }

        return self::$instance;
    }
}
