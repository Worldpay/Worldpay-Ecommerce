<?php

namespace WorldpayEcommerce\Payment\lib\Service;

use Exception;
use Worldpay\Api\Builders\HostedPaymentPages\HostedPaymentPagesBuilder;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;

class WorldpayEcommerce
{
    /**
     * @var array
     */
    protected array $orderData = [];

    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * @var HostedPaymentPagesBuilder
     */
    protected HostedPaymentPagesBuilder $apiRequest;

    /**
     * @var ApiResponse
     */
    protected ApiResponse $apiResponse;

    /**
     * Constructor
     *
     * @param WorldpayService $worldpayService
     * @param array           $order
     */
    public function __construct(
        WorldpayService $worldpayService,
        array $order = []
    ) {
        $this->worldpayService = $worldpayService;
        $this->orderData = $order;
    }

    /**
     * Tests the API credentials by making a test request to the Worldpay API.
     *
     * @param AccessWorldpayConfigProvider $apiConfigProvider
     * @param string $type
     *
     * @return ApiResponse
     * @throws AuthenticationException
     * @throws Exception
     */
    public function testApiCredentials(
        AccessWorldpayConfigProvider $apiConfigProvider,
        string $type
    ): ApiResponse {
        $this->worldpayService->apiConfigProvider = $apiConfigProvider;
        $api = $this->worldpayService->initializeApi();

        $transactionReference = Helper::generateString(12) . '_' . $type.'_test';

        return $api->HPPSetup(1)
                   ->withCurrency('GBP')
                   ->withTransactionReference($transactionReference)
                   ->execute();
    }

    /**
     * Request for HPP url.
     *
     * @param  string  $transaction_reference
     * @param  string  $success_return_url
     * @param  string  $failure_return_url
     * @param  string  $cancel_return_url
     *
     * @return ApiResponse
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     */
    public function requestHppUrl(
        string $transaction_reference,
        string $success_return_url,
        string $failure_return_url = '',
        string $cancel_return_url = ''
    ): ApiResponse {
        $order = $this->worldpayService->getOrderData($this->orderData);
        $result_URLs = null;
        if (!empty($success_return_url) && !empty($failure_return_url) && !empty($cancel_return_url)) {
            $result_URLs = $this->worldpayService->getResultUrls(
                $success_return_url,
                $failure_return_url,
                $cancel_return_url
            );
        }

        $api = $this->worldpayService->initializeApi();

        $this->apiRequest = $api->HPPSetup($order->amount)
                           ->withTransactionReference($transaction_reference)
                           ->withOptionalOrder($order);
        if ($description = $this->worldpayService->getMerchantDescription()) {
            $this->apiRequest = $this->apiRequest->withDescription($description);
        }
        if (!empty($result_URLs)) {
            $this->apiRequest = $this->apiRequest->withResultURLs($result_URLs);
        }

        return $this->apiRequest->execute();
    }

    /**
     * Request for refund.
     *
     * @param string $transactionReference
     * @param mixed $refundAmount
     * @param string $currencyCode
     * @param string $storeLocale
     * @param string $partialRefundReference
     *
     * @return ApiResponse
     * @throws ApiException
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     */
    public function refund(
        string $transactionReference,
        mixed $refundAmount,
        string $currencyCode,
        string $storeLocale,
        string $partialRefundReference = ''
    ): ApiResponse {
        $api = $this->worldpayService->initializeApi();

        $convertedAmount = AmountHelper::decimalToExponentDelimiter($refundAmount, $currencyCode, $storeLocale);

        return $api->refund($convertedAmount)
                    ->withCurrency($currencyCode)
                    ->withTransactionReference($transactionReference)
                    ->withPartialRefundReference($partialRefundReference)
                    ->execute();
    }
}
