<?php

namespace WorldpayEcommerce\Payment\lib\Service;

use Magento\Store\Model\ScopeInterface;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\Address;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;
use Magento\Framework\App\Config\ScopeConfigInterface;

class WorldpayService
{
    /**
     * Plugin version
     */
    public const PLUGIN_VERSION = "1.0.1";

    /**
     * TRANSACTION_STATUS_SUCCESS
     */
    public const TRANSACTION_STATUS_SUCCESS = 'success';

    /**
     * TRANSACTION_STATUS_FAILED
     */
    public const TRANSACTION_STATUS_FAILED  = 'failed';

    /**
     * TRANSACTION_STATUS_PENDING
     */
    public const TRANSACTION_STATUS_PENDING = 'pending';

    /**
     * TRANSACTION_STATUS_CANCELED
     */
    public const TRANSACTION_STATUS_CANCELED = 'canceled';

    /**
     * @var null
     */
    public $apiConfigProvider = null;

    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * Constructor
     *
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->config = $config;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Initialize api.
     *
     * @return AccessWorldpay
     */
    public function initializeApi(): AccessWorldpay
    {
        $this->configureProxy();
        if ($this->apiConfigProvider instanceof AccessWorldpayConfigProvider) {
            return AccessWorldpay::config($this->apiConfigProvider);
        }

        return AccessWorldpay::config($this->configureApi());
    }

    /**
     * Configure api for requests.
     *
     * @return AccessWorldpayConfigProvider|mixed|null
     */
    public function configureApi(): mixed
    {
        $apiConfigProvider                    = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->environment       = $this->getApiEnvironment();
        $apiConfigProvider->username          = $this->getApiUsername();
        $apiConfigProvider->password          = $this->getApiPassword();
        $apiConfigProvider->merchantEntity    = $this->getMerchantEntity();
        $apiConfigProvider->merchantNarrative = $this->getMerchantNarrative();

        return $apiConfigProvider;
    }

    /**
     * Get addresses from order.
     *
     * @param array  $orderData
     * @param string $addressType
     *
     * @return Address|null
     */
    public static function getOrderAddress(
        array $orderData = [],
        string $addressType = ''
    ): ?Address {
        if (!in_array($addressType, ["billing", "shipping"]) || empty($orderData)) {
            return null;
        }

        $address = $addressType === 'billing' ? new BillingAddress() : new ShippingAddress();
        $address->address1   = $orderData[$addressType]['street'] ?? '';
        $address->postalCode = $orderData[$addressType]['postcode'] ?? '';
        $address->city       = $orderData[$addressType]['city'] ?? '';
        $address->state      = $orderData[$addressType]['country'] ?? '';

        return $address;
    }

    /**
     * Get customer from order.
     *
     * @param array $orderData
     *
     * @return Customer
     */
    public static function getOrderCustomer(array $orderData = []): Customer
    {
        $customer = new Customer();
        $customer->firstName   = $orderData['customer']['firstname'] ?? '';
        $customer->lastName    = $orderData['customer']['lastname'] ?? '';
        $customer->email       = $orderData['customer']['email'] ?? '';
        $customer->phoneNumber = $orderData['customer']['telephone'] ?? '';

        return $customer;
    }

    /**
     * Get order data.
     *
     * @param array $orderData
     *
     * @throws InvalidArgumentException
     *
     * @return Order
     */
    public function getOrderData(array $orderData = []): Order
    {
        $order = new Order();
        $order->id              = $orderData["id"] ?? "";
        $order->billingAddress  = self::getOrderAddress($orderData, 'billing');
        $order->shippingAddress = self::getOrderAddress($orderData, 'shipping');
        $order->customer        = self::getOrderCustomer($orderData);
        $order->currency        = $orderData["currency_code"] ?? "";
        $order->amount          = AmountHelper::decimalToExponentDelimiter($orderData["total"], $orderData['currency_code'], $orderData['locale']) ?? "";

        return $order;
    }

    /**
     * Get result URLs.
     *
     * @param string $success_return_url
     * @param string $failure_return_url
     * @param string $cancel_return_url
     *
     * @return ResultURLs
     */
    public function getResultUrls(
        string $success_return_url,
        string $failure_return_url,
        string $cancel_return_url
    ): ResultURLs {
        $resultUrls = new ResultURLs();
        $resultUrls->successURL = $success_return_url;
        $resultUrls->errorURL   = $failure_return_url;
        $resultUrls->failureURL = $failure_return_url;
        $resultUrls->pendingURL = $failure_return_url;
        $resultUrls->expiryURL  = $failure_return_url;
        $resultUrls->cancelURL  = $cancel_return_url;

        return $resultUrls;
    }

    /**
     * Get transaction reference for requests.
     *
     * @param int $order_id
     *
     * @throws \Exception
     *
     * @return string
     */
    public static function getTransactionReferenceByOrderId(int $order_id): string
    {
        return Helper::generateString(12) . '_' . $order_id;
    }

    /**
     * Configure proxy for requests.
     *
     * @return void
     */
    protected function configureProxy(): void
    {
        $proxyConfigProvider = ProxyConfigProvider::instance();

        if ($this->scopeConfig->getValue(
            'web/proxy/use_proxy',
            ScopeInterface::SCOPE_STORE
        )) {
            $proxyConfigProvider->host = $this->scopeConfig->getValue(
                'web/proxy/proxy_host',
                ScopeInterface::SCOPE_STORE
            );
            $proxyConfigProvider->port = $this->scopeConfig->getValue(
                'web/proxy/proxy_port',
                ScopeInterface::SCOPE_STORE
            );
        }
    }

    /**
     * Get API environment from config value.
     *
     * @return string
     */
    public function getApiEnvironment(): string
    {
        return $this->config->getValue('app_mode') === 'live' ?
            Environment::LIVE_MODE : Environment::TRY_MODE;
    }

    /**
     * Get API username from config value.
     *
     * @return string
     */
    public function getApiUsername(): string
    {
        if ($this->getApiEnvironment() === Environment::LIVE_MODE) {
            return $this->config->getValue('api_live_username') ?? "";
        }

        return $this->config->getValue('api_try_username') ?? "";
    }

    /**
     * Get API password from config value.
     *
     * @return string
     */
    public function getApiPassword(): string
    {
        if ($this->getApiEnvironment() === Environment::LIVE_MODE) {
            return $this->config->getValue('api_live_password') ?? "";
        }

        return $this->config->getValue('api_try_password') ?? "";
    }

    /**
     * Get merchant entity from config value.
     *
     * @return string
     */
    public function getMerchantEntity(): string
    {
        return $this->config->getValue(
            'merchant_entity'
        ) ?? "";
    }

    /**
     * Get merchant narrative from config value.
     *
     * @return string
     */
    public function getMerchantNarrative(): string
    {
        return $this->config->getValue(
            'merchant_narrative'
        ) ?? "";
    }

    /**
     * Get merchant description from config value.
     *
     * @return string
     */
    public function getMerchantDescription(): string
    {
        return $this->config->getValue(
            'description'
        ) ?? "";
    }

    /**
     * Get WP Correlation id from headers.
     *
     * @param array $headers
     *
     * @return string
     */
    public static function getWpCorrelationIdFromHeaders(array $headers = []): string
    {
        if (empty($headers)) {
            return "";
        }

        $output = "";

        if (isset($headers["wp-correlationid"])) {
            $output = $headers["wp-correlationid"];
        }

        if (isset($headers["WP-CorrelationId"])) {
            $output = $headers["WP-CorrelationId"];
        }

        if (is_array($output)) {
            $output = array_pop($output);
        }

        return $output;
    }

    /**
     * Load worldpay-php sdk.
     *
     * @return void
     */
    public static function includeSdk(): void
    {
        require_once __DIR__ . '/../worldpay-php-sdk/autoload.php';
    }
}
