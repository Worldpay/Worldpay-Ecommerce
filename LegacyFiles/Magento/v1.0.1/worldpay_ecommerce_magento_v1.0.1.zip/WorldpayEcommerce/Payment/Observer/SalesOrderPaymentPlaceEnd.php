<?php

namespace WorldpayEcommerce\Payment\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

class SalesOrderPaymentPlaceEnd implements ObserverInterface
{
    /**
     * Execute event.
     *
     * @param  Observer  $observer
     *
     * @return void
     */
    public function execute(Observer $observer)
    {
        $payment = $observer->getEvent()->getPayment();
        $order = $payment->getOrder();
        if ($payment->getMethod() === PaymentMethodConfig::CODE &&
            $order->getStatus() === WorldpayService::TRANSACTION_STATUS_PENDING &&
            ($order->getState() === Order::STATE_NEW || $order->getState() === Order::STATE_PROCESSING)) {
            $order->setState(Order::STATE_PENDING_PAYMENT);
            $order->setStatus(Order::STATE_PENDING_PAYMENT);
        }
    }
}
