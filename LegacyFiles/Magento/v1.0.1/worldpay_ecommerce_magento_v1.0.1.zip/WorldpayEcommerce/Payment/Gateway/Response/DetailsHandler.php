<?php
namespace WorldpayEcommerce\Payment\Gateway\Response;

use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class DetailsHandler implements HandlerInterface
{
    public const PAYMENT_ID = 'paymentId';

    public const PAYER_EMAIL = 'payerEmail';

    /**
     * @var SubjectReader
     */
    private SubjectReader $subjectReader;

    /**
     * Constructor
     *
     * @param SubjectReader $subjectReader
     */
    public function __construct(SubjectReader $subjectReader)
    {
        $this->subjectReader = $subjectReader;
    }

    /**
     * Handle response.
     *
     * @param array $handlingSubject
     * @param array $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);
        /** @var OrderPaymentInterface $payment */
        $payment = $paymentDO->getPayment();
        $payment->setAdditionalInformation('hppUrl', $response["hppUrl"] ?? "");
        $payment->setAdditionalInformation('success_guid', $response["success_guid"] ?? "");
        $payment->setAdditionalInformation('failure_guid', $response["failure_guid"] ?? "");
        $payment->setAdditionalInformation('cancel_guid', $response["cancel_guid"] ?? "");
        $payment->setAdditionalInformation('transaction_reference', $response["transaction_reference"] ?? "");

        Logger::setDescription('Details Handler Additional Information')->debug($payment->getAdditionalInformation());
    }
}
