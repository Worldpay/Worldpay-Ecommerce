## Worldpay eCommerce for Magento Community Edition Changelog

### Version 1.0.1
* fixed bug for empty merchant settings fields at fresh module install

### Version 1.0.0
* initial release
