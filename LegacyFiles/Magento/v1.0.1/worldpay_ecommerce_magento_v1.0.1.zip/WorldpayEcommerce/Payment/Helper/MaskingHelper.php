<?php

namespace WorldpayEcommerce\Payment\Helper;

class MaskingHelper
{
    /**
     * Mask the value to display only the last four characters with bullets for the rest.
     *
     * @param string $value
     * @return string
     */
    public static function maskValueWithLastFour(string $value): string
    {
        return str_repeat('*', max(0, strlen($value) - 4)) . substr($value, -4);
    }
}
