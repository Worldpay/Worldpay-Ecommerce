define([
    'jquery'
], function ($) {
    'use strict';
    return function (target) {
        $.validator.addMethod(
            'validate-characters-type',
            function (value) {
                var regex = /^[a-zA-Z0-9\-., ]+$/;
                return regex.test(value);
            },
            $.mage.__('Please enter a valid merchant narrative. Valid characters are: A-Z, a-z, 0-9, hyphen(-), full stop(.), commas(,), space.')
        );
        return target;
    };
});
