<?php

namespace WorldpayEcommerce\Payment\Gateway\Validator;

use Magento\Payment\Gateway\Validator\AbstractValidator;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Payment\Gateway\Validator\ResultInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class AcceptValidator extends AbstractValidator
{
    /**
     * Validate response.
     *
     * @param array $validationSubject
     * @return ResultInterface
     */
    public function validate(array $validationSubject)
    {
        $response = SubjectReader::readResponse($validationSubject);

        $isValid = true;
        $errorCode = [];

        /* Validate response from TransactionSale.php which return response form sdk. */
        if (empty($response) || empty($response["hppUrl"])) {
            $isValid = false;
            $errorCode[] = 'payment_failed_try_again_later';
            Logger::setDescription("Accept Validator invalid hpp url")->alert($response);
        }

        return $this->createResult($isValid, [], $errorCode);
    }
}
