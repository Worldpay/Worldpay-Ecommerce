<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client;

use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Magento\Sales\Model\ResourceModel\Order\Payment\Collection;
use Worldpay\Api\Utils\Helper;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Http\Client\Exception;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use Magento\Framework\App\Config\ScopeConfigInterface;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use Magento\Framework\Locale\Resolver;

class TransactionInitialize implements ClientInterface
{

    /**
     * @var Collection
     */
    private Collection $_orderPayment;

    /**
     * @var Config
     */
    private Config $_config;

    /**
     * @var WorldpayService
     */
    private WorldpayService $_worldpayService;

    /**
     * @var UrlInterface
     */
    private UrlInterface $url;

    /**
     * @var Resolver
     */
    private Resolver $store;

    /**
     * @param Collection $orderPayment
     * @param Config $config
     * @param UrlInterface $url
     * @param ScopeConfigInterface $scopeConfig
     * @param Resolver $store
     */
    public function __construct(
        Collection $orderPayment,
        Config $config,
        UrlInterface $url,
        ScopeConfigInterface $scopeConfig,
        Resolver $store,
    ) {
        $this->_orderPayment = $orderPayment;
        $this->_config = $config;
        $this->_worldpayService = new WorldpayService($config, $scopeConfig);
        $this->url = $url;
        $this->store = $store;
    }

    /**
     * Process request.
     *
     * @param  array  $data
     *
     * @return array
     * @throws \Exception
     */
    protected function process(array $data): array
    {
        $success_guid = Helper::guidv4();
        $failure_guid = Helper::guidv4();
        $cancel_guid  = Helper::guidv4();
        $transaction_reference =  WorldpayService::getTransactionReferenceByOrderId($data["orderId"]);

        $success_return_url = $this->url->getUrl(
            'access_worldpay_hpp/process/returnUrl/',
            ['guid' => $success_guid]
        );
        $failure_return_url = $this->url->getUrl(
            'access_worldpay_hpp/process/returnUrl/',
            ['guid' => $failure_guid]
        );
        $cancel_return_url  = $this->url->getUrl(
            'access_worldpay_hpp/process/returnUrl/',
            ['guid' => $cancel_guid]
        );
        $order_data = [
            "total" => $data["amount"],
            "currency_code" => $data["currency"],
            "billing" => $data["billing"],
            "shipping" => $data["shipping"],
            'locale' => $this->store->getLocale(),
            'customer' => $data["customer"]
        ];
        $output = [
            "success_guid" => $success_guid,
            "failure_guid" => $failure_guid,
            "cancel_guid" => $cancel_guid,
            "transaction_reference" => $transaction_reference,
            "hppUrl" => "",
        ];

        try {
            $worldpay = new WorldpayEcommerce($this->_worldpayService, $order_data);
            $apiResponse = $worldpay->requestHppUrl(
                $transaction_reference,
                $success_return_url,
                $failure_return_url,
                $cancel_return_url
            );

            $dataToLog = [
                'correlationId'             => WorldpayService::getWpCorrelationIdFromHeaders($apiResponse->headers),
                "request"                   => $apiResponse->rawRequest,
                "response"                  => $apiResponse->rawResponse,
                "order_data"                => $order_data,
                "success_guid"              => $success_guid,
                "failure_guid"              => $failure_guid,
                "cancel_guid"               => $cancel_guid,
                "transaction_reference"     => $transaction_reference,
            ];

            if (!$apiResponse->isSuccessful()) {
                throw new \Exception($apiResponse->rawResponse);
            }

            $decodedApiResponse = $apiResponse->jsonDecode();

            $output["hppUrl"] = $decodedApiResponse->url ?? "";

            $dataToLog["hpp_url"] = $output["hppUrl"];
            Logger::setDescription("Retrieve Hpp url")->debug($dataToLog);
        } catch (\Throwable $exception) {
            $dataToLog = [
                "message"                   => $exception->getMessage(),
                "order_data"                => $order_data,
                "success_guid"              => $success_guid,
                "failure_guid"              => $failure_guid,
                "cancel_guid"               => $cancel_guid,
                "transaction_reference"     => $transaction_reference,
                "hpp_url"                   => $output["hppUrl"] ?? "",
            ];
            Logger::setDescription("Retrieve Hpp url failed")->alert($dataToLog);
        }

        return $output;
    }

    /**
     * Place request.
     *
     * @param  TransferInterface  $transferObject
     *
     * @return array
     * @throws ClientException
     */
    public function placeRequest(TransferInterface $transferObject): array
    {

        $data = $transferObject->getBody();
        $response['object'] = ["placeRequest"];

        try {
            $response = $this->process($data);
        } catch (Exception $e) {
            $message = __($e->getMessage() ?: 'Sorry, but something went wrong');
            throw new ClientException($message);
        } finally {
            $log['response'] = (array) $response;
        }

        return $response;
    }
}
