## Worldpay eCommerce for Magento Community Edition Changelog

### Version 1.0.4
* added backwards compatibility with Magento 2.4.5-p9

### Version 1.0.3
* the plugin now supports multiple stores
* fix for refunding negative values
* fix for updating mini-cart if payment failure or cancellation

### Version 1.0.2
* changed wording for some of the merchant settings inputs
* fixed billing and shipping address not being sent to the gateway
* delayed the order confirmation mails to only be sent after a successful payment

### Version 1.0.1
* fixed bug for empty merchant settings fields at fresh module install

### Version 1.0.0
* initial release
