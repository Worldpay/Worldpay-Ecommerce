<?php

namespace Worldpay\Api\Enums;

/**
 * Integrated Worldpay APIs.
 */
class Api
{
    public const ACCESS_WORLDPAY_API = 'Access Worldpay';
}
