var config = {
    map: {
        '*': {
            'refreshMiniCart': 'WorldpayEcommerce_Payment/js/refresh-minicart'
        }
    }
};
