<?php return array(
	'dependencies' => array( 'react', 'wc-blocks-registry', 'wc-settings', 'wp-html-entities' ),
	'version'      => 'e7a55ae8845cf606d834',
);
