<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;

trait WC_Access_Worldpay_Credentials_Validators {

	/**
	 * @return void
	 */
	public function test_api_credentials_request() {
		try {
			if ( ! wp_verify_nonce( wc_get_var( $_REQUEST['_wpnonce'] ),
				'worldpay-ecommerce-test_api_credentials' ) ) {
				throw new \Exception( __( 'Invalid test API credentials request.', 'worldpay-ecommerce-woocommerce' ) );
			}
			if ( 'live' == wc_get_var( $_REQUEST['app_mode'] ) ) {
				$environment  = Environment::LIVE_MODE;
				$password_key = 'app_api_live_password';
			} else {
				$environment  = Environment::TRY_MODE;
				$password_key = 'app_api_try_password';
			}

			$this->api_config_provider                    = AccessWorldpayConfigProvider::instance();
			$this->api_config_provider->environment       = $environment;
			$this->api_config_provider->username          = wc_get_var( $_REQUEST['app_username'] );
			$this->api_config_provider->password          = $this->replace_mask( $password_key,
				wc_get_var( $_REQUEST['app_password'] ) );
			$this->api_config_provider->merchantEntity    = $this->replace_mask( 'app_merchant_entity',
				wc_get_var( $_REQUEST['app_merchant_entity'] ), true );
			$this->api_config_provider->merchantNarrative = 'Test API Credentials';

			$api_response = $this->test_api_credentials();
			if ( $api_response->isSuccessful() ) {
				wp_send_json( [
					'status'  => 'success',
					'message' => __( 'Worldpay Payments connected successfully to the payment gateway with your provided credentials.',
						'worldpay-ecommerce-woocommerce' ),
				] );

				return;
			}
			if ( $api_response->hasServerError() ) {
				throw new \Exception( 'Worldpay Payments could not connect to Access Worldpay API. Please try again later.' );
			}
			throw new \Exception( 'Worldpay Payments could not connect to the payment gateway with your provided credentials.' );
		} catch ( \Exception $e ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => $e->getMessage(),
			] );
		}
	}

	/**
	 * @return void
	 */
	public function test_api_credentials_save() {
		try {
			$api_response = $this->test_api_credentials();
			if ( $api_response->isSuccessful() ) {
				WC_Admin_Settings::add_message( __( 'Worldpay Payments connected successfully to the payment gateway with your provided credentials.',
					'worldpay-ecommerce-woocommerce' ) );

				return;
			}
			if ( $api_response->hasServerError() ) {
				throw new \Exception( 'Your settings were saved, but Worldpay Payments could not connect to Access Worldpay API. Please try again later.' );
			}
			throw new \Exception( 'Your settings were saved, but Worldpay Payments could not connect to the payment gateway with your provided credentials.' );
		} catch ( \Exception $e ) {
			WC_Admin_Settings::add_error( $e->getMessage() );
		}
	}

	/**
	 * @return ApiResponse
	 * @throws AuthenticationException
	 */
	public function test_api_credentials(): ApiResponse {
		$api = $this->initiliaze_api();

		$api_response = $api->HPPSetup( 1 )
		                    ->withCurrency( 'GBP' )
		                    ->withTransactionReference( Helper::generateString( 12 ) . '_test' )
		                    ->execute();
		if ( wc_string_to_bool( $this->get_option( 'app_debug' ) ) ) {
			$data_to_log = [
				'rawRequest=' . $api_response->rawRequest,
				'rawResponse=' . $api_response->rawResponse,
				'statusCode=' . $api_response->statusCode,
				'curlError=' . $api_response->curlError,
				'headers=' . json_encode( $api_response->headers ),
			];
			$data_to_log = implode( ' | ', $data_to_log );
			wc_get_logger()->debug( $data_to_log );
		}

		return $api_response;
	}
}
