let accessWorldpayCheckout = window.accessWorldpayCheckout;
let accessWorldpayCheckoutIntegration = {
    deviceSessionIsSent: false,
    transactionReference: null,
    checkoutPaymentFormInit: function () {
        accessWorldpayCheckout.init(accessWorldpayCheckoutIntegration.initCheckoutCallback);
    },
    initCheckoutCallback: function (error, checkout) {
        if (error) {
            accessWorldpayCheckoutIntegration.displayError(error);
            return;
        }
        accessWorldpayCheckout.checkout = checkout;
        accessWorldpayCheckoutIntegration.handleCardHolderNameInput();
    },
    handleCardHolderNameInput: function() {
        let cardHolderInput = $(accessWorldpayCheckout.config.paymentFormExtraFields.cardHolderName.selector);
        cardHolderInput.attr('placeholder', accessWorldpayCheckout.config.paymentFormExtraFields.cardHolderName.placeholder);
        cardHolderInput.on('focus', function () {
            if ($(this).val().length === 0) {
                $(this).attr('placeholder', accessWorldpayCheckout.config.paymentFormExtraFields.cardHolderName.placeholder);
                $(this).css('color', '');
                $(this).removeClass('valid invalid');
            }
        });
        cardHolderInput.on('keydown', function () {
            if ($(this).val().length === 0) {
                $(this).attr('placeholder', '');
            }
        });
        cardHolderInput.on('input', function () {
            let length = this.value.length;
            if (length > 0 && length <= 255) {
                $(this).css('color', 'green').removeClass('invalid').addClass('valid');
            } else if (length > 255) {
                $(this).css('color', 'red').removeClass('valid').addClass('invalid');
            }
        });
        cardHolderInput.on('blur', function () {
            if ($(this).val().length === 0) {
                $(this).attr('placeholder', accessWorldpayCheckout.config.paymentFormExtraFields.cardHolderName.placeholder);
                $(this).css('color', '');
            }
        });
    },
    placeOrderRequest: function() {
        accessWorldpayCheckout.request(
            'POST',
            'index.php?route=extension/worldpay_ecommerce/payment/' + window.merchantData.paymentMethod + '.initializePayment&language=' + window.merchantData.language,
            {
                'payment_session': accessWorldpayCheckout.paymentSession,
                'card_holder_name': $('#access_worldpay_checkout-card-holder-name').val(),
            },
            'JSON',
            accessWorldpayCheckoutIntegration.placeOrderRequestSuccessCallback,
        );
    },
    placeOrderRequestSuccessCallback: function(result) {
        console.log(result);
        if (result.error) {
            accessWorldpayCheckoutIntegration.displayError(result.error);
            accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
        } else {
            if (result.result === 'success') {
                if (result.status === 'authorized' || result.status === 'sentForSettlement' && result.redirect) {
                    window.location = result.redirect.replace(/&amp;/g, '&');
                } else if (result.status === '3dsDeviceDataRequired') {
                    accessWorldpayCheckoutIntegration.transactionReference = result.transactionReference;
                    accessWorldpayCheckout.setupDeviceDataCollectionIframe(result.deviceDataCollectionUrl.replace(/&amp;/g, '&'));
                }
            } else if (result.result === 'failed'){
                accessWorldpayCheckoutIntegration.displayError(result.message);
                accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
                accessWorldpayCheckout.session = null;
            }
        }
    },
    generatePaymentSession: function () {
        if (accessWorldpayCheckoutIntegration.isCardHolderInputValid()) {
            accessWorldpayCheckoutIntegration.addPaymentFormProcessing();
            accessWorldpayCheckout.generatePaymentSession(accessWorldpayCheckoutIntegration.generatePaymentSessionCallback);
            return true;
        }
        return false;
    },
    generatePaymentSessionCallback: function(error, paymentSession) {
        if (error) {
            error = error.includes('The payment form is invalid or incomplete') ?
                'The payment form is invalid or incomplete.' :
                'Something went wrong while processing your payment. Please try again later.';
            accessWorldpayCheckoutIntegration.displayError(error);
            accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
            return;
        }
        accessWorldpayCheckout.paymentSession = paymentSession;
        accessWorldpayCheckoutIntegration.placeOrderRequest();
    },
    addPaymentFormProcessing: function() {
        $('#access_worldpay_checkout-payment-processing-spinner').addClass('d-flex').removeClass('d-none');
        $('#access_worldpay_checkout-button-confirm').addClass('d-none');
    },
    removePaymentFormProcessing: function() {
        $('#access_worldpay_checkout-payment-processing-spinner').addClass('d-none').removeClass('d-flex');
        $('#access_worldpay_checkout-button-confirm').removeClass('d-none');
    },
    isCardHolderInputValid: function() {
        let cardHolderInput = $(accessWorldpayCheckout.config.paymentFormExtraFields.cardHolderName.selector);
        if (cardHolderInput.val().trim().length === 0 || cardHolderInput.val().length > 255) {
            accessWorldpayCheckoutIntegration.displayError('The payment form is invalid or incomplete.');
            return false;
        }
        return true;
    },
    displayError: function(errorMessage) {
        $('#alert').prepend(
            '<div class="alert alert-danger alert-dismissible"><i class="fa-solid fa-circle-exclamation"></i> ' + errorMessage + ' <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'
        );
    },
    listen3DSDeviceDataCollectionResultMessage: function() {
        let timeoutID;

        function handleMessage(event) {
            if (event.origin !== window.merchantData.authentication3dsApplicationUrl) {
                return;
            }

            if (typeof event.data === 'undefined' || !event.data) {
                return;
            }

            let postMessage = JSON.parse(event.data);
            if (typeof postMessage.MessageType === 'undefined' || postMessage.MessageType !== 'profile.completed' || typeof postMessage.Status === 'undefined' || postMessage.Status !== true) {
                return;
            }

            accessWorldpayCheckoutIntegration.deviceSessionIsSent = true;
            window.removeEventListener('message', handleMessage);
            clearTimeout(timeoutID);
            accessWorldpayCheckout.submitDeviceDataCollectionRequest({
                collectionReference: postMessage.SessionId,
                transactionReference: accessWorldpayCheckoutIntegration.transactionReference
            },
            accessWorldpayCheckoutIntegration.submitDeviceDataCollectionRequestSuccessCallback,
            accessWorldpayCheckoutIntegration.submitDeviceDataCollectionRequestErrorCallback);
        }

        window.addEventListener('message', handleMessage);
        timeoutID = setTimeout(function () {
            window.removeEventListener('message', handleMessage);
            if (false === accessWorldpayCheckoutIntegration.deviceSessionIsSent) {
                accessWorldpayCheckoutIntegration.deviceSessionIsSent = true;
                accessWorldpayCheckout.submitDeviceDataCollectionRequest(null,
                    accessWorldpayCheckoutIntegration.submitDeviceDataCollectionRequestSuccessCallback,
                    accessWorldpayCheckoutIntegration.submitDeviceDataCollectionRequestErrorCallback);
            }
        }, 10000);
    },
    resetDeviceDataCollectionIframe: function() {
        $(accessWorldpayCheckout.config.deviceDataCollection.iframe.selector).empty();
    },
    submitDeviceDataCollectionRequestSuccessCallback: function(result) {
        console.log(result);
        if (result.status === 'authorized' || result.status === 'sentForSettlement' && result.redirect) {
            window.location = result.redirect.replace(/&amp;/g, '&');
        } else if (result.status === '3dsChallenged') {
            accessWorldpayCheckoutIntegration.setChallengeModalSize(result.challengeWindowSize);
            accessWorldpayCheckout.setupThreeDSChallengeIframe(result.challengeUrl.replace(/&amp;/g, '&'));
            accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
            accessWorldpayCheckoutIntegration.displayChallengeModal();
        } else {
            accessWorldpayCheckoutIntegration.deviceSessionIsSent = false;
            accessWorldpayCheckout.session = null;
            accessWorldpayCheckoutIntegration.displayError(result.message);
            accessWorldpayCheckoutIntegration.resetDeviceDataCollectionIframe();
            accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
        }
    },
    submitDeviceDataCollectionRequestErrorCallback: function(result) {
        accessWorldpayCheckoutIntegration.deviceSessionIsSent = false;
        accessWorldpayCheckout.session = null;
        accessWorldpayCheckoutIntegration.displayError(result.message);
        accessWorldpayCheckoutIntegration.resetDeviceDataCollectionIframe();
        accessWorldpayCheckoutIntegration.removePaymentFormProcessing();
    },
    setChallengeModalSize: function(challengeWindowSize) {
        if (challengeWindowSize) {
            $(accessWorldpayCheckout.config.threeDSChallenge.modal.selector).width(challengeWindowSize.width);
            $(accessWorldpayCheckout.config.threeDSChallenge.modal.selector).height(challengeWindowSize.height);
        }
    },
    displayChallengeModal: function() {
        $(accessWorldpayCheckout.config.threeDSChallenge.modal.selector).fadeIn();
        $(accessWorldpayCheckout.config.threeDSChallenge.overlay.selector).fadeIn();
    },
    listen3DSChallengeResultMessage: function(event) {
        if ('undefined' !== typeof event.detail.data) {
            let challengeResponse = JSON.parse(event.detail.data);
            if ('success' === challengeResponse.result) {
                window.location = challengeResponse.redirect.replace(/&amp;/g, '&');
            } else {
                accessWorldpayCheckoutIntegration.displayError(challengeResponse.message)
                accessWorldpayCheckoutIntegration.reset3DSChallengeIframe();
                accessWorldpayCheckoutIntegration.resetDeviceDataCollectionIframe();
                accessWorldpayCheckout.paymentSession = null;
            }
        }
    },
    reset3DSChallengeIframe: function () {
        $(accessWorldpayCheckout.config.threeDSChallenge.modal.selector).fadeOut();
        $(accessWorldpayCheckout.config.threeDSChallenge.overlay.selector).fadeOut();
        $(accessWorldpayCheckout.config.threeDSChallenge.iframe.selector).empty();
    },
};

accessWorldpayCheckout.config = {
    merchantCheckoutId: window.merchantData.merchantCheckoutId,
    paymentForm: {
        selector: "#access_worldpay_checkout-payment-form",
        fields: {
            pan: {
                selector: "#access_worldpay_checkout-card-number",
                placeholder: "4444 3333 2222 1111"
            },
            expiry: {
                selector: "#access_worldpay_checkout-card-expiry",
                placeholder: "MM/YY"
            },
            cvv: {
                selector: "#access_worldpay_checkout-card-cvc",
                placeholder: "123"
            }
        },
        acceptedCardBrands: window.merchantData.cardBrands,
        enablePanFormatting: true,
        styles: {
            "input": {
                "color": "black",
                "font-weight": "bold",
                "font-size": "15px",
                "letter-spacing": "3px"
            },
            "input.is-valid": {
                "color": "green !important"
            },
            "input.is-invalid": {
                "color": "red !important"
            },
            "input.is-onfocus": {
                "color": "black !important"
            }
        }
    },
    paymentFormExtraFields: {
        cardHolderName: {
            selector: '#access_worldpay_checkout-card-holder-name',
            placeholder: 'Card holder name'
        }
    },
    checkoutForm: {
        selector: null,
        submitUrl: null,
    },
    deviceDataCollection: {
        iframe: {
            selector: '#access_worldpay_checkout-ddc-iframe'
        },
        submitUrl: window.merchantData.deviceDataCollectionEndpoint
    },
    threeDSChallenge: {
        iframe: {
            selector: '#access_worldpay_checkout-challenge-iframe'
        },
        modal: {
            selector: '#access_worldpay_checkout-modal'
        },
        overlay: {
            selector: '#access_worldpay_checkout-modal-overlay'
        }
    },
    events: [
        {
            name: 'access_worldpay_checkout_init',
            callback: accessWorldpayCheckoutIntegration.checkoutPaymentFormInit,
            selector: '#access_worldpay_checkout-payment-form'
        },
        {
            name: 'click',
            callback: accessWorldpayCheckoutIntegration.generatePaymentSession,
            selector: '#access_worldpay_checkout-button-confirm'
        },
        {
            name: 'access_worldpay_checkout_post_message_ddc_trigger',
            callback: accessWorldpayCheckoutIntegration.listen3DSDeviceDataCollectionResultMessage,
            selector: null
        },
        {
            name: 'access_worldpay_checkout_payment_3ds_completed',
            callback: accessWorldpayCheckoutIntegration.listen3DSChallengeResultMessage,
            selector: null
        },
    ],
};

function initializeAccessWorldpayCheckout(){
    accessWorldpayCheckout.initEvents();
    $('#access_worldpay_checkout-payment-form').trigger('access_worldpay_checkout_init');
}
