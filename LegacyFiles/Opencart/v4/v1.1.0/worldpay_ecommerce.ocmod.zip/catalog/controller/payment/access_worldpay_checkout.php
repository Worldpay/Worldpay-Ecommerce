<?php

namespace Opencart\Catalog\Controller\Extension\WorldpayEcommerce\Payment;

use Opencart\Extension\WorldpayEcommerce\System\Library\AccessWorldpayPaymentMethods;
use Opencart\Extension\WorldpayEcommerce\System\Library\Logger;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout;
use Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayService;
use Worldpay\Api\Enums\ChallengeWindowSize;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Enums\PaymentStatus;
use Worldpay\Api\Enums\RequestMethods;
use Worldpay\Api\AccessWorldpay as AccessWorldpayManager;

class AccessWorldpayCheckout extends AccessWorldpay {

	/**
	 * @var string
	 */
	protected $payment_method = AccessWorldpayPaymentMethods::CHECKOUT;

	/**
	 * Index - display payment form.
	 *
	 * @return array
	 */
	public function index() {
		$data = parent::index();

		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$worldpay = new WorldpayEcommerceCheckout($this->worldpay_service);

		$card_brands = unserialize($this->config->get('payment_' . AccessWorldpayPaymentMethods::CHECKOUT . '_app_card_brands'));
		$data = array_merge($data, [
			'checkout_sdk_url' => $worldpay->getCheckoutSdkUrl(),
			'checkout_id'      => $this->worldpay_service->getCheckoutId(),
			'card_brands'      => false === $card_brands ? [] : $card_brands,
			'app_mode'         => $this->config->get('payment_' . AccessWorldpayPaymentMethods::CHECKOUT . '_app_mode'),
			'submit_3ds_data_device_endpoint'    => $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.submit3DSDeviceDataCollection', ['language' => $this->config->get('config_language')], false),
			'authentication_3ds_application_url' => Environment::LIVE_MODE === $this->config->get('payment_'.$this->payment_method.'_app_mode') ? AccessWorldpayManager::LIVE_CARDINAL_URL : AccessWorldpayManager::TRY_CARDINAL_URL,
		]);

		return $this->load->view('extension/worldpay_ecommerce/payment/' . $this->payment_method, $data);
	}

	/**
	 * Confirm - redisplay payment form for confirmation.
	 *
	 * @return void
	 */
	public function confirm(): void {
		$this->response->setOutput($this->index());
	}

	/**
	 * Initialize payment.
	 *
	 * @return void
	 * @throws \Exception
	 */
	public function initializePayment(): void {
		$json = [];
		$api_response = null;
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);

		Logger::config($this->config, $this->payment_method);

		if ($this->request->server['REQUEST_METHOD'] !== RequestMethods::POST) {
			$json['error'] = $this->language->get('error_request');
		} else if (empty($this->request->post['payment_session'])) {
			$json['error'] = $this->language->get('error_payment_session');
		} else if (empty($this->request->post['card_holder_name'])) {
			$json['error'] = $this->language->get('error_card_holder_name');
		}
		if (!$json) {
			$this->registry->set( 'worldpay_service', new WorldpayService( $this->registry, $this->payment_method ) );
			$this->load->model( 'extension/worldpay_ecommerce/payment/' . $this->payment_method );
			$this->load->model( 'checkout/order' );
			$json = $this->validateOrder();

			$order_id   = $this->session->data['order_id'] ?? 0;
			$order_data = $this->model_checkout_order->getOrder( $order_id );
			if ( empty( $order_data ) ) {
				$json['error'] = $this->language->get( 'error_order' );
			}
		}
		if (!$json) {
			$transaction_reference = WorldpayService::getTransactionReferenceByOrderId($order_id);

			$order_currency_conversion_log_info = [
				'session_currency'     => $this->session->data['currency'],
				'config_currency'      => $this->config->get('config_currency'),
				'order_total'          => $order_data['total'],
				'order_currency_code'  => $order_data['currency_code'],
				'order_currency_value' => $order_data['currency_value'],
			];
			$order_data['total'] = $this->currency->format($order_data['total'], $order_data['currency_code'], $order_data['currency_value'], false);
			$order_currency_conversion_log_info['currency_conversion_amount'] = $order_data['total'];
			$json['order_data'] = $order_data;

			try {
				$worldpay = new \Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout($this->worldpay_service, $order_data);
				$threeDSChallengeReturnUrl = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.handle3DSChallengeReturnUrl', ['language' => $this->config->get('config_language')], false);

				$api_response = $worldpay->initializePayment(
					$transaction_reference,
					$this->request->post['payment_session'],
					$this->request->post['card_holder_name'],
					$threeDSChallengeReturnUrl
				);
				$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
				$this->{$model}->saveTransactionInitialDetails($order_data, $transaction_reference, $api_response->outcome);

				// Workaround for internal OpenCart 4 bug for products that don't require shipping (fixed in version 4.1.0.0)
				if (empty($order_data['shipping_method']['name']) && VERSION < '4.1.0.0') {
					$shipping_method = $order_data['shipping_method'];
					$shipping_method['name'] = '';
					$this->{$model}->setOrderShippingMethod($order_id, json_encode($shipping_method));
				}

				switch ($api_response->outcome) {

					case PaymentStatus::AUTHORIZED:
					case PaymentStatus::SENT_FOR_SETTLEMENT:

						$this->paymentCompleted($order_data, $transaction_reference, $api_response->outcome, $this->getLinkDataForPaymentManagement($api_response->_actions->refundPayment->href ?? ''));
						$json['result'] = 'success';
						$json['status'] = $api_response->outcome;
						$json['redirect'] = $this->url->link('checkout/success', ['language' => $this->config->get('config_language')], false);
						break;

					case PaymentStatus::THREE_DS_DEVICE_DATA_REQUIRED:
						$this->paymentPending($order_data, $transaction_reference, $api_response->outcome, $api_response->_actions->supply3dsDeviceData->href ?? '');
						$json['result'] = 'success';
						$json['status'] = $api_response->outcome;
						$json['transactionReference'] = $transaction_reference;
						$json['deviceDataCollectionUrl'] = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.handleDeviceDataCollection',
							[
								'jwt' => $api_response->deviceDataCollection->jwt ?? '',
								'url' => $api_response->deviceDataCollection->url ?? '',
								'bin' => $api_response->deviceDataCollection->bin ?? '',
								'language' => $this->config->get('config_language')
							], false);
						break;

					case PaymentStatus::SENT_FOR_CANCELLATION:
					case PaymentStatus::FRAUD_HIGH_RISK:
					case PaymentStatus::REFUSED:
						$this->paymentFailed($order_data, $transaction_reference, $api_response->outcome, '.');
						$json['result'] = 'failed';
						$json['status'] = $api_response->outcome;
						$json['message'] = $this->language->get('failed_payment');
						break;

					default:
						break;
				}

			} catch (\Throwable $exception) {
				$data_to_log = [
					"payment_method"            => $this->payment_method,
					"message"                   => $exception->getMessage(),
					"order_id"                  => $order_id,
					"order_data"                => $order_data,
					"transaction_reference"     => $transaction_reference,
					"order_currency_conversion" => $order_currency_conversion_log_info,
					"api_response"              => json_encode($api_response)
				];
				Logger::setDescription("Initialize payment failed")->alert($data_to_log);

				$json['error'] = $this->language->get('error_payment');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Process completed payment.
	 *
	 * @param  array  $order_data
	 * @param  string  $transaction_reference
	 * @param  string  $payment_status
	 * @param  array  $link_data
	 *
	 * @return void
	 */
	protected function paymentCompleted(array $order_data, string $transaction_reference, string $payment_status, array $link_data) {
		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$amount = $this->{$model}->getTransactionAmountByReference($transaction_reference);
		$note = $this->currency->format($amount, $order_data['currency_code'], 1) . ' Payment successful via Worldpay. Transaction reference: ' . $transaction_reference;
		$this->model_checkout_order->addHistory($order_data['order_id'], WorldpayService::OC_ORDER_STATUS_ID_PROCESSING, $note);
		$this->{$model}->updateTransactionStatus($transaction_reference, WorldpayService::TRANSACTION_STATUS_SUCCESS, $payment_status, $link_data);

		$data_to_log = [
			"payment_method"        => $this->payment_method,
			"transaction_reference" => $transaction_reference,
			"order_data"            => $order_data,
			"payment_status"        => $payment_status,
		];
		Logger::setDescription("Payment completed")->debug($data_to_log);
	}

	/**
	 *  Process pending payment.
	 *
	 * @param  array  $order_data
	 * @param  string  $transaction_reference
	 * @param  string  $payment_status
	 * @param  string  $supply_3ds_device_data_url
	 *
	 * @return void
	 */
	protected function paymentPending(array $order_data, string $transaction_reference, string $payment_status, string $supply_3ds_device_data_url = '') {
		$note = $this->currency->format($order_data['total'], $order_data['currency_code'], 1) . ' Awaiting payment via Worldpay. Transaction reference: ' . $transaction_reference;
		$this->model_checkout_order->addHistory($order_data['order_id'], WorldpayService::OC_ORDER_STATUS_ID_PENDING, $note);
		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$this->{$model}->updateTransactionStatus($transaction_reference, WorldpayService::TRANSACTION_STATUS_PENDING, $payment_status);
		if ($supply_3ds_device_data_url) {
			$this->{$model}->set3DSDeviceDataUrl($transaction_reference, $supply_3ds_device_data_url);
		}

		$data_to_log = [
			"payment_method"        => $this->payment_method,
			"transaction_reference" => $transaction_reference,
			"order_data"            => $order_data,
			"payment_status"        => $payment_status,
		];
		Logger::setDescription("Payment pending")->debug($data_to_log);
	}

	/**
	 * Process failed payment.
	 *
	 * @param  array  $order_data
	 * @param  string  $transaction_reference
	 * @param  string  $payment_status
	 * @param  string  $reason
	 *
	 * @return void
	 */
	protected function paymentFailed(array $order_data, string $transaction_reference, string $payment_status, string $reason = '') {
		$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
		$amount = $this->{$model}->getTransactionAmountByReference($transaction_reference);
		$message = $reason === '' ? $this->language->get('failed_payment_note') : $this->language->get('failed_payment_note').$reason;
		$note = $this->currency->format($amount, $order_data['currency_code'], 1) . ' '.$message.' Transaction reference: ' . $transaction_reference;
		$this->model_checkout_order->addHistory($order_data['order_id'], WorldpayService::OC_ORDER_STATUS_ID_FAILED, $note);
		$this->{$model}->updateTransactionStatus($transaction_reference, WorldpayService::TRANSACTION_STATUS_FAILED, $payment_status);

		$data_to_log = [
			"payment_method"        => $this->payment_method,
			"transaction_reference" => $transaction_reference,
			"order_data"            => $order_data,
			"payment_status"        => $payment_status,
			"reason"                => $reason,
		];
		Logger::setDescription("Payment failed")->debug($data_to_log);
	}

	/**
	 * Display device data collection form.
	 *
	 * @return void
	 */
	public function handleDeviceDataCollection() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		Logger::config($this->config, $this->payment_method);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$worldpay = new \Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout($this->worldpay_service, []);

		try {
			if ($this->request->server['REQUEST_METHOD'] !== RequestMethods::GET) {
				throw new \Exception('Method not allowed for this request. Please use one of the allowed methods.');
			}
			$device_data_collection_form = $worldpay->getDeviceDataCollectionForm($this->request->get['url'], $this->request->get['bin'], $this->request->get['jwt']);
			$this->response->addHeader('Content-Type: text/html');
			$this->response->setOutput($device_data_collection_form->render());
		} catch ( \Exception $e ) {
			Logger::setDescription("Handle device data collection")->alert(['message' => 'Unsupported method attempt']);
			exit();
		}
	}

	/**
	 * Submit device data collection for processing.
	 *
	 * @return void
	 */
	public function submit3DSDeviceDataCollection() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		Logger::config($this->config, $this->payment_method);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$worldpay = new \Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout($this->worldpay_service, []);
		$api_response = null;
		$json = [];
		$order_id = $this->session->data['order_id'] ?? 0;

		try {
			if ($this->request->server['REQUEST_METHOD'] !== RequestMethods::POST) {
				throw new \Exception('Method not allowed for this request. Please use one of the allowed methods.');
			}
			$this->load->model('checkout/order');
			$order_data = $this->model_checkout_order->getOrder($order_id);

			$collection_reference = $this->request->post['collectionReference'] ?? '';
			$transaction_reference = $this->request->post['transactionReference'];
			$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
			$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
			$supply_3ds_device_link_data = $this->{$model}->get3DSDeviceDataUrlByTransactionReference($this->request->post['transactionReference']);

			$api_response = $worldpay->supply3DSDeviceData(
				$supply_3ds_device_link_data['supply_3ds_device_data_url'],
				$collection_reference
			);

			switch ($api_response->outcome) {

				case PaymentStatus::AUTHORIZED:
				case PaymentStatus::SENT_FOR_SETTLEMENT:
					$this->paymentCompleted($order_data, $transaction_reference, $api_response->outcome, $this->getLinkDataForPaymentManagement($api_response->_actions->refundPayment->href ?? ''));
					$json['result'] = 'success';
					$json['status'] = $api_response->outcome;
					$json['redirect'] = $this->url->link('checkout/success', ['language' => $this->config->get('config_language')], false);
					break;

				case PaymentStatus::THREE_DS_CHALLENGED:
					$json['result'] = 'success';
					$json['status'] = $api_response->outcome;
					$this->{$model}->set3DSCompleteChallengeUrl($transaction_reference, $api_response->_actions->complete3dsChallenge->href);
					$json['challengeUrl'] = $this->url->link('extension/worldpay_ecommerce/payment/' . $this->payment_method . '.handle3DSChallenge',
						[
							'reference'              => $api_response->challenge->reference ?? '',
							'url'                    => $api_response->challenge->url ?? '',
							'jwt'                    => $api_response->challenge->jwt ?? '',
							'payload'                => $api_response->challenge->payload ?? '',
							'hash'                   => base64_encode($transaction_reference),
							'language' => $this->config->get('config_language')
						], false);
					$challenge_window_size = $this->getChallengeWindowSize( $api_response->challenge->payload ?? '' );
					if ( ! empty( $challenge_window_size ) ) {
						$json['challengeWindowSize'] = $challenge_window_size;
					}
					break;

				case PaymentStatus::SENT_FOR_CANCELLATION:
				case PaymentStatus::REFUSED:
				case PaymentStatus::THREE_DS_AUTHENTICATION_FAILED:
				case PaymentStatus::THREE_DS_UNAVAILABLE:
					$reason = '.';
					if ( PaymentStatus::THREE_DS_AUTHENTICATION_FAILED === $api_response->outcome ) {
						$reason = ' because 3DS authentication did not succeed.';
					} elseif ( PaymentStatus::THREE_DS_UNAVAILABLE === $api_response->outcome ) {
						$reason = ' because 3DS is not available at the moment.';
					}
					$this->paymentFailed($order_data, $transaction_reference, $api_response->outcome, $reason);
					$json['result'] = 'failed';
					$json['status'] = $api_response->outcome;
					$json['message'] = $this->language->get('failed_payment_note') . $reason;
					break;

				default:
					break;
			}
		} catch (\Exception $e ) {
			$data_to_log = [
				"payment_method"            => $this->payment_method,
				"message"                   => $e->getMessage(),
				"order_id"                  => $order_id,
				"api_response"              => json_encode($api_response)
			];
			Logger::setDescription("Provide 3DS Data failed")->alert($data_to_log);
			$json['error'] = $this->language->get('error_payment');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Display 3ds challenge form.
	 *
	 * @return void
	 */
	public function handle3DSChallenge() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		Logger::config($this->config, $this->payment_method);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$worldpay = new \Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout($this->worldpay_service, []);

		try {
			if ($this->request->server['REQUEST_METHOD'] !== RequestMethods::GET) {
				throw new \Exception('Method not allowed for this request. Please use one of the allowed methods.');
			}
			$challenge_form = $worldpay->get3DSChallengeForm($this->request->get['url'], $this->request->get['jwt'], $this->request->get['hash']);
			$this->response->addHeader('Content-Type: text/html');
			$this->response->setOutput($challenge_form->render());
		} catch ( \Exception $e ) {
			Logger::setDescription("Handle 3ds challenge")->alert(['message' => 'Unsupported method attempt']);
			exit();
		}
	}

	/**
	 * Process 3ds challenge result.
	 *
	 * @return void
	 */
	public function handle3DSChallengeReturnUrl() {
		$this->load->language('extension/worldpay_ecommerce/payment/' . $this->payment_method);
		Logger::config($this->config, $this->payment_method);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry, $this->payment_method));
		$worldpay = new \Opencart\Extension\WorldpayEcommerce\System\Library\WorldpayEcommerceCheckout($this->worldpay_service, []);
		$api_response = null;
		$order_id     = null;
		try {
			if ($this->request->server['REQUEST_METHOD'] !== RequestMethods::POST) {
				throw new \Exception('Method not allowed for this request. Please use one of the allowed methods.');
			}

			if (!isset($this->request->post['MD'] ) ) {
				throw new \Exception( 'Invalid request. There is no hash in the request.');
			}

			$transaction_reference = base64_decode($this->request->post['MD']);
			$order_id = explode('_', $transaction_reference)[1];
			$this->load->model('checkout/order');
			$order_data = $this->model_checkout_order->getOrder($order_id);

			$this->load->model('extension/worldpay_ecommerce/payment/' . $this->payment_method);
			$model = 'model_extension_worldpay_ecommerce_payment_' . $this->payment_method;
			$complete_3ds_challenge_url = $this->{$model}->get3DSCompleteChallengeByTransactionReference($transaction_reference)['complete_3ds_challenge_url'];

			$api_response = $worldpay->fetch3DSChallengeResult($complete_3ds_challenge_url);

			switch ($api_response->outcome) {

				case PaymentStatus::AUTHORIZED:
				case PaymentStatus::SENT_FOR_SETTLEMENT:
					$this->paymentCompleted($order_data, $transaction_reference, $api_response->outcome, $this->getLinkDataForPaymentManagement($api_response->_actions->refundPayment->href ?? ''));
					$json['result'] = 'success';
					$json['status'] = $api_response->outcome;
					$json['redirect'] = $this->url->link('checkout/success', ['language' => $this->config->get('config_language')], false);
					break;

				case PaymentStatus::SENT_FOR_CANCELLATION:
				case PaymentStatus::REFUSED:
				case PaymentStatus::THREE_DS_AUTHENTICATION_FAILED:
				case PaymentStatus::THREE_DS_UNAVAILABLE:
					$reason = '.';
					if ( PaymentStatus::THREE_DS_AUTHENTICATION_FAILED === $api_response->outcome ) {
						$reason = ' because 3DS authentication did not succeed.';
					} elseif ( PaymentStatus::THREE_DS_UNAVAILABLE === $api_response->outcome ) {
						$reason = ' because 3DS is not available at the moment.';
					}
					$this->paymentFailed($order_data, $transaction_reference, $api_response->outcome, $reason);
					$json['result'] = 'failed';
					$json['status'] = $api_response->outcome;
					$json['message'] = $this->language->get('failed_payment_note') . $reason;
					break;

				default:
					break;
			}

		} catch (\Exception $e ) {
			$data_to_log = [
				"payment_method"            => $this->payment_method,
				"message"                   => $e->getMessage(),
				"order_id"                  => $order_id,
				"api_response"              => json_encode($api_response)
			];
			Logger::setDescription("Process 3DS Challenge result failed")->alert($data_to_log);
			$json['error'] = $this->language->get('error_payment');
		}

		$data = json_encode($json);
		$output = "
			<html>
				<head></head>
				<body>
			        <script>
			            window.onload = function() {
			                let eventType = 'access_worldpay_checkout_payment_3ds_completed';
			                let eventData = {
			                    detail: {
			                        data: '$data'
			                    },
			                }
			                window.parent.dispatchEvent(new CustomEvent(eventType, eventData));
			            }
			        </script>
				</body>
			</html>";
		$this->response->addHeader('Content-Type: text/html');
		$this->response->setOutput($output);
	}

	/**
	 * Return challenge window size from payload
	 *
	 * @param $payload
	 *
	 * @return array
	 */
	public function getChallengeWindowSize( $payload = null ) {
		$challenge_window_size = array();

		if (empty($payload)) {
			return $challenge_window_size;
		}

		$payload = base64_decode($payload);
		if (empty($payload)) {
			return $challenge_window_size;
		}

		$payload = json_decode($payload,true);
		if (empty($payload)) {
			return $challenge_window_size;
		}

		$challenge_window_mode = $payload['challengeWindowSize'] ?? '';
		if (empty($challenge_window_mode)) {
			return $challenge_window_size;
		}

		$challenge_window_size = ChallengeWindowSize::$challengeWindowSizeMapping[$challenge_window_mode] ?? [];
		if ('05' === $challenge_window_mode || '5' === $challenge_window_mode) {
			$challenge_window_size = [
				'width'  => 600,
				'height' => 700,
			];
		}

		return $challenge_window_size;
	}

	/**
	 * @param  string  $url
	 *
	 * @return array
	 */
	public function getLinkDataForPaymentManagement(string $url) {
		$data = [];
		if (!$url) {
			return $data;
		}
		$data = [
			'payment_env' => 'live',
		];
		if (str_contains($url, 'try')) {
			$data['payment_env'] = 'try';
		}
		$url_strings       = explode('/', str_replace('https://', '', $url));
		$data['link_data'] = $url_strings[3];

		return $data;
	}
}
