<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library;

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';

use Opencart\System\Engine\Config;
use Opencart\System\Library\Log;
use Psr\Log\LogLevel;
use Worldpay\Api\Utils\Helper;

class Logger {
	/**
	 * @var Log
	 */
	protected static Log $oc_log;

	/**
	 * @var string
	 */
	protected static string $log_description = "";

	/**
	 * @var string
	 */
	protected static string $type = "";

	/**
	 * @var array
	 */
	protected static array $log_data = [];

	/**
	 * @var string
	 */
	protected static string $log_raw_data = '';

	/**
	 * @var string
	 */
	protected static string $log_file_name = 'worldpay.log';

	/**
	 * @var int
	 */
	protected static int $app_debug = 0;

	/**
	 * @var string
	 */
	protected static string $app_mode = "";

	public const DELIMITER_LOG_VARIABLE = " | ";

	private static $instance;

	protected function __construct() {}

	/**
	 * @return Logger
	 */
	public static function getInstance(): self {
		if (!isset(self::$instance)) {
			self::$instance = new static();
		}

		return self::$instance;
	}

	/**
	 * @param  Config  $config
	 * @param  string  $payment_method
	 *
	 * @return Logger
	 */
	public static function config(Config $config, string $payment_method): self {
		self::$app_debug = (int)$config->get('payment_'.$payment_method.'_app_debug');
		self::$app_mode = $config->get('payment_'.$payment_method.'_app_mode');
		self::$oc_log = new Log(self::$log_file_name);

		return self::getInstance();
	}

	/**
	 * @return void
	 */
	public static function logPlatformVersion(): void {
		$data = self::getInstallationVersions();

		self::setDescription("Platforms versions")->debug($data);
	}

	/**
	 * @param string $log_description
	 *
	 * @return Logger
	 */
	public static function setDescription(string $log_description): self {
		self::$log_description = $log_description;

		return self::getInstance();
	}

	/**
	 * @param array|string $log_data
	 *
	 * @return Logger
	 */
	public static function debug(array|string $log_data): self {
		if (self::$app_debug == 0) {
			return self::getInstance();
		}

		$log_data = self::formatLog($log_data);

		return self::setLog(LogLevel::DEBUG, $log_data);
	}

	/**
	 * @param array|string $log_data
	 *
	 * @return Logger
	 */
	public static function alert(array|string $log_data): self {
		$log_data = self::formatLog($log_data);

		return self::setLog(LogLevel::ALERT, $log_data);
	}

	/**
	 * @param string       $type
	 * @param array|string $log_data
	 *
	 * @return Logger
	 */
	protected static function setLog(string $type, array|string $log_data): self {
		if (empty($type) || empty($log_data)) {
			return self::getInstance();
		}
		self::$type = $type;

		return self::setLogData($log_data)->send();
	}

	/**
	 * @param array|string $log_data
	 *
	 * @return Logger
	 */
	protected static function setLogData(array|string $log_data): self {
		if (is_string($log_data)) {
			self::$log_raw_data .= $log_data;
		}
		if (is_array($log_data)) {
			self::$log_data = array_merge(self::$log_data, $log_data);
		}
		if (\gettype($log_data) == "object") {
			self::$log_data = array_merge(self::$log_data, (array)$log_data);
		}

		return self::getInstance();
	}

	/**
	 * @param array   $log_data
	 * @param ?string $parent_key
	 *
	 * @return string
	 */
	protected static function formatLogDataArray(array $log_data, ?string $parent_key = null): string {
		$payload = [];
		foreach ($log_data as $key => $data) {
			if (is_object($data)) {
				$data = (array)$data;
			}
			if (is_array($data)) {
				$payload[] = self::formatLogDataArray($data, $key);
				continue;
			}
			$payload[] = self::formatLogRecord($data, $key, $parent_key);
		}

		return implode(self::DELIMITER_LOG_VARIABLE, $payload);
	}

	/**
	 * @param int|string  $data
	 * @param int|string  $key
	 * @param string|null $parent_key
	 *
	 * @return string
	 */
	public static function formatLogRecord(null|float|int|string $data, int|string $key, ?string $parent_key): string {
		if (null === $data) {
			$data = "NULL";
		}
		$value = ((is_numeric($data) || $data == "NULL") ? $data : '"' . (string)$data . '"');
		$result = (is_numeric($key)) ? $value : $key . "=" . $value;
		$result = (is_numeric($key) && $parent_key) ? $result = "=" . $result : $result;

		if ($parent_key) {
			$result = str_replace(
				" ",
				"",
				lcfirst(ucwords($parent_key))
			) . ucfirst($result);
		}

		return $result;
	}

	/**
	 * @return string
	 */
	protected static function formatLogDataRow(): string {
		$prepend_log_data = strtoupper(self::$type);

		if (!empty(self::$log_description)) {
			self::$log_data = array_merge(["detailMessage" => self::$log_description], self::$log_data);
		}

		if (!empty(self::$log_raw_data)) {
			self::$log_data = array_merge(self::$log_data, [self::$log_raw_data]);
		}

		return $prepend_log_data . self::DELIMITER_LOG_VARIABLE . self::formatLogDataArray(self::$log_data);
	}

	/**
	 * @param string $data
	 *
	 * @return bool
	 */
	protected static function validateJson(string $data): bool {
		json_decode($data, true);

		return json_last_error() === JSON_ERROR_NONE;
	}

	/**
	 * @return Logger
	 */
	protected static function send(): self {
		self::$oc_log->write(self::formatLogDataRow());

		self::clearStoredData();

		return self::getInstance();
	}

	/**
	 * @return void
	 */
	protected static function clearStoredData(): void {
		self::$type = "";
		self::$log_description = "";
		self::$log_data = [];
	}

	/**
	 * @return array
	 */
	protected static function getInstallationVersions(): array {
		$plugin_instal_file = DIR_EXTENSION . 'worldpay_ecommerce/install.json';
		$plugin_data = [];
		if (is_readable($plugin_instal_file)) {
			$plugin_data = file_get_contents(DIR_EXTENSION . 'worldpay_ecommerce/install.json');
			$plugin_data = json_decode($plugin_data, true);
		}

		return [
			"platform_version" => VERSION,
			"php_version"      => PHP_VERSION,
			"plugin_version"   => $plugin_data["version"] ?? ""
		];
	}

	/**
	 * @param array|string $log_data
	 *
	 * @return string[]
	 */
	public static function formatLog(array|string $log_data): array {
		if (is_array($log_data)) {
			$log_data = Helper::cleanArray($log_data);
		} else {
			$log_data = [$log_data];
		}

		return array_merge(["app_mode" => self::$app_mode], $log_data);
	}
}
