<?php

namespace Opencart\Extension\WorldpayEcommerce\System\Library;

require_once __DIR__ . '/vendor/worldpay/php-sdk/autoload.php';

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Exceptions\ApiClientException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\AmountHelper;

abstract class WorldpayEcommerce {

	/**
	 * @var array
	 */
	protected $order_data = [];
	protected $worldpay_service;

	/**
	 * @param WorldpayService $worldpay_service
	 * @param array           $order
	 */
	public function __construct(WorldpayService $worldpay_service, array $order = []) {
		$this->worldpay_service = $worldpay_service;
		$this->order_data = $order;
	}

	/**
	 * @param array $headers
	 *
	 * @return string
	 */
	protected function getWpCorrelationId(array $headers = []): string {
		$output = "";

		if (isset($headers["wp-correlationid"])) {
			$output =  $headers["wp-correlationid"];
		}

		if (isset($headers["WP-CorrelationId"])) {
			$output =  $headers["WP-CorrelationId"];
		}

		if (is_array($output)) {
			$output = array_pop($output);
		}

		return $output;
	}

	/**
	 * @return ApiResponse|null
	 * @throws ApiClientException
	 */
	abstract public function testApiCredentials(): ?ApiResponse;

	/**
	 * @param $order_id
	 * @param $refund_amount
	 * @param $refund_currency
	 * @param $transaction_reference
	 * @param $partial_refund_reference
	 * @param $is_partial_refund
	 * @param $link_data
	 *
	 * @return bool
	 * @throws InvalidArgumentException
	 * @throws AuthenticationException
	 * @throws ApiClientException
	 * @throws \Exception
	 */
	public function refund(
		$order_id,
		$refund_amount,
		$refund_currency,
		$transaction_reference,
		$partial_refund_reference,
		$is_partial_refund,
		$link_data = ''
	): bool {
		$api = $this->worldpay_service->initializeApi();

		$converted_amount = AmountHelper::decimalToExponentDelimiter($refund_amount);

		$api_call = $is_partial_refund
			? $api->partialRefund($converted_amount)->withCurrency($refund_currency)
			: $api->refund($converted_amount);

		$api_call = $api_call->withTransactionReference($transaction_reference)
	                         ->withPartialOperationReference($partial_refund_reference);

		if ($link_data) {
			$api_call = $api_call->withLinkData($link_data);
		}

		$api_response = $api_call->execute();

		$data_to_log = [
			"partial_refund_reference" => $partial_refund_reference,
			"order_id"                 => $order_id,
			"transaction_amount"       => $refund_amount,
			"transaction_reference"    => $transaction_reference,
			"api_request"              => $api_response->rawRequest,
			"api_response"             => $api_response->rawResponse,
			"wp-correlationid"         => $this->getWpCorrelationId($api_response->headers),
		];

		if ($api_response->statusCode !== 202) {
			Logger::setDescription("Refund failed")->alert($data_to_log);

			throw new \Exception('Something went wrong while requesting payment refund.');
		} else {
			Logger::setDescription("Refund success")->debug($data_to_log);
		}

		return true;
	}
}
