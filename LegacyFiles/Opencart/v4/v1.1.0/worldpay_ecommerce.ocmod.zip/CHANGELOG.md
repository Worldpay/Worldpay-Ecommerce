# Worldpay eCommerce for OpenCart change log

## [v1.1.0] (01/30/2025)
* Added Payments API support for credit card payments via Checkout SDK with 3DS authentication and FraudSight risk assessment.

## [v1.0.1] (07/19/2024)
* Added compatibility checks.
* Added iframe support.
* Added regex validation for merchant narrative.
* Added Description setting.
* Removed GBP checkout restriction.

## [v1.0.0] (03/01/2024)
* Initial release.
