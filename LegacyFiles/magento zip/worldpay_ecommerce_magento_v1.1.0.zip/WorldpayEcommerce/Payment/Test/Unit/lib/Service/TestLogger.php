<?php

namespace WorldpayEcommerce\Payment\Test\Unit\lib\Service;

use WorldpayEcommerce\Payment\lib\Service\Logger as BaseLogger;

class TestLogger extends BaseLogger
{
    private static $description = '';
    private static $logData = [];

    /**
     * Override the formatLogRecord method to handle null values.
     *
     * @param  int|string|null  $data
     * @param  int|string  $key
     * @param  string|null $parent_key
     *
     * @return string
     */
    public static function formatLogRecord($data, $key, $parent_key): string
    {
        if ($data === null) {
            $data = "NULL";
        }
        $value  = ((is_numeric($data) || $data === "NULL") ? $data : '"' . (string)$data . '"');
        $result = (is_numeric($key)) ? $value : $key . "=" . $value;
        $result = (is_numeric($key) && $parent_key) ? "=" . $result : $result;

        if ($parent_key) {
            $result = str_replace(" ", "", lcfirst(ucwords($parent_key))) . ucfirst($result);
        }

        return $result;
    }

    public static function setDescription(string $description): self
    {
        self::$description = $description;
        return new self();
    }

    public static function alert($logData): self
    {
        self::$logData = $logData;

        return new self();
    }

    public static function getDescription(): string
    {
        return self::$description;
    }

    public static function getLogData(): array
    {
        return self::$logData;
    }
}
