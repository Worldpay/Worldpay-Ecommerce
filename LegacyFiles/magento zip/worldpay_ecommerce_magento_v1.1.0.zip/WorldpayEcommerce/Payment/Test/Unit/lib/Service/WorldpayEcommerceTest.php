<?php

namespace WorldpayEcommerce\Payment\Test\Unit\lib\Service;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Builders\HostedPaymentPages\HostedPaymentPagesBuilder;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\Utils\Helper;
use Worldpay\Api\ValueObjects\ResultURLs;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

class WorldpayEcommerceTest extends TestCase
{
    protected $worldpayEcommerce;
    protected $worldpayServiceMock;
    protected $accessWorldpayConfigProviderMock;
    protected $apiResponseMock;
    protected $hppBuilderMock;
    protected $amountHelperMock;
    protected $helper;
    protected $apiMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->worldpayServiceMock = $this->createMock(WorldpayService::class);
        $this->accessWorldpayConfigProviderMock = $this->createMock(AccessWorldpayConfigProvider::class);
        $this->apiResponseMock = $this->createMock(ApiResponse::class);
        $this->hppBuilderMock = $this->createMock(HostedPaymentPagesBuilder::class);
        $this->amountHelperMock = $this->createMock(AmountHelper::class);

        $this->helper = new Helper();

        $this->worldpayEcommerce = new WorldpayEcommerce(
            $this->worldpayServiceMock,
            []
        );
    }

    public function testTestApiCredentials()
    {
        $transactionReference = 'test_transaction_test';

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('HPPSetup')
                      ->with(1)
                      ->willReturn($this->hppBuilderMock);

        $this->hppBuilderMock->expects($this->once())
                             ->method('withCurrency')
                             ->with('GBP')
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withTransactionReference')
                             ->with($transactionReference)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('execute')
                             ->willReturn($this->apiResponseMock);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);

        $response = $this->worldpayEcommerce->testApiCredentials(
            $this->accessWorldpayConfigProviderMock,
            'test'
        );

        $this->assertInstanceOf(ApiResponse::class, $response);
    }

    public function testTestApiCredentialsThrowsException()
    {
        $transactionReference = 'test_transaction';

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('HPPSetup')
                      ->with(1)
                      ->willThrowException(new AuthenticationException('Invalid API credentials'));

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);

        $this->expectException(AuthenticationException::class);
        $this->expectExceptionMessage('Invalid API credentials');

        $this->worldpayEcommerce->testApiCredentials(
            $this->accessWorldpayConfigProviderMock,
            'test'
        );
    }

    public function testRequestHppUrl()
    {
        $transactionReference = 'test_transaction';
        $successReturnUrl = 'http://success.com';
        $failureReturnUrl = 'http://failure.com';
        $cancelReturnUrl = 'http://cancel.com';

        $orderMock = $this->createMock( Order::class);
        $orderMock->amount = '10000';

        $resultUrlsMock = $this->createMock( ResultURLs::class);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('getOrderData')
                                  ->with($this->worldpayEcommerce->orderData)
                                  ->willReturn($orderMock);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('getResultUrls')
                                  ->with($successReturnUrl, $failureReturnUrl, $cancelReturnUrl)
                                  ->willReturn($resultUrlsMock);

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('HPPSetup')
                      ->with($orderMock->amount)
                      ->willReturn($this->hppBuilderMock);

        $this->hppBuilderMock->expects($this->once())
                             ->method('withTransactionReference')
                             ->with($transactionReference)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withOptionalOrder')
                             ->with($orderMock)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withDescription')
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withResultURLs')
                             ->with($resultUrlsMock)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('execute')
                             ->willReturn($this->apiResponseMock);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);
        $this->worldpayServiceMock->expects($this->once())
                                  ->method('getMerchantDescription')
                                  ->willReturn('description');

        $response = $this->worldpayEcommerce->requestHppUrl(
            $transactionReference,
            $successReturnUrl,
            $failureReturnUrl,
            $cancelReturnUrl
        );

        $this->assertInstanceOf(ApiResponse::class, $response);
    }

    public function testRequestHppUrlWithoutResultUrls()
    {
        $transactionReference = 'test_transaction';
        $successReturnUrl = 'http://success.com';
        $failureReturnUrl = 'http://failure.com';
        $cancelReturnUrl = '';

        $orderMock = $this->createMock( Order::class);
        $orderMock->amount = '10000';

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('getOrderData')
                                  ->with($this->worldpayEcommerce->orderData)
                                  ->willReturn($orderMock);

        $this->worldpayServiceMock->expects($this->never())
                                  ->method('getResultUrls');

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('HPPSetup')
                      ->with($orderMock->amount)
                      ->willReturn($this->hppBuilderMock);

        $this->hppBuilderMock->expects($this->once())
                             ->method('withTransactionReference')
                             ->with($transactionReference)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withOptionalOrder')
                             ->with($orderMock)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withDescription')
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->never())
                             ->method('withResultURLs');
        $this->hppBuilderMock->expects($this->once())
                             ->method('execute')
                             ->willReturn($this->apiResponseMock);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);
        $this->worldpayServiceMock->expects($this->once())
                                  ->method('getMerchantDescription')
                                  ->willReturn('description');

        $response = $this->worldpayEcommerce->requestHppUrl(
            $transactionReference,
            $successReturnUrl,
            $failureReturnUrl,
            $cancelReturnUrl
        );

        $this->assertInstanceOf(ApiResponse::class, $response);
    }

    public function testRefund()
    {
        $transactionReference = 'test_transaction';
        $refundAmount = 100.00;
        $currencyCode = 'GBP';
        $storeLocale = 'en_GB';
        $partialRefundReference = 'partial_refund';

        $expectedAmount = AmountHelper::decimalToExponentDelimiter($refundAmount, $currencyCode, $storeLocale);

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('refund')
                      ->with($expectedAmount)
                      ->willReturn($this->hppBuilderMock);

        $this->hppBuilderMock->expects($this->once())
                             ->method('withCurrency')
                             ->with($currencyCode)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withTransactionReference')
                             ->with($transactionReference)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('withPartialRefundReference')
                             ->with($partialRefundReference)
                             ->willReturn($this->hppBuilderMock);
        $this->hppBuilderMock->expects($this->once())
                             ->method('execute')
                             ->willReturn($this->apiResponseMock);

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);

        $response = $this->worldpayEcommerce->refund(
            $transactionReference,
            $refundAmount,
            $currencyCode,
            $storeLocale,
            $partialRefundReference
        );

        $this->assertInstanceOf(ApiResponse::class, $response);
    }

    public function testRefundThrowsException()
    {
        $transactionReference = 'test_transaction';
        $refundAmount = 100.00;
        $currencyCode = 'GBP';
        $storeLocale = 'en_GB';
        $partialRefundReference = 'partial_refund';

        $expectedAmount = AmountHelper::decimalToExponentDelimiter($refundAmount, $currencyCode, $storeLocale);

        $this->apiMock = $this->createMock(AccessWorldpay::class);
        $this->apiMock->expects($this->once())
                      ->method('refund')
                      ->with($expectedAmount)
                      ->willThrowException(new ApiException('Refund failed'));

        $this->worldpayServiceMock->expects($this->once())
                                  ->method('initializeApi')
                                  ->willReturn($this->apiMock);

        $this->expectException(ApiException::class);
        $this->expectExceptionMessage('Refund failed');

        $this->worldpayEcommerce->refund(
            $transactionReference,
            $refundAmount,
            $currencyCode,
            $storeLocale,
            $partialRefundReference
        );
    }
}
