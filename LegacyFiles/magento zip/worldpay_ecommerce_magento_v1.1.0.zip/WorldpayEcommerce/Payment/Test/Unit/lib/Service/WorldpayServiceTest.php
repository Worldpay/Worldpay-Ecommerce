<?php

namespace WorldpayEcommerce\Payment\Test\Unit\lib\Service;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;
use PHPUnit\Framework\ExpectationFailedException;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Providers\ProxyConfigProvider;
use Worldpay\Api\Utils\AmountHelper;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ShippingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Entities\Order;
use Worldpay\Api\Enums\Environment;
use PHPUnit\Framework\MockObject\MockObject;

class WorldpayServiceTest extends TestCase
{
    /** @var WorldpayService */
    private $worldpayService;

    /** @var Config|MockObject */
    private $configMock;

    /** @var ScopeConfigInterface|MockObject */
    private $scopeConfigMock;

    /**
     * @var RequestInterface|MockObject
     */
    private $requestMock;

    protected function setUp(): void
    {
        parent::setUp();

        $this->configMock = $this->createMock(Config::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->worldpayServiceMock = $this->createMock(WorldpayService::class);
        $this->requestMock = $this->createMock(RequestInterface::class);

        $this->worldpayService = new WorldpayService(
            $this->configMock,
            $this->scopeConfigMock,
            $this->requestMock
        );
    }

    public function testInitializeApiWithConfiguredProvider()
    {
        $configProviderMock = $this->createMock(AccessWorldpayConfigProvider::class);
        $this->worldpayService->apiConfigProvider = $configProviderMock;

        $accessWorldpayMock = $this->createMock(AccessWorldpay::class);
        $configProviderMock->expects($this->once())
                           ->method('getConfig')
                           ->willReturn($accessWorldpayMock);

        $this->assertSame(
            $accessWorldpayMock,
            $this->worldpayService->initializeApi()
        );
    }

    public function testInitializeApiWithDefaultProvider()
    {
        $configProviderMock = $this->createMock(AccessWorldpayConfigProvider::class);
        $this->worldpayService->apiConfigProvider = $configProviderMock;
        $result = $this->worldpayService->initializeApi();
        $this->assertInstanceOf(AccessWorldpay::class, $result);
    }

    public function testConfigureApi()
    {
        $this->configMock->method('getValue')
                         ->will($this->returnValueMap([
                             ['app_mode', 'live'],
                             ['api_live_username', 'live_username'],
                             ['api_live_password', 'live_password'],
                             ['merchant_entity', 'merchant_entity'],
                             ['merchant_narrative', 'merchant_narrative']
                         ]));

        $configProvider = $this->worldpayService->configureApi();

        $this->assertInstanceOf(AccessWorldpayConfigProvider::class, $configProvider);
        $this->assertEquals('live_username', $configProvider->username);
        $this->assertEquals('live_password', $configProvider->password);
        $this->assertEquals('merchant_entity', $configProvider->merchantEntity);
        $this->assertEquals('merchant_narrative', $configProvider->merchantNarrative);
    }

    public function testGetOrderAddress()
    {
        $orderData = [
            'billing' => ['street' => '123 Main St', 'postcode' => '12345', 'city' => 'City', 'country' => 'Country'],
            'shipping' => ['street' => '456 Another St', 'postcode' => '67890', 'city' => 'Another City', 'country' => 'Another Country']
        ];

        $billingAddress = WorldpayService::getOrderAddress($orderData, 'billing');
        $shippingAddress = WorldpayService::getOrderAddress($orderData, 'shipping');

        $this->assertInstanceOf(BillingAddress::class, $billingAddress);
        $this->assertInstanceOf(ShippingAddress::class, $shippingAddress);
        $this->assertEquals('123 Main St', $billingAddress->address1);
        $this->assertEquals('456 Another St', $shippingAddress->address1);
    }

    public function testGetOrderCustomer()
    {
        $orderData = [
            'customer' => ['firstname' => 'John', 'lastname' => 'Doe', 'email' => 'john.doe@example.com', 'telephone' => '1234567890']
        ];

        $customer = WorldpayService::getOrderCustomer($orderData);

        $this->assertInstanceOf(Customer::class, $customer);
        $this->assertEquals('John', $customer->firstName);
        $this->assertEquals('Doe', $customer->lastName);
    }

    public function testGetOrderData()
    {
        $orderData = [
            'id' => '123',
            'billing' => ['street' => '123 Main St', 'postcode' => '12345', 'city' => 'City', 'country' => 'Country'],
            'shipping' => ['street' => '456 Another St', 'postcode' => '67890', 'city' => 'Another City', 'country' => 'Another Country'],
            'customer' => ['firstname' => 'John', 'lastname' => 'Doe', 'email' => 'john.doe@example.com', 'telephone' => '1234567890'],
            'currency_code' => 'USD',
            'total' => 100.00,
            'locale' => 'en_US'
        ];

        $expectedAmount = AmountHelper::decimalToExponentDelimiter($orderData['total'], $orderData['currency_code'], $orderData['locale']);

        $order = $this->worldpayService->getOrderData($orderData);

        $this->assertInstanceOf(Order::class, $order);
        $this->assertEquals('123', $order->id);
        $this->assertEquals('USD', $order->currency);
        $this->assertEquals($expectedAmount, $order->amount);
    }

    public function testGetResultUrls()
    {
        $resultUrls = $this->worldpayService->getResultUrls(
            'success_url',
            'failure_url',
            'cancel_url'
        );

        $this->assertInstanceOf(ResultURLs::class, $resultUrls);
        $this->assertEquals('success_url', $resultUrls->successURL);
        $this->assertEquals('failure_url', $resultUrls->errorURL);
        $this->assertEquals('failure_url', $resultUrls->failureURL);
        $this->assertEquals('failure_url', $resultUrls->pendingURL);
        $this->assertEquals('failure_url', $resultUrls->expiryURL);
        $this->assertEquals('cancel_url', $resultUrls->cancelURL);
    }

    public function testGetTransactionReferenceByOrderId()
    {
        $orderId = 12345;
        $transactionReference = WorldpayService::getTransactionReferenceByOrderId($orderId);

        $this->assertMatchesRegularExpression('/^\w{12}_12345$/', $transactionReference);
    }

    public function testConfigureProxyWithProxyEnabled()
    {
        $this->scopeConfigMock->method('getValue')
                              ->will($this->returnValueMap([
                                  ['web/proxy/use_proxy', ScopeInterface::SCOPE_STORE, true],
                                  ['web/proxy/proxy_host', ScopeInterface::SCOPE_STORE, 'proxy_host'],
                                  ['web/proxy/proxy_port', ScopeInterface::SCOPE_STORE, 'proxy_port']
                              ]));

        $proxyConfigProviderMock = $this->createMock(ProxyConfigProvider::class);
        ProxyConfigProvider::method('instance')->willReturn($proxyConfigProviderMock);

        $proxyConfigProviderMock->expects($this->once())->method('setHost')->with('proxy_host');
        $proxyConfigProviderMock->expects($this->once())->method('setPort')->with('proxy_port');

        $this->worldpayService->configureProxy();
    }

    /**
     * @dataProvider apiEnvironmentProvider
     */
    public function testGetApiEnvironment($configSetting, $expectedVal)
    {
        $this->configMock->method('getValue')
                         ->with($this->stringContains('app_mode'))
                         ->willReturn($configSetting);

        $this->assertEquals($expectedVal, $this->worldpayService->getApiEnvironment());
    }

    public static function apiEnvironmentProvider()
    {
        return [
            ['live', Environment::LIVE_MODE],
            ['try', Environment::TRY_MODE],
            ['anyOtherValue', Environment::TRY_MODE],
        ];
    }

    /**
     * @dataProvider apiUsernameProvider
     */
    public function testGetApiUsername($envConfigSetting, $expectedVal)
    {
        try {
            $this->configMock->method('getValue')->with($this->equalTo('app_mode'))->willReturn($envConfigSetting);
            $this->worldpayService->getApiUsername();
        } catch (ExpectationFailedException $e) {
            $this->assertStringContainsString("Config::getValue('" . $expectedVal . "'", $e->getMessage());
        }
    }

    public static function apiUsernameProvider()
    {
        return [
            ['live', 'api_live_username'],
            ['try', 'api_try_username'],
            ['anyOtherValue', 'api_try_username'],
        ];
    }

    /**
     * @dataProvider apiPasswordProvider
     */
    public function testGetApiPassword($envConfigSetting, $expectedVal)
    {
        try {
            $this->configMock->method('getValue')->with($this->equalTo('app_mode'))->willReturn($envConfigSetting);
            $this->worldpayService->getApiPassword();
        } catch (ExpectationFailedException $e) {
            $this->assertStringContainsString("Config::getValue('" . $expectedVal . "'", $e->getMessage());
        }
    }

    public static function apiPasswordProvider()
    {
        return [
            ['live', 'api_live_password'],
            ['try', 'api_try_password'],
            ['anyOtherValue', 'api_try_password'],
        ];
    }

    public function testGetMerchantEntity()
    {
        $this->configMock->method('getValue')
                         ->with($this->equalTo('merchant_entity'))
                         ->willReturn('merchant_entity_value');

        $this->assertEquals('merchant_entity_value', $this->worldpayService->getMerchantEntity());
    }

    public function testGetMerchantNarrative()
    {
        $this->configMock->method('getValue')
                         ->with($this->equalTo('merchant_narrative'))
                         ->willReturn('merchant_narrative_value');

        $this->assertEquals('merchant_narrative_value', $this->worldpayService->getMerchantNarrative());
    }

    public function testGetMerchantDescription()
    {
        $this->configMock->method('getValue')
                         ->with($this->equalTo('description'))
                         ->willReturn('description_value');

        $this->assertEquals('description_value', $this->worldpayService->getMerchantDescription());
    }

    public function testGetWpCorrelationIdFromHeaders()
    {
        $headers = [
            'wp-correlationid' => 'correlation_id',
            'WP-CorrelationId' => 'another_correlation_id'
        ];

        $this->assertEquals('another_correlation_id', WorldpayService::getWpCorrelationIdFromHeaders($headers));
    }

    public function testIncludeSdk()
    {
        $this->expectOutputString('');
        WorldpayService::includeSdk();
    }

    public function testGetMerchantCheckoutCardBrands()
    {
        $this->configMock->method('getValue')
                         ->with($this->equalTo('card_brands'))
                         ->willReturn('visa,mastercard,amex');

        $this->assertEquals('visa,mastercard,amex', $this->worldpayService->getMerchantCheckoutCardBrands());
    }

    /**
     * @dataProvider apiCheckoutIdProvider
     */
    public function testGetMerchantCheckoutId($envConfigSetting, $expectedVal)
    {
        try {
            $this->configMock->method('getValue')->with($this->equalTo('app_mode'))->willReturn($envConfigSetting);
            $this->worldpayService->getMerchantCheckoutId();
        } catch (ExpectationFailedException $e) {
            $this->assertStringContainsString("Config::getValue('" . $expectedVal . "'", $e->getMessage());
        }
    }

    public static function apiCheckoutIdProvider()
    {
        return [
            ['live', 'api_live_checkout_id'],
            ['try', 'api_try_checkout_id'],
        ];
    }
}
