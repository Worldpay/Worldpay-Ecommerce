<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Data\Form\Element;

use Magento\Framework\Data\Form\Element\Factory;
use Magento\Framework\Data\Form\Element\CollectionFactory;
use Magento\Framework\Escaper;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Data\Form\Element\PartialObscure;

class PartialObscureTest extends TestCase
{
    /** @var PartialObscure */
    private $partialObscure;

    protected function setUp(): void
    {
        $this->partialObscure = new PartialObscure(
            $this->createMock(Factory::class),
            $this->createMock(CollectionFactory::class),
            new Escaper(),
            ['name' => 'test']
        );
    }

    /**
     * @dataProvider getEscapedValueProvider
     */
    public function testGetEscapedValue($value, $expectedValue)
    {
        $this->partialObscure->setValue($value);
        $this->assertSame($expectedValue, $this->partialObscure->getEscapedValue());
    }

    public static function getEscapedValueProvider()
    {
        return [
            ['1234567890123456', '************3456'],
            ['', ''],
            ['Abc123!@#', '*****3!@#'],
            ['   1234567890123456   ', '******************6   '],
            ['1234   567890123456', '***************3456'],
            ['AbCdEfGhIjKlMnOp', '************MnOp'],
            ['abcdefghijklmnopqrstuvwxyzABCDEF', '****************************CDEF'],
        ];
    }
}
