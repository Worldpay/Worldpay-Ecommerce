<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Helper;

use PHPUnit\Framework\TestCase;
use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;

class ConfigButtonHelperTest extends TestCase
{
    private $helper;

    private $elementMock;

    protected function setUp(): void
    {
        $this->helper = new ConfigButtonHelper();
        // Mock the AbstractElement
        $this->elementMock = $this->createMock(AbstractElement::class);
    }

    public function testGetHtmlIdForFieldId()
    {
        $this->elementMock
            ->method('getData')
            ->willReturn('payment_worldpay_ecommerce');

        $this->assertEquals('payment_worldpay_ecommerce_app_mode', $this->helper->getHtmlIdForFieldId($this->elementMock, 'app_mode'));
    }

    public function testAppendButtonHtml()
    {
        // Configure the mock to return a valid HTML ID
        $this->elementMock->method('getHtmlId')->willReturn('test_input');

        // Configure the mock to return element HTML
        $this->elementMock->method('getElementHtml')->willReturn('<input type="text" id="test_input" />');

        // Test callback for generating button HTML
        $getButtonHtml = function ($element) {
            return '<button id="' . $element->getHtmlId() . '_button">Click Me</button>';
        };

        $result = $this->helper->appendButtonHtml($this->elementMock, $getButtonHtml);

        // Assert the combined HTML
        $this->assertStringContainsString('<input type="text" id="test_input" />', $result);
        $this->assertStringContainsString('<button id="test_input_button">Click Me</button>', $result);
    }
}
