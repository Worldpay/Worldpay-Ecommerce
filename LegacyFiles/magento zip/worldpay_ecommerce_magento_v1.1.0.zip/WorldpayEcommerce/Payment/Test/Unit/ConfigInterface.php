<?php

namespace WorldpayEcommerce\Payment\Test\Unit;

interface ConfigInterface
{
    public const API_USERNAME = '';
    public const API_TRY_PASSWORD = '';
    public const API_LIVE_PASSWORD = '';
    public const MERCHANT_ENTITY = '';
}
