<?php

namespace WorldpayEcommerce\Payment\Test\Unit;

use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Data\Form\Element\Factory;
use Magento\Framework\Data\Form\Element\CollectionFactory;
use Magento\Framework\Escaper;
use Magento\Framework\View\Helper\SecureHtmlRenderer;
use Magento\Framework\Math\Random;

class TestElement extends AbstractElement
{
    private $htmlOutput = '';

    public function __construct(
        Factory $factoryElement,
        CollectionFactory $factoryCollection,
        Escaper $escaper,
        $data = [],
        ?SecureHtmlRenderer $secureRenderer = null,
        ?Random $random = null
    ) {
        parent::__construct($factoryElement, $factoryCollection, $escaper, $data, $secureRenderer, $random);
    }

    public function setHtmlOutput(string $htmlOutput)
    {
        $this->htmlOutput = $htmlOutput;
    }

    public function getElementHtml()
    {
        return $this->htmlOutput;
    }

    public function setValue($value)
    {
        $this->setData('value', $value);
    }

    public function setData($key, $value = null)
    {
        return parent::setData($key, $value);
    }

    public function getHtmlId()
    {
        return $this->getData('html_id');
    }

    public function getForm()
    {
        return $this->getData('form');
    }

    public function getFactoryElement()
    {
        return $this->_factoryElement;
    }

    public function getFactoryCollection()
    {
        return $this->_factoryCollection;
    }

    public function getEscaper()
    {
        return $this->_escaper;
    }
}
