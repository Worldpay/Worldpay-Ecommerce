<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Controller\Adminhtml\Payment;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\Request\Http;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Phrase;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Controller\Adminhtml\Payment\TestApiCredentialsRequest;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use Worldpay\Api\ApiResponse;
use WorldpayEcommerce\Payment\Test\Unit\lib\Service\TestLogger;
use WorldpayEcommerce\Payment\Test\Unit\ConfigInterface;

class TestApiCredentialsRequestTest extends TestCase implements ConfigInterface
{
    protected $contextMock;
    protected $resultJsonFactoryMock;
    protected $worldpayEcommerceMock;
    protected $configMock;
    protected $scopeConfigMock;
    protected $dirMock;
    protected $requestMock;
    protected $controller;

    protected function setUp(): void
    {
        $this->requestMock = $this->createMock(Http::class);
        $this->contextMock = $this->getMockBuilder(Context::class)
                                  ->disableOriginalConstructor()
                                  ->onlyMethods(['getRequest'])
                                  ->getMock();
        $this->contextMock->method('getRequest')->willReturn($this->requestMock);

        $this->resultJsonFactoryMock = $this->createMock(JsonFactory::class);
        $this->worldpayEcommerceMock = $this->createMock(WorldpayEcommerce::class);
        $this->configMock = $this->createMock(Config::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->dirMock = $this->createMock(DirectoryList::class);

        $this->controller = new TestApiCredentialsRequest(
            $this->contextMock,
            $this->resultJsonFactoryMock,
            $this->worldpayEcommerceMock,
            $this->configMock,
            $this->scopeConfigMock,
            $this->dirMock
        );

        TestLogger::config($this->scopeConfigMock, $this->dirMock);
    }

    private function mockScopeConfig()
    {
        $this->scopeConfigMock->method('getValue')
                              ->willReturnMap([
                                  ['payment/access_worldpay_hpp/debug', null, 1],
                                  ['payment/access_worldpay_hpp/app_mode', null, 'try'],
                                  ['payment/access_worldpay_hpp/api_try_password', null, self::API_TRY_PASSWORD],
                                  ['payment/access_worldpay_hpp/api_live_password', null, self::API_LIVE_PASSWORD],
                                  ['payment/access_worldpay_hpp/merchant_entity', null, self::MERCHANT_ENTITY]
                              ]);
    }

    public function testExecuteSuccess()
    {
        $postData = [
            'app_mode' => 'try',
            'api_try_username' => self::API_USERNAME,
            'api_try_password' => self::API_TRY_PASSWORD,
            'merchant_entity' => self::MERCHANT_ENTITY
        ];

        $this->requestMock->method('getPostValue')->willReturn($postData);

        $apiResponse = $this->createMock(ApiResponse::class);
        $apiResponse->headers = ['wp-correlationid' => '123'];
        $apiResponse->rawRequest = 'request';
        $apiResponse->rawResponse = 'response';
        $apiResponse->curlError = '';
        $apiResponse->statusCode = 200;
        $apiResponse->method('isSuccessful')->willReturn(true);
        $apiResponse->method('hasServerError')->willReturn(false);
        $apiResponse->method('hasClientError')->willReturn(false);

        $this->worldpayEcommerceMock->method('testApiCredentials')
                                    ->willReturn($apiResponse);

        $resultJson = $this->createMock(Json::class);
        $this->resultJsonFactoryMock->method('create')->willReturn($resultJson);

        $setDataCalls = [];
        $resultJson->method('setData')
                   ->will($this->returnCallback(function ($data) use (&$setDataCalls, $resultJson) {
                       $setDataCalls[] = $data;
                       return $resultJson;
                   }));

        $this->mockScopeConfig();

        $result = $this->controller->execute();

        $this->assertInstanceOf(Json::class, $result);
        $this->assertCount(1, $setDataCalls);
        $this->assertTrue($setDataCalls[0]['success']);
        $this->assertInstanceOf(Phrase::class, $setDataCalls[0]['message']);

        $expectedMessage = 'Worldpay Payments connected successfully to the payment gateway with your provided credentials.';
        $actualMessage = $setDataCalls[0]['message']->render();

        $normalizedExpectedMessage = preg_replace('/\s+/', ' ', trim($expectedMessage));
        $normalizedActualMessage = preg_replace('/\s+/', ' ', trim($actualMessage));

        $this->assertEquals($normalizedExpectedMessage, $normalizedActualMessage);
    }

    public function testExecuteServerError()
    {
        $postData = [
            'app_mode' => 'try',
            'api_try_username' => self::API_USERNAME,
            'api_try_password' => 'password',
            'merchant_entity' => 'merchant'
        ];

        $this->requestMock->method('getPostValue')->willReturn($postData);

        $apiResponse = $this->createMock(ApiResponse::class);
        $apiResponse->headers = ['wp-correlationid' => '123'];
        $apiResponse->rawRequest = 'request';
        $apiResponse->rawResponse = 'response';
        $apiResponse->statusCode = 500;
        $apiResponse->curlError = 'Server error';
        $apiResponse->method('isSuccessful')->willReturn(false);
        $apiResponse->method('hasServerError')->willReturn(true);
        $apiResponse->method('hasClientError')->willReturn(false);

        $this->worldpayEcommerceMock->method('testApiCredentials')
                                    ->willReturn($apiResponse);

        $resultJson = $this->createMock(Json::class);
        $this->resultJsonFactoryMock->method('create')->willReturn($resultJson);

        $dataToLog = [
            "app_mode" => "try",
            "correlationId" => "123",
            "api request" => "request",
            "api response" => "response",
            "api status code" => 500,
            "api is successful" => 0,
            "api has server error" => 1,
            "api has client error" => 0,
            "api curl error" => "Server error",
        ];

        $resultJson->expects($this->once())
                   ->method('setData')
                   ->with($this->callback(function ($data) {
                       return $data['success'] === false && $data['message'] == 'Worldpay Payments could not connect to Access Worldpay API. Please try again later.';
                   }))
                   ->willReturnSelf();

        $this->mockScopeConfig();

        try {
            TestLogger::setDescription("Test Api Credentials Request - failed")->alert($dataToLog);
            $this->controller->execute();
            $this->fail('Expected Exception not thrown');
        } catch (\Exception $e) {
            $this->assertEquals('Worldpay Payments could not connect to Access Worldpay API. Please try again later.', $e->getMessage());
        }

        $this->assertInstanceOf(Json::class, $resultJson);
    }

    public function testExecuteValidationError()
    {
        $postData = [
            'app_mode' => 'try',
            'api_try_username' => '',
            'api_try_password' => '',
            'merchant_entity' => ''
        ];

        $this->requestMock->method('getPostValue')->willReturn($postData);

        $resultJson = $this->createMock(Json::class);
        $this->resultJsonFactoryMock->method('create')->willReturn($resultJson);

        $resultJson->expects($this->once())
                   ->method('setData')
                   ->with([
                       'success' => false,
                       'message' => 'Missing required fields: Username, Password, Merchant Entity'
                   ])
                   ->willReturnSelf();

        $this->mockScopeConfig();

        $result = $this->controller->execute();

        $this->assertInstanceOf(Json::class, $result);
    }

    public function testGetCredentialsWithMaskedPassword()
    {
        $postDataTry = [
            'app_mode' => 'try',
            'api_try_username' => self::API_USERNAME,
            'api_try_password' => '******',
            'merchant_entity' => self::MERCHANT_ENTITY
        ];

        $this->scopeConfigMock->method('getValue')->willReturnMap([
            ['payment/access_worldpay_hpp/api_try_password', null, self::API_TRY_PASSWORD],
            ['payment/access_worldpay_hpp/api_live_password', null, self::API_LIVE_PASSWORD],
        ]);

        $this->requestMock->method('getPostValue')->willReturn($postDataTry);

        $resultTry = $this->invokeGetCredentials($postDataTry);

        $this->assertEquals(self::API_TRY_PASSWORD, $resultTry['apiPassword'], 'Failed asserting that the API try password matches the expected value.');

        $postDataLive = [
            'app_mode' => 'live',
            'api_live_username' => self::API_USERNAME,
            'api_live_password' => '******',
            'merchant_entity' => self::MERCHANT_ENTITY
        ];

        $this->requestMock->method('getPostValue')->willReturn($postDataLive);

        $resultLive = $this->invokeGetCredentials($postDataLive);

        $this->assertEquals(self::API_LIVE_PASSWORD, $resultLive['apiPassword'], 'Failed asserting that the API live password matches the expected value.');
    }

    public function testGetCredentialsWithMaskedMerchantEntity()
    {
        $postData = [
            'app_mode' => 'try',
            'api_try_username' => self::API_USERNAME,
            'api_try_password' => self::API_TRY_PASSWORD,
            'merchant_entity' => '******7346'
        ];

        $this->requestMock->method('getPostValue')->willReturn($postData);

        $this->scopeConfigMock->method('getValue')->willReturnMap([
            ['payment/access_worldpay_hpp/merchant_entity', null, self::MERCHANT_ENTITY],
        ]);

        $result = $this->invokeGetCredentials($postData);

        $this->assertEquals(self::MERCHANT_ENTITY, $result['merchantEntity'], 'Failed asserting that the Merchant Entity matches the expected value.');
    }

    private function invokeGetCredentials($postData)
    {
        // Use reflection to access the private method 'getCredentials'
        $reflection = new \ReflectionClass($this->controller);
        $method = $reflection->getMethod('getCredentials');
        $method->setAccessible(true);

        // Call the method with $postData
        return $method->invokeArgs($this->controller, [$postData]);
    }
}
