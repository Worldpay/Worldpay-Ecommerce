<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Controller\Checkout\Onepage;

use Magento\Checkout\Model\Type\Onepage;
use Magento\Checkout\Model\Type\Onepage\Interceptor;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\Result\RawFactory;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Registry;
use Magento\Framework\Translate\InlineInterface;
use Magento\Framework\View\LayoutFactory;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\View\Result\LayoutFactory as LayoutResultFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Session;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Controller\Checkout\Onepage\Success;
use WorldpayEcommerce\Payment\Gateway\Config\Config as PaymentMethodConfig;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class SuccessTest extends TestCase
{
    /** @var Success */
    private $controller;

    /** @var MockObject|OrderRepositoryInterface */
    private $orderRepositoryMock;

    /** @var MockObject|Context */
    private $contextMock;

    /** @var MockObject|Session */
    private $customerSessionMock;

    /** @var MockObject|CustomerRepositoryInterface */
    private $customerRepositoryMock;

    /** @var MockObject|AccountManagementInterface */
    private $accountManagementMock;

    /** @var MockObject|Registry */
    private $coreRegistryMock;

    /** @var MockObject|InlineInterface */
    private $translateInlineMock;

    /** @var MockObject|Validator */
    private $formKeyValidatorMock;

    /** @var MockObject|ScopeConfigInterface */
    private $scopeConfigMock;

    /** @var MockObject|LayoutFactory */
    private $layoutFactoryMock;

    /** @var MockObject|CartRepositoryInterface */
    private $quoteRepositoryMock;

    /** @var MockObject|PageFactory */
    private $resultPageFactoryMock;

    /** @var MockObject|LayoutResultFactory */
    private $resultLayoutFactoryMock;

    /** @var MockObject|RawFactory */
    private $resultRawFactoryMock;

    /** @var MockObject|JsonFactory */
    private $resultJsonFactoryMock;

    /** @var MockObject|DirectoryList */
    private $dirMock;

    /** @var MockObject|RedirectFactory */
    private $resultRedirectFactoryMock;

    /** @var MockObject|Onepage */
    private $onepageMock;

    protected function setUp(): void
    {
        $this->orderRepositoryMock = $this->createMock(OrderRepositoryInterface::class);
        $this->contextMock = $this->createMock(Context::class);
        $this->customerSessionMock = $this->createMock(Session::class);
        $this->customerRepositoryMock = $this->createMock(CustomerRepositoryInterface::class);
        $this->accountManagementMock = $this->createMock(AccountManagementInterface::class);
        $this->coreRegistryMock = $this->createMock(Registry::class);
        $this->translateInlineMock = $this->createMock(InlineInterface::class);
        $this->formKeyValidatorMock = $this->createMock(Validator::class);
        $this->scopeConfigMock = $this->createMock( ScopeConfigInterface::class);
        $this->layoutFactoryMock = $this->createMock(LayoutFactory::class);
        $this->quoteRepositoryMock = $this->createMock(CartRepositoryInterface::class);
        $this->resultPageFactoryMock = $this->createMock(PageFactory::class);
        $this->resultLayoutFactoryMock = $this->createMock(LayoutResultFactory::class);
        $this->resultRawFactoryMock = $this->createMock(RawFactory::class);
        $this->resultJsonFactoryMock = $this->createMock(JsonFactory::class);
        $this->dirMock = $this->createMock(DirectoryList::class);
        $this->resultRedirectFactoryMock = $this->createMock(RedirectFactory::class);

        $this->onepageMock = $this->createMock(Onepage::class);

        $this->controller = $this->getMockBuilder(Success::class)
                                 ->setConstructorArgs([
                                     $this->contextMock,
                                     $this->customerSessionMock,
                                     $this->customerRepositoryMock,
                                     $this->accountManagementMock,
                                     $this->coreRegistryMock,
                                     $this->translateInlineMock,
                                     $this->formKeyValidatorMock,
                                     $this->scopeConfigMock,
                                     $this->layoutFactoryMock,
                                     $this->quoteRepositoryMock,
                                     $this->resultPageFactoryMock,
                                     $this->resultLayoutFactoryMock,
                                     $this->resultRawFactoryMock,
                                     $this->resultJsonFactoryMock,
                                     $this->dirMock,
                                     $this->orderRepositoryMock,
                                 ])
                                 ->onlyMethods(['getOnepage'])
                                 ->getMock();

        $this->controller->method('getOnepage')->willReturn($this->onepageMock);

        // Set up Logger
        Logger::config($this->scopeConfigMock, $this->dirMock);
    }

    public function testExecuteNoOrderId(): void
    {
        // Mock the Redirect object
        $resultRedirectMock = $this->createMock( Redirect::class);
        $resultRedirectMock->method('setPath')->willReturnSelf();

        // Mock the ResultRedirectFactory
        $resultRedirectFactoryMock = $this->createMock( RedirectFactory::class);
        $resultRedirectFactoryMock->method('create')->willReturn($resultRedirectMock);

        // Mock the Onepage Interceptor object
        $onepageMock = $this->createMock( Interceptor::class);
        $onepageMock->method('getCheckout')->willReturnSelf();
        $onepageMock->method('getLastOrderId')->willReturn(null);

        // Ensure that the context returns the mocked resultRedirectFactory
        $this->contextMock->method('getResultRedirectFactory')->willReturn($resultRedirectFactoryMock);

        // Create the controller with the required dependencies
        $this->controller = $this->getMockBuilder(Success::class)
                                 ->setConstructorArgs([
                                     $this->contextMock,
                                     $this->customerSessionMock,
                                     $this->customerRepositoryMock,
                                     $this->accountManagementMock,
                                     $this->coreRegistryMock,
                                     $this->translateInlineMock,
                                     $this->formKeyValidatorMock,
                                     $this->scopeConfigMock,
                                     $this->layoutFactoryMock,
                                     $this->quoteRepositoryMock,
                                     $this->resultPageFactoryMock,
                                     $this->resultLayoutFactoryMock,
                                     $this->resultRawFactoryMock,
                                     $this->resultJsonFactoryMock,
                                     $this->dirMock,
                                     $this->orderRepositoryMock,
                                 ])
                                 ->onlyMethods(['getOnepage'])
                                 ->getMock();

        // Mock the getOnepage method to return the Onepage mock
        $this->controller->method('getOnepage')->willReturn($onepageMock);

        // Execute the method
        $result = $this->controller->execute();

        // Verify the method call and its arguments
        $this->assertInstanceOf( Redirect::class, $result);
        $this->assertSame($resultRedirectMock, $result);
    }

    public function testExecuteOrderHandling(): void
    {
        // Mock the Redirect object
        $resultRedirectMock = $this->createMock( Redirect::class);
        $resultRedirectMock->method('setPath')->willReturnSelf();
        $resultRedirectMock->method('setUrl')->willReturnSelf();

        // Mock the ResultRedirectFactory
        $resultRedirectFactoryMock = $this->createMock( RedirectFactory::class);
        $resultRedirectFactoryMock->method('create')->willReturn($resultRedirectMock);

        // Mock the Onepage Interceptor object
        $onepageMock = $this->createMock( Interceptor::class);
        $onepageMock->method('getCheckout')->willReturnSelf();
        $onepageMock->method('getLastOrderId')->willReturn(1);

        // Ensure that the context returns the mocked resultRedirectFactory
        $this->contextMock->method('getResultRedirectFactory')->willReturn($resultRedirectFactoryMock);

        // Mock Order and OrderPayment
        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(Order\Payment::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderMock->method('getIncrementId')->willReturn('1000001');
        $orderMock->method('getStatus')->willReturn(Order::STATE_PENDING_PAYMENT);
        $orderPaymentMock->method('getMethod')->willReturn(PaymentMethodConfig::ACCESS_WORLDPAY_HPP_CODE);
        $orderPaymentMock->method('getAdditionalInformation')->willReturn(['hppUrl' => 'http://example.com', 'transaction_reference' => '12345']);

        $this->orderRepositoryMock->method('get')->willReturn($orderMock);

        // Create the controller with the required dependencies
        $this->controller = $this->getMockBuilder(Success::class)
                                 ->setConstructorArgs([
                                     $this->contextMock,
                                     $this->customerSessionMock,
                                     $this->customerRepositoryMock,
                                     $this->accountManagementMock,
                                     $this->coreRegistryMock,
                                     $this->translateInlineMock,
                                     $this->formKeyValidatorMock,
                                     $this->scopeConfigMock,
                                     $this->layoutFactoryMock,
                                     $this->quoteRepositoryMock,
                                     $this->resultPageFactoryMock,
                                     $this->resultLayoutFactoryMock,
                                     $this->resultRawFactoryMock,
                                     $this->resultJsonFactoryMock,
                                     $this->dirMock,
                                     $this->orderRepositoryMock,
                                 ])
                                 ->onlyMethods(['getOnepage'])
                                 ->getMock();

        // Mock the getOnepage method to return the Onepage mock
        $this->controller->method('getOnepage')->willReturn($onepageMock);

        // Execute the method
        $result = $this->controller->execute();

        // Verify the method call and its arguments
        $this->assertInstanceOf( Redirect::class, $result);
        $this->assertSame($resultRedirectMock, $result);
    }
}
