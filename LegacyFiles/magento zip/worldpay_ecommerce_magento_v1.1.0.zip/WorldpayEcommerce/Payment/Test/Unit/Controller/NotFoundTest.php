<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Controller;

use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Controller\NotFound;

class NotFoundTest extends TestCase
{
    /** @var RedirectFactory|MockObject */
    private $resultRedirectFactoryMock;

    /** @var NotFound */
    private $controller;

    protected function setUp(): void
    {
        $this->resultRedirectFactoryMock = $this->createMock(RedirectFactory::class);
        $this->controller = new NotFound($this->resultRedirectFactoryMock);
    }

    public function testExecute()
    {
        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultRedirectFactoryMock->method('create')->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('noroute')->willReturnSelf();

        $result = $this->controller->execute();

        $this->assertInstanceOf(Redirect::class, $result);
    }
}
