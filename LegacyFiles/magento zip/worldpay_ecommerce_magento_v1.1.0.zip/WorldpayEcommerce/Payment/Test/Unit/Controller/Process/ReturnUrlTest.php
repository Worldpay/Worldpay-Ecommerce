<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Controller\Process;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Request\Http as HttpRequest;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Message\ManagerInterface as MessageManager;
use Magento\Framework\UrlInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Controller\Process\ReturnUrl;
use WorldpayEcommerce\Payment\Helper\InvoiceHelper;
use WorldpayEcommerce\Payment\Helper\TransactionHelper;
use WorldpayEcommerce\Payment\Test\Unit\ConfigInterface;
use WorldpayEcommerce\Payment\Test\Unit\lib\Service\TestLogger;
use WorldpayEcommerce\Payment\Validator\GuidValidator;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Payment\Gateway\Validator\ResultInterface;
use Exception;

class ReturnUrlTest extends TestCase implements ConfigInterface
{
    /** @var MockObject|Session */
    private $checkoutSessionMock;

    /** @var MockObject|ResultFactory */
    private $resultFactoryMock;

    /** @var MockObject|HttpRequest */
    private $requestMock;

    /** @var MockObject|GuidValidator */
    private $guidValidatorMock;

    /** @var MockObject|OrderRepositoryInterface */
    private $orderRepositoryMock;

    /** @var MockObject|TransactionHelper */
    private $transactionHelperMock;

    /** @var MockObject|InvoiceHelper */
    private $invoiceHelperMock;

    /** @var MockObject|UrlInterface */
    private $urlInterfaceMock;

    /** @var MockObject|RedirectFactory */
    private $resultRedirectFactoryMock;

    /** @var MockObject|MessageManager */
    private $messageManagerMock;

    /** @var MockObject|ScopeConfigInterface */
    private $scopeConfigMock;

    /** @var MockObject|DirectoryList */
    private $dirMock;

    /** @var ReturnUrl */
    private $controller;

    protected function setUp(): void
    {
        $this->checkoutSessionMock = $this->createMock(Session::class);
        $this->resultFactoryMock = $this->createMock(ResultFactory::class);
        $this->requestMock = $this->createMock(HttpRequest::class);
        $this->guidValidatorMock = $this->createMock(GuidValidator::class);
        $this->orderRepositoryMock = $this->createMock(OrderRepositoryInterface::class);
        $this->transactionHelperMock = $this->createMock(TransactionHelper::class);
        $this->invoiceHelperMock = $this->createMock(InvoiceHelper::class);
        $this->urlInterfaceMock = $this->createMock(UrlInterface::class);
        $this->resultRedirectFactoryMock = $this->createMock(RedirectFactory::class);
        $this->messageManagerMock = $this->createMock(MessageManager::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->dirMock = $this->createMock(DirectoryList::class);
        $this->orderSenderMock = $this->createMock(OrderSender::class);

        $this->dirMock->method('getPath')->with('log')->willReturn(sys_get_temp_dir());

        TestLogger::config($this->scopeConfigMock, $this->dirMock);

        $this->controller = new ReturnUrl(
            $this->checkoutSessionMock,
            $this->resultFactoryMock,
            $this->requestMock,
            $this->guidValidatorMock,
            $this->orderRepositoryMock,
            $this->transactionHelperMock,
            $this->invoiceHelperMock,
            $this->urlInterfaceMock,
            $this->resultRedirectFactoryMock,
            $this->messageManagerMock,
            $this->scopeConfigMock,
            $this->dirMock,
            $this->orderSenderMock
        );
    }

    private function mockScopeConfig()
    {
        $this->scopeConfigMock->method('getValue')
                              ->willReturnMap([
                                  ['payment/access_worldpay_hpp/debug', null, 1],
                                  ['payment/access_worldpay_hpp/app_mode', null, 'try'],
                                  ['payment/access_worldpay_hpp/api_try_password', null, self::API_TRY_PASSWORD],
                                  ['payment/access_worldpay_hpp/api_live_password', null, self::API_LIVE_PASSWORD],
                                  ['payment/access_worldpay_hpp/merchant_entity', null, self::MERCHANT_ENTITY],
                              ]);
    }

    public function testExecuteInvalidGuid()
    {
        $this->mockScopeConfig();

        $this->dirMock->method('getPath')
                      ->with('log')
                      ->willReturn(sys_get_temp_dir());

        $this->requestMock->method('getParam')->with('guid')->willReturn('invalid-guid');

        $validationResultMock = $this->createMock(ResultInterface::class);
        $validationResultMock->method('isValid')->willReturn(false);
        $validationResultMock->method('getFailsDescription')->willReturn(['Invalid GUID']);

        $this->guidValidatorMock->method('validate')->willReturn($validationResultMock);

        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultRedirectFactoryMock->method('create')->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('access_worldpay_hpp/notfound')->willReturnSelf();

        $dataToLog = [
            "urlGuid" => "invalid-guid",
            "app_mode" => 'try',
        ];

        TestLogger::setDescription("Return url - invalid guid")->alert($dataToLog);

        $this->controller->execute();
    }

    public function testExecuteValidGuid()
    {
        $this->mockScopeConfig();

        $this->requestMock->method('getParam')->with('guid')->willReturn('valid-guid');

        $validationResultMock = $this->createMock(ResultInterface::class);
        $validationResultMock->method('isValid')->willReturn(true);

        $this->guidValidatorMock->method('validate')->willReturn($validationResultMock);

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderMock->method('getStatus')->willReturn(Order::STATE_PENDING_PAYMENT);
        $orderMock->method('getIncrementId')->willReturn('000000001');
        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'success_guid' => 'valid-guid',
            'failure_guid' => 'invalid-guid',
            'cancel_guid' => 'invalid-guid',
            'transaction_reference' => 'TXN123456'
        ]);

        $this->checkoutSessionMock->method('getLastRealOrder')->willReturn($orderMock);

        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultFactoryMock->method('create')->with(ResultFactory::TYPE_REDIRECT)->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('checkout/onepage/success', ['_secure' => true])->willReturnSelf();

        $this->controller->execute();
    }

    public function testHandleSuccessResult()
    {
        $this->mockScopeConfig();

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'transaction_reference' => 'TXN123456'
        ]);

        $orderMock->expects($this->once())->method('setState')->with(Order::STATE_PROCESSING);
        $orderMock->expects($this->once())->method('setStatus')->with(Order::STATE_PROCESSING);
        $orderMock->expects($this->once())->method('addCommentToStatusHistory')->with(
            __('Payment successful via Worldpay. Transaction reference: %1', 'TXN123456')
        );

        $this->transactionHelperMock->expects($this->once())->method('createTransaction')->with(
            $orderMock, $orderPaymentMock, 'TXN123456'
        );
        $this->invoiceHelperMock->expects($this->once())->method('createInvoice')->with(
            $orderMock, 'TXN123456'
        );

        $this->orderRepositoryMock->expects($this->once())->method('save')->with($orderMock);

        $quoteId = 1;
        $orderMock->method('getQuoteId')->willReturn($quoteId);

        $this->checkoutSessionMock->expects($this->once())->method('setQuoteId')->with($quoteId);

        $this->controller->handleSuccessResult($orderMock, $orderPaymentMock);
    }

    public function testHandleCancelResult()
    {
        $this->mockScopeConfig();

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'transaction_reference' => 'TXN123456'
        ]);

        $this->checkoutSessionMock->expects($this->once())->method('restoreQuote');
        $orderMock->expects($this->once())->method('setState')->with(Order::STATE_CANCELED);
        $orderMock->expects($this->once())->method('setStatus')->with(Order::STATE_CANCELED);
        $orderMock->expects($this->once())->method('addCommentToStatusHistory')->with(
            __('Payment via Worldpay canceled by customer. Transaction reference: %1', 'TXN123456')
        );

        $this->orderRepositoryMock->expects($this->once())->method('save')->with($orderMock);

        $this->controller->handleCancelResult($orderMock, $orderPaymentMock);
    }

    public function testHandleFailureResult()
    {
        $this->mockScopeConfig();

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'transaction_reference' => 'TXN123456'
        ]);

        $this->checkoutSessionMock->expects($this->once())->method('restoreQuote');
        $orderMock->expects($this->once())->method('setState')->with(Order::STATE_CANCELED);
        $orderMock->expects($this->once())->method('setStatus')->with(Order::STATE_CANCELED);
        $orderMock->expects($this->once())->method('addCommentToStatusHistory')->with(
            __('Payment via Worldpay failed. Transaction reference: %1', 'TXN123456')
        );

        $this->orderRepositoryMock->expects($this->once())->method('save')->with($orderMock);
        $this->messageManagerMock->expects($this->once())->method('addErrorMessage')->with(__('Payment failed. Please try again.'));

        $this->controller->handleFailureResult($orderMock, $orderPaymentMock);
    }

    public function testExecuteFailureGuid()
    {
        $this->mockScopeConfig();

        $this->requestMock->method('getParam')->with('guid')->willReturn('invalid-failure-guid');

        $validationResultMock = $this->createMock(ResultInterface::class);
        $validationResultMock->method('isValid')->willReturn(true);

        $this->guidValidatorMock->method('validate')->willReturn($validationResultMock);

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderMock->method('getStatus')->willReturn(Order::STATE_PENDING_PAYMENT);
        $orderMock->method('getIncrementId')->willReturn('000000001');
        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'success_guid' => 'valid-guid',
            'failure_guid' => 'invalid-failure-guid',
            'cancel_guid' => 'invalid-guid',
            'transaction_reference' => 'TXN123456'
        ]);

        $this->checkoutSessionMock->method('getLastRealOrder')->willReturn($orderMock);

        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultFactoryMock->method('create')->with(ResultFactory::TYPE_REDIRECT)->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('checkout/cart', ['_secure' => true])->willReturnSelf();

        $dataToLog = [
            "urlGuid" => 'invalid-failure-guid',
            "orderId" => '000000001',
            "order_status" => Order::STATE_CANCELED,
            "app_mode" => 'try',
        ];

        TestLogger::setDescription("Return url - handle failure")->debug($dataToLog);

        $this->controller->execute();
    }

    public function testExecuteCancelGuid()
    {
        $this->mockScopeConfig();

        $this->requestMock->method('getParam')->with('guid')->willReturn('invalid-cancel-guid');

        $validationResultMock = $this->createMock(ResultInterface::class);
        $validationResultMock->method('isValid')->willReturn(true);

        $this->guidValidatorMock->method('validate')->willReturn($validationResultMock);

        $orderMock = $this->createMock(Order::class);
        $orderPaymentMock = $this->createMock(OrderPaymentInterface::class);

        $orderMock->method('getPayment')->willReturn($orderPaymentMock);
        $orderMock->method('getStatus')->willReturn(Order::STATE_PENDING_PAYMENT);
        $orderMock->method('getIncrementId')->willReturn('000000001');
        $orderPaymentMock->method('getAdditionalInformation')->willReturn([
            'success_guid' => 'valid-guid',
            'failure_guid' => 'invalid-guid',
            'cancel_guid' => 'invalid-cancel-guid',
            'transaction_reference' => 'TXN123456'
        ]);

        $this->checkoutSessionMock->method('getLastRealOrder')->willReturn($orderMock);

        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultFactoryMock->method('create')->with(ResultFactory::TYPE_REDIRECT)->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('checkout/cart', ['_secure' => true])->willReturnSelf();

        $dataToLog = [
            "urlGuid" => 'invalid-cancel-guid',
            "orderId" => '000000001',
            "order_status" => Order::STATE_CANCELED,
            "app_mode" => 'try',
        ];

        TestLogger::setDescription("Return url - handle cancel")->debug($dataToLog);

        $this->controller->execute();
    }

    public function testExecuteCatchBlock()
    {
        $this->mockScopeConfig();

        $this->requestMock->method('getParam')->willReturn('valid-guid');

        $validationResultMock = $this->createMock(ResultInterface::class);
        $validationResultMock->method('isValid')->willReturn(true);
        $this->guidValidatorMock->method('validate')->willReturn($validationResultMock);

        $this->checkoutSessionMock->method('getLastRealOrder')->willThrowException(new Exception('Some exception'));

        $resultRedirectMock = $this->createMock(Redirect::class);
        $this->resultRedirectFactoryMock->method('create')->willReturn($resultRedirectMock);
        $resultRedirectMock->expects($this->once())->method('setPath')->with('access_worldpay_hpp/notfound')->willReturnSelf();

        $this->controller->execute();
    }
}
