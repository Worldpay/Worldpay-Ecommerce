<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Config;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Filesystem\DirectoryList;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\lib\Service\Logger;

class ConfigTest extends TestCase
{
    private $scopeConfigMock;
    private $directoryListMock;

    protected function setUp(): void
    {
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->directoryListMock = $this->createMock(DirectoryList::class);
    }

    public function testConstructorConfiguresLogger(): void
    {
        $this->scopeConfigMock->expects($this->once())
                              ->method('getValue')
                              ->with($this->stringContains(Config::ACCESS_WORLDPAY_HPP_CODE));

        $loggerMock = $this->getMockBuilder(Logger::class)
                           ->disableOriginalConstructor()
                           ->onlyMethods(['config'])
                           ->getMock();

        $loggerMock::staticExpects($this->once())
                   ->method('config')
                   ->with($this->scopeConfigMock, $this->directoryListMock);

        $config = new Config(
            $this->scopeConfigMock,
            $this->directoryListMock
        );

        $this->assertInstanceOf(Config::class, $config);
    }

    public function testConstructorThrowsFileSystemException(): void
    {
        $this->expectException(FileSystemException::class);

        $config = new Config(
            $this->scopeConfigMock,
            $this->directoryListMock
        );
    }
}
