<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Http\Client;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\TransferInterface;
use PHPUnit\Framework\TestCase;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Builders\PaymentManagement\PaymentManagementBuilder;
use Worldpay\Api\Builders\PaymentProcessing\PaymentProcessingBuilder;
use Worldpay\Api\Builders\Payments\RefundsBuilder;
use Worldpay\Api\Exceptions\ApiException;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\Gateway\Http\Client\TransactionRefund;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Test\Unit\ConfigInterface;
use WorldpayEcommerce\Payment\Test\Unit\lib\Service\TestLogger;

class TransactionRefundTest extends TestCase implements ConfigInterface
{
    private $configMock;
    private $scopeConfigMock;
    private $storeMock;
    private $transferObjectMock;
    private $worldpayServiceMock;
    private $accessWorldpayMock;
    private $refundsBuilderMock;
    private $dirMock;
    private $transactionRefund;
    private $data;

    protected function setUp(): void
    {
        $this->configMock = $this->createMock(Config::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->storeMock = $this->createMock(Resolver::class);

        $this->transferObjectMock = $this->createMock(TransferInterface::class);

        //log writing
        $this->dirMock = $this->createMock(DirectoryList::class);
        TestLogger::config($this->scopeConfigMock, $this->dirMock);

        $this->worldpayServiceMock = $this->createMock(WorldpayService::class);

        $this->transactionRefund = new TransactionRefund(
            $this->configMock,
            $this->scopeConfigMock,
            $this->storeMock
        );

        $reflection = new \ReflectionClass($this->transactionRefund);
        $worldpayServiceProperty = $reflection->getProperty('_worldpayService');
        $worldpayServiceProperty->setAccessible(true);
        $worldpayServiceProperty->setValue($this->transactionRefund, $this->worldpayServiceMock);

        $this->setUpWorldpayEcommerce();
        $this->setUpRequestData();

        // should end here

        $this->worldpayServiceMock->method('initializeApi')
                                  ->willReturn($this->accessWorldpayMock);

        $this->accessWorldpayMock->method('refund')
                                 ->willReturn($this->refundsBuilderMock);

        $apiResponseMock = $this->createMock(ApiResponse::class);
        $apiResponseMock->statusCode = 200;
        $apiResponseMock->method('isSuccessful')->willReturn(true);
        $apiResponseMock->headers = ['WP-CorrelationId' => 'corr123'];
        $apiResponseMock->rawResponse = json_encode(['success' => true]);

        $this->refundsBuilderMock->method('withCurrency')->willReturnSelf();
        $this->refundsBuilderMock->method('withTransactionReference')->willReturnSelf();
        $this->refundsBuilderMock->method('withPartialRefundReference')->willReturnSelf();
        $this->refundsBuilderMock->method('execute')->willReturn($apiResponseMock);
    }

    private function setUpWorldpayEcommerce()
    {
        $this->accessWorldpayMock = $this->createMock(AccessWorldpay::class);
        $this->refundsBuilderMock = $this->createMock(PaymentManagementBuilder::class);
    }

    private function setUpRequestData()
    {
        $this->data = [
            'transactionReference' => 'TX12345',
            'refundAmount' => '50.00',
            'currency' => 'USD',
            'orderIncrementId' => '1001'
        ];
    }

    private function mockScopeConfig()
    {
        $this->scopeConfigMock->method('getValue')
                              ->willReturnMap([
                                  ['payment/access_worldpay_hpp/debug', null, 1],
                                  ['payment/access_worldpay_hpp/app_mode', null, 'try'],
                                  ['payment/access_worldpay_hpp/api_try_password', null, self::API_TRY_PASSWORD],
                                  ['payment/access_worldpay_hpp/api_live_password', null, self::API_LIVE_PASSWORD],
                                  ['payment/access_worldpay_hpp/merchant_entity', null, self::MERCHANT_ENTITY]
                              ]);
    }

    public function testPlaceRequestSuccessful()
    {
//        $this->mockScopeConfig();

        $this->transferObjectMock->method('getBody')->willReturn($this->data);
        $this->storeMock->method('getLocale')->willReturn('en_US');

        $response = $this->transactionRefund->placeRequest($this->transferObjectMock);

        $this->assertIsArray($response);
        $this->assertArrayHasKey('refundAmount', $response);
        $this->assertEquals('50.00', $response['refundAmount']);
    }

    public function testPlaceRequestFailed()
    {
        $this->mockScopeConfig();

        $data = [
            'transactionReference' => 'TX12345',
            'refundAmount' => '50.00',
            'currency' => 'USD',
            'orderIncrementId' => '1001'
        ];

        $this->transferObjectMock->method('getBody')->willReturn($data);
        $this->storeMock->method('getLocale')->willReturn('en_US');

        $apiResponseMock = $this->createMock(ApiResponse::class);
        $apiResponseMock->statusCode = 400;
        $apiResponseMock->method('isSuccessful')->willReturn(false);
        $apiResponseMock->headers = ['WP-CorrelationId' => 'corr123'];
        $apiResponseMock->rawResponse = json_encode(['success' => false]);

        $this->refundsBuilderMock->method('execute')->willReturn($apiResponseMock);

        $this->expectException(ClientException::class);
        $this->expectExceptionMessage('Something went wrong while requesting payment refund.');

        $this->transactionRefund->placeRequest($this->transferObjectMock);
    }

    public function testPlaceRequestHandlesExceptions()
    {
        $this->mockScopeConfig();

        $data = [
            'transactionReference' => 'TX12345',
            'refundAmount' => '50.00',
            'currency' => 'USD',
            'orderIncrementId' => '1001'
        ];

        $this->transferObjectMock->method('getBody')->willReturn($data);
        $this->storeMock->method('getLocale')->willReturn('en_US');

        $this->refundsBuilderMock->method('execute')->willThrowException(new ApiException('API Error'));

        $this->expectException(ApiException::class);
        $this->expectExceptionMessage('API Error');

        $this->transactionRefund->placeRequest($this->transferObjectMock);
    }
}
