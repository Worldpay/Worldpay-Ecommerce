<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Response;

use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayHpp\ResponseHandler;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use PHPUnit\Framework\TestCase;

class DetailsHandlerTest extends TestCase
{
    private $orderPaymentMock;
    private $detailsHandler;

    protected function setUp(): void
    {
        $this->orderPaymentMock = $this->createMock(OrderPaymentInterface::class);
        $this->detailsHandler = new ResponseHandler(new SubjectReader());
    }

    public function testHandle()
    {
        $paymentDataObjectMock = $this->createMock(\Magento\Payment\Gateway\Data\PaymentDataObjectInterface::class);
        $paymentDataObjectMock->method('getPayment')->willReturn($this->orderPaymentMock);

        $originalReadPayment = [SubjectReader::class, 'readPayment'];
        $this->setStaticMethodMock($originalReadPayment, function() use ($paymentDataObjectMock) {
            return $paymentDataObjectMock;
        });

        $response = [
            'hppUrl' => 'http://example.com/hpp',
            'success_guid' => 'success-guid',
            'failure_guid' => 'failure-guid',
            'cancel_guid' => 'cancel-guid',
            'transaction_reference' => 'transaction-ref'
        ];

        $this->orderPaymentMock->expects($this->exactly(5))
                               ->method('setAdditionalInformation')
                               ->with(
                                   $this->logicalOr(
                                       $this->equalTo('hppUrl'),
                                       $this->equalTo('success_guid'),
                                       $this->equalTo('failure_guid'),
                                       $this->equalTo('cancel_guid'),
                                       $this->equalTo('transaction_reference')
                                   ),
                                   $this->logicalOr(
                                       $this->equalTo('http://example.com/hpp'),
                                       $this->equalTo('success-guid'),
                                       $this->equalTo('failure-guid'),
                                       $this->equalTo('cancel-guid'),
                                       $this->equalTo('transaction-ref')
                                   )
                               );

        $this->detailsHandler->handle(['payment' => $paymentDataObjectMock], $response);

        $this->restoreStaticMethodMock($originalReadPayment);
    }

    private function setStaticMethodMock(array $method, callable $callback) {}

    private function restoreStaticMethodMock(array $method) {}
}
