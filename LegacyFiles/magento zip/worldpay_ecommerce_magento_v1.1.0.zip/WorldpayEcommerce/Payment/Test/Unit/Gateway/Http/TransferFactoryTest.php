<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Http;

use PHPUnit\Framework\TestCase;
use Magento\Payment\Gateway\Http\TransferBuilder;
use Magento\Payment\Gateway\Http\Transfer;
use Magento\Payment\Gateway\Http\TransferFactoryInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use WorldpayEcommerce\Payment\Gateway\Http\TransferFactory;

class TransferFactoryTest extends TestCase
{
    /**
     * @var \PHPUnit\Framework\MockObject\MockObject|TransferBuilder
     */
    private $transferBuilderMock;

    /**
     * @var TransferFactory
     */
    private $transferFactory;

    protected function setUp(): void
    {
        parent::setUp();

        $this->transferBuilderMock = $this->createMock(TransferBuilder::class);
        $this->transferFactory = new TransferFactory($this->transferBuilderMock);
    }

    public function testImplementsTransferFactoryInterface()
    {
        $this->assertInstanceOf(TransferFactoryInterface::class, $this->transferFactory);
    }

    public function testCreate()
    {
        $request = ['key' => 'value'];

        $transferMock = $this->createMock(Transfer::class);

        $this->transferBuilderMock
            ->expects($this->once())
            ->method('setBody')
            ->with($this->equalTo($request))
            ->willReturnSelf();

        $this->transferBuilderMock
            ->expects($this->once())
            ->method('build')
            ->willReturn($transferMock);

        $result = $this->transferFactory->create($request);

        $this->assertInstanceOf(TransferInterface::class, $result);
        $this->assertSame($transferMock, $result);
    }
}
