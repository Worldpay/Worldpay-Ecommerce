<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Response;

use Magento\Framework\Phrase;
use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Gateway\Response\RefundHandler;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Payment\Gateway\Data\PaymentDataObjectInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Framework\Exception\LocalizedException;

class RefundHandlerTest extends TestCase
{
    private $orderRepositoryMock;
    private $refundHandler;
    private $orderMock;
    private $paymentMock;
    private $paymentDataObjectMock;

    protected function setUp(): void
    {
        parent::setUp();

        // Mock OrderRepositoryInterface
        $this->orderRepositoryMock = $this->createMock(OrderRepositoryInterface::class);

        // Mock Order
        $this->orderMock = $this->createMock(Order::class);

        // Mock Payment
        $this->paymentMock = $this->createMock(Payment::class);

        // Mock PaymentDataObjectInterface
        $this->paymentDataObjectMock = $this->createMock(PaymentDataObjectInterface::class);

        // Create RefundHandler instance with real SubjectReader class
        $this->refundHandler = new RefundHandler(
            new SubjectReader(), // Use real SubjectReader
            $this->orderRepositoryMock
        );
    }

    public function testHandleWithNegativeRefundAmountThrowsException()
    {
        $response = [
            'refundAmount' => -50.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Expect an exception to be thrown
        $this->expectException(LocalizedException::class);
        $this->expectExceptionMessage('Refund amount cannot be negative.');

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithZeroRefundAmount()
    {
        $response = [
            'refundAmount' => 0.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Expect formatPrice method to not be called
        $this->paymentMock->expects($this->never())
                          ->method('formatPrice');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('get')
                                  ->with($this->equalTo(1))
                                  ->willReturn($this->orderMock);

        // Configure Order mock
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('Partial refund reference: partial-refund-123.'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('save')
                                  ->with($this->orderMock);

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithZeroRefundAmountDoesNotSaveOrder()
    {
        $response = [
            'refundAmount' => 0.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Expect formatPrice method to not be called
        $this->paymentMock->expects($this->never())
                          ->method('formatPrice');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->never())
                                  ->method('get')
                                  ->with($this->equalTo(1));

        // Configure Order mock
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('Partial refund reference: partial-refund-123.'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->never())
                                  ->method('save');

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithRefundAmountGreaterThanOrderTotal()
    {
        $response = [
            'refundAmount' => 150.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Expect formatPrice method to not be called
        $this->paymentMock->expects($this->never())
                          ->method('formatPrice');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('get')
                                  ->with($this->equalTo(1))
                                  ->willReturn($this->orderMock);

        // Configure Order mock
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('Partial refund reference: partial-refund-123. Refund amount exceeds the order total.'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('save')
                                  ->with($this->orderMock);

        // Expect Payment's setTransactionId method to not be called
        $this->paymentMock->expects($this->never())
                          ->method('setTransactionId');

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithMissingPartialRefundReferenceThrowsException()
    {
        $response = [
            'refundAmount' => 50.00,
            'partialRefundReference' => null,
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Expect an exception to be thrown
        $this->expectException(LocalizedException::class);
        $this->expectExceptionMessage('Partial refund reference is missing.');

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithExistingPartialRefundReference()
    {
        $response = [
            'refundAmount' => 50.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Mock Payment's formatPrice method
        $this->paymentMock->expects($this->once())
                          ->method('formatPrice')
                          ->with($this->equalTo(50.00))
                          ->willReturn('$50.00');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('get')
                                  ->with($this->equalTo(1))
                                  ->willReturn($this->orderMock);

        // Configure Order mock to expect correct parameter types
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('$50.00 sent for refund via Worldpay. Partial refund reference: partial-refund-123.'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('save')
                                  ->with($this->orderMock);

        // Expect Payment's setTransactionId method to be called
        $this->paymentMock->expects($this->once())
                          ->method('setTransactionId')
                          ->with($this->equalTo('partial-refund-123'));

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleDoesNotSaveOrderIfRefundAmountEqualsOrderTotal()
    {
        $response = [
            'refundAmount' => 100.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Mock Payment's formatPrice method
        $this->paymentMock->expects($this->once())
                          ->method('formatPrice')
                          ->with($this->equalTo(100.00))
                          ->willReturn('$100.00');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('get')
                                  ->with($this->equalTo(1))
                                  ->willReturn($this->orderMock);

        // Configure Order mock to expect correct parameter types
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->isInstanceOf( Phrase::class), // Check if it's an instance of Phrase
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->never())
                                  ->method('save');

        // Expect Payment's setTransactionId method to be called
        $this->paymentMock->expects($this->once())
                          ->method('setTransactionId')
                          ->with($this->equalTo('partial-refund-123'));

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithExceedingRefundAmountThrowsException()
    {
        $response = [
            'refundAmount' => 150.00,
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Expect an exception to be thrown
        $this->expectException(LocalizedException::class);
        $this->expectExceptionMessage('Refund amount exceeds the remaining order balance.');

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithExceedingRefundAmountDoesNotSaveOrder()
    {
        $response = [
            'refundAmount' => 150.00, // Exceeds remaining order balance
            'partialRefundReference' => 'partial-refund-123',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00); // Remaining order balance

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Expect formatPrice method to not be called
        $this->paymentMock->expects($this->never())
                          ->method('formatPrice');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->never())
                                  ->method('get')
                                  ->with($this->equalTo(1));

        // Configure Order mock
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('Refund amount exceeds the remaining order balance.'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->never())
                                  ->method('save')
                                  ->with($this->orderMock);

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }

    public function testHandleWithPartialRefundReferenceContainingSpecialCharacters()
    {
        $response = [
            'refundAmount' => 50.00,
            'partialRefundReference' => 'partial-refund-123!@#$%^&*()',
        ];

        // Mock getPayment and getOrder methods
        $this->paymentDataObjectMock->method('getPayment')->willReturn($this->paymentMock);
        $this->paymentDataObjectMock->method('getOrder')->willReturn($this->orderMock);

        // Mock Order methods
        $this->orderMock->method('getId')->willReturn(1);
        $this->orderMock->method('getGrandTotal')->willReturn(100.00);

        // Mock Order's getPayment method to return the Payment mock
        $this->orderMock->method('getPayment')->willReturn($this->paymentMock);

        // Mock Payment's formatPrice method
        $this->paymentMock->expects($this->once())
                          ->method('formatPrice')
                          ->with($this->equalTo(50.00))
                          ->willReturn('$50.00');

        // Configure OrderRepositoryInterface mock
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('get')
                                  ->with($this->equalTo(1))
                                  ->willReturn($this->orderMock);

        // Configure Order mock to expect correct parameter types
        $this->orderMock->expects($this->once())
                        ->method('addCommentToStatusHistory')
                        ->with(
                            $this->stringContains('$50.00 sent for refund via Worldpay. Partial refund reference: partial-refund-123!@#$%^&*().'),
                            $this->isType('string'),
                            $this->isType('boolean')
                        )
                        ->willReturnSelf();

        // Configure OrderRepositoryInterface mock for saving
        $this->orderRepositoryMock->expects($this->once())
                                  ->method('save')
                                  ->with($this->orderMock);

        // Expect Payment's setTransactionId method to be called
        $this->paymentMock->expects($this->once())
                          ->method('setTransactionId')
                          ->with($this->equalTo('partial-refund-123!@#$%^&*()'));

        // Call the handle method
        $this->refundHandler->handle(['payment' => $this->paymentDataObjectMock], $response);
    }
}
