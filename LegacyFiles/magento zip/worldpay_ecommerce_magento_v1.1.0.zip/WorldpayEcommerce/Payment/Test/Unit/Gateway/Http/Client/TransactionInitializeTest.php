<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Gateway\Http\Client;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Filesystem\DirectoryList;
use Magento\Framework\Locale\Resolver;
use Magento\Framework\UrlInterface;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\TransferInterface;
use PHPUnit\Framework\TestCase;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\ApiResponse;
use Worldpay\Api\Builders\PaymentProcessing\PaymentProcessingBuilder;
use Worldpay\Api\Entities\Order;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Test\Unit\ConfigInterface;
use WorldpayEcommerce\Payment\Test\Unit\lib\Service\TestLogger;
use WorldpayEcommerce\Payment\Gateway\Http\Client\AccessWorldpayHpp\TransactionInitialize;

/**
 * @covers \WorldpayEcommerce\Payment\Gateway\Http\Client\AccessWorldpayHpp\TransactionInitialize
 */
class TransactionInitializeTest extends TestCase implements ConfigInterface
{
    private $configMock;
    private $urlMock;
    private $scopeConfigMock;
    private $storeMock;
    private $transferObjectMock;
    private $worldpayServiceMock;
    private $dirMock;
    private $transactionInitialize;
    private $accessWorldpayMock;
    private $processingBuilderMock;
    private $data;

    protected function setUp(): void
    {
        $this->configMock = $this->createMock(Config::class);
        $this->scopeConfigMock = $this->createMock(ScopeConfigInterface::class);
        $this->storeMock = $this->createMock(Resolver::class);
        $this->urlMock = $this->createMock(UrlInterface::class);

        $this->transferObjectMock = $this->createMock(TransferInterface::class);

        //log writing
        $this->dirMock = $this->createMock(DirectoryList::class);
        $this->dirMock->method('getPath')->willReturn(sys_get_temp_dir());
        TestLogger::config($this->scopeConfigMock, $this->dirMock);

        $this->worldpayServiceMock = $this->createMock(WorldpayService::class);

        $this->transactionInitialize = new TransactionInitialize(
            $this->configMock,
            $this->scopeConfigMock,
            $this->storeMock,
            $this->urlMock
        );

        $reflection = new \ReflectionClass($this->transactionInitialize);
        $worldpayServiceProperty = $reflection->getProperty('_worldpayService');
        $worldpayServiceProperty->setAccessible(true);
        $worldpayServiceProperty->setValue($this->transactionInitialize, $this->worldpayServiceMock);

        $this->setUpWorldpayEcommerce();
        $this->setUpRequestData();
    }

    private function setUpWorldpayEcommerce()
    {
        $this->accessWorldpayMock = $this->createMock(AccessWorldpay::class);
        $this->processingBuilderMock = $this->createMock(PaymentProcessingBuilder::class);
    }

    private function setUpRequestData()
    {
        $this->data = [
            'paymentMethodCode' => 'access_worldpay_hpp',
            'orderId' => '1001',
            'total' => '100.00',
            'currency_code' => 'USD',
            'billing' => [],
            'shipping' => [],
            'customer' => []
        ];
    }

    public function testPlaceRequestSuccessful()
    {
        $order = new Order();
        $order->id = $this->data['orderId'];
        $order->amount = 10000;
        $order->currency = 'USD';

        $this->transferObjectMock->method('getBody')->willReturn($this->data);
        $this->storeMock->method('getLocale')->willReturn('en_UK');
        $this->urlMock->method('getUrl')->willReturn('https://example.com/return');
        $this->worldpayServiceMock->method('getOrderData')->willReturn($order);

        $apiResponse = new ApiResponse();
        $apiResponse->headers = [
            'wp-correlationid' => '00894ce0-4664-463c-a961-71c735256ec9',
        ];
        $apiResponse->statusCode = 200;
        $apiResponse->rawResponse = '{"url":"https://example.com/hpp"}';


        $this->worldpayServiceMock->expects($this->once())->method('initializeApi')->willReturn($this->accessWorldpayMock);

        $this->accessWorldpayMock->expects($this->once())->method('initiatePayment')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->expects($this->once())->method('withTransactionReference')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->expects($this->once())->method('withOptionalOrder')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->method('withDescription')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->method('withResultURLs')->willReturn($this->processingBuilderMock);

        $this->processingBuilderMock->expects($this->once())->method('execute')->willReturn($apiResponse);

        $actualResponse = $this->transactionInitialize->placeRequest($this->transferObjectMock);
        $this->assertIsArray($actualResponse);
        $this->assertArrayHasKey('hppUrl', $actualResponse);
        $this->assertEquals('https://example.com/hpp', $actualResponse['hppUrl']);
        $this->assertArrayHasKey('success_guid', $actualResponse);
        $this->assertArrayHasKey('failure_guid', $actualResponse);
        $this->assertArrayHasKey('cancel_guid', $actualResponse);
        $this->assertArrayHasKey('transaction_reference', $actualResponse);
    }

    public function testPlaceRequestThrowsClientException()
    {
        $order = new Order();
        $order->id = $this->data['orderId'];
        $order->amount = 10000;
        $order->currency = 'USD';

        $this->transferObjectMock->method('getBody')->willReturn($this->data);
        $this->storeMock->method('getLocale')->willReturn('en_UK');
        $this->urlMock->method('getUrl')->willReturn('https://example.com/return');
        $this->worldpayServiceMock->method('getOrderData')->willReturn($order);

        $apiResponse = new ApiResponse();
        $apiResponse->headers = [
            'wp-correlationid' => '00894ce0-4664-463c-a961-71c735256ec9',
        ];
        $apiResponse->statusCode = 401;
        $apiResponse->rawResponse = '{"errorName": "accessDenied","message": "Access to the requested resource has been denied"}';

        $this->worldpayServiceMock->expects($this->once())->method('initializeApi')->willReturn($this->accessWorldpayMock);

        $this->accessWorldpayMock->expects($this->once())->method('initiatePayment')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->expects($this->once())->method('withTransactionReference')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->expects($this->once())->method('withOptionalOrder')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->method('withDescription')->willReturn($this->processingBuilderMock);
        $this->processingBuilderMock->method('withResultURLs')->willReturn($this->processingBuilderMock);

        $this->processingBuilderMock->expects($this->once())->method('execute')->willReturn($apiResponse);

        $this->expectException(ClientException::class);
        $this->expectExceptionMessage($apiResponse->rawResponse);
        $this->transactionInitialize->placeRequest($this->transferObjectMock);
    }
}
