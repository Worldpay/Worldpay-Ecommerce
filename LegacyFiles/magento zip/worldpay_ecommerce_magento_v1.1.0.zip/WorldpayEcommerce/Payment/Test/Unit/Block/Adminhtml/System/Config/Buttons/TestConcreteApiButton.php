<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block\Adminhtml\System\Config\Buttons;

use Magento\Framework\Data\Form\Element\AbstractElement;
use WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons\BaseApiButton;

class TestConcreteApiButton extends BaseApiButton
{
    public function getButtonHtml(AbstractElement $element): string
    {
        return '<button>Test Button</button>';
    }

    public function callRenderScopeLabel(AbstractElement $element): string
    {
        return $this->_renderScopeLabel($element);
    }

    public function callGetElementHtml(AbstractElement $element): string
    {
        return $this->_getElementHtml($element);
    }
}
