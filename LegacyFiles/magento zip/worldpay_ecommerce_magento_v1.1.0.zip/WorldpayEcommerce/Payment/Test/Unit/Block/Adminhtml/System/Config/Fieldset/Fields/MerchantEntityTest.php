<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block\Adminhtml\System\Config\Fieldset\Fields;

use PHPUnit\Framework\TestCase;
use WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Fieldset\Fields\MerchantEntity;
use Magento\Backend\Block\Template\Context;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Test\Unit\TestElement;
use Magento\Framework\Data\Form\Element\Factory;
use Magento\Framework\Data\Form\Element\CollectionFactory;
use Magento\Framework\Escaper;
use Magento\Framework\View\Helper\SecureHtmlRenderer;
use Magento\Framework\Math\Random;

class MerchantEntityTest extends TestCase
{
    /**
     * @var MerchantEntity
     */
    private $merchantEntity;

    /**
     * @var \PHPUnit\Framework\MockObject\MockObject|WorldpayService
     */
    private $worldpayServiceMock;

    /**
     * @var TestElement
     */
    private $element;

    protected function setUp(): void
    {
        $contextMock = $this->createMock(Context::class);
        $this->worldpayServiceMock = $this->createMock(WorldpayService::class);

        $this->merchantEntity = new MerchantEntity(
            $contextMock,
            $this->worldpayServiceMock
        );

        $factoryElementMock = $this->createMock(Factory::class);
        $factoryCollectionMock = $this->createMock(CollectionFactory::class);
        $escaperMock = $this->createMock(Escaper::class);
        $secureRendererMock = $this->createMock(SecureHtmlRenderer::class);
        $randomMock = $this->createMock(Random::class);

        $this->element = new TestElement(
            $factoryElementMock,
            $factoryCollectionMock,
            $escaperMock,
            [],
            $secureRendererMock,
            $randomMock
        );

        $this->element->setHtmlOutput('');
    }

    public function testGetElementHtml()
    {
        $this->worldpayServiceMock
            ->expects($this->once())
            ->method('getMerchantEntity')
            ->willReturn('merchant123');

        $html = $this->merchantEntity->getElementHtmlForTest($this->element);

        $this->assertStringContainsString('', $html);
    }
}
