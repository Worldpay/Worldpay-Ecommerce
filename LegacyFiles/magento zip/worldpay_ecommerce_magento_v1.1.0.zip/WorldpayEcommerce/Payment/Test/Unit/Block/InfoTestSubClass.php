<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block;

use Magento\Framework\Phrase;
use WorldpayEcommerce\Payment\Block\Info;

class InfoTestSubClass extends Info
{
    public function callGetLabel($field): Phrase
    {
        return $this->getLabel($field);
    }
}
