<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block\Adminhtml\System\Config\Buttons;

use WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons\TryApiButton;
use PHPUnit\Framework\TestCase;
use Magento\Backend\Block\Template\Context;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;
use Magento\Framework\Data\Form\Element\AbstractElement;

class TryApiButtonTest extends TestCase
{
    protected $apiButton;
    protected $configButtonHelperMock;
    protected $contextMock;
    protected $elementMock;
    protected $expectedHtml;
    protected $url;
    protected $fieldIds;
    protected $buttonText;

    protected function setUp(): void
    {
        $this->contextMock = $this->getMockBuilder(Context::class)
                                  ->disableOriginalConstructor()
                                  ->getMock();

        $this->configButtonHelperMock = $this->createMock(ConfigButtonHelper::class);
        $this->elementMock = $this->createMock(AbstractElement::class);

        $this->apiButton = $this->getMockBuilder(TryApiButton::class)
                                ->setConstructorArgs([
                                    $this->contextMock,
                                    $this->configButtonHelperMock,
                                    []
                                ])
                                ->onlyMethods(['getUrl'])
                                ->getMock();

        $this->apiButton->method('getUrl')
                        ->willReturn('worldpay_ecommerce/payment/testApiCredentialsRequest?type=try');

        $this->expectedHtml = '<button>Validate Try Credentials</button>';
        $this->url = 'worldpay_ecommerce/payment/testApiCredentialsRequest?type=try';
        $this->fieldIds = [
            'api_try_username' => 'api_try_username',
            'api_try_password' => 'api_try_password',
            'merchant_entity' => 'merchant_entity'
        ];
        $this->buttonText = 'Validate Try Credentials';

        $this->configButtonHelperMock->expects($this->once())
                                     ->method('generateButtonHtml')
                                     ->with(
                                         $this->elementMock,
                                         $this->buttonText,
                                         $this->url,
                                         $this->fieldIds,
                                         'try'
                                     )
                                     ->willReturn($this->expectedHtml);
    }

    public function testGetButtonHtml()
    {
        $html = $this->apiButton->getButtonHtml($this->elementMock);
        $this->assertEquals($this->expectedHtml, $html);
    }
}
