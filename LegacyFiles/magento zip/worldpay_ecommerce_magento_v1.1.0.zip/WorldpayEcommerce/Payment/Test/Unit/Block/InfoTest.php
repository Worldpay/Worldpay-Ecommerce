<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block;

use PHPUnit\Framework\TestCase;
use Magento\Framework\Phrase;
use Magento\Payment\Gateway\ConfigInterface;
use Magento\Framework\View\Element\Template\Context;

class InfoTest extends TestCase
{
    protected $info;

    protected function setUp(): void
    {
        $contextMock = $this->createMock(Context::class);
        $configMock = $this->createMock(ConfigInterface::class);

        $this->info = new InfoTestSubClass($contextMock, $configMock, []);
    }

    public function testGetLabel()
    {
        $field = 'test_field';
        $expectedPhrase = new Phrase($field);

        $label = $this->info->callGetLabel($field);

        $this->assertInstanceOf(Phrase::class, $label);
        $this->assertEquals($expectedPhrase, $label);
    }
}
