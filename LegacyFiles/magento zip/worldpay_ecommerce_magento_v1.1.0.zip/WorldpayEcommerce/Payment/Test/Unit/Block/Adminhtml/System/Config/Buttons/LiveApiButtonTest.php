<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block\Adminhtml\System\Config\Buttons;

use WorldpayEcommerce\Payment\Block\Adminhtml\System\Config\Buttons\LiveApiButton;
use PHPUnit\Framework\TestCase;
use Magento\Backend\Block\Template\Context;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;
use Magento\Framework\Data\Form\Element\AbstractElement;

class LiveApiButtonTest extends TestCase
{
    protected $apiButton;
    protected $configButtonHelperMock;
    protected $contextMock;
    protected $elementMock;
    protected $expectedHtml;
    protected $url;
    protected $fieldIds;
    protected $buttonText;

    protected function setUp(): void
    {
        $this->contextMock = $this->getMockBuilder(Context::class)
                                  ->disableOriginalConstructor()
                                  ->getMock();

        $this->configButtonHelperMock = $this->createMock(ConfigButtonHelper::class);
        $this->elementMock = $this->createMock(AbstractElement::class);

        $this->apiButton = $this->getMockBuilder(LiveApiButton::class)
                                ->setConstructorArgs([
                                    $this->contextMock,
                                    $this->configButtonHelperMock,
                                    []
                                ])
                                ->onlyMethods(['getUrl'])
                                ->getMock();

        $this->apiButton->method('getUrl')
                        ->willReturn('worldpay_ecommerce/payment/testApiCredentialsRequest?type=live');

        $this->expectedHtml = '<button>Validate Live Credentials</button>';
        $this->url = 'worldpay_ecommerce/payment/testApiCredentialsRequest?type=live';
        $this->fieldIds = [
            'api_live_username' => 'api_live_username',
            'api_live_password' => 'api_live_password',
            'merchant_entity' => 'merchant_entity'
        ];
        $this->buttonText = 'Validate Live Credentials';

        $this->configButtonHelperMock->expects($this->once())
                                     ->method('generateButtonHtml')
                                     ->with(
                                         $this->elementMock,
                                         $this->buttonText,
                                         $this->url,
                                         $this->fieldIds,
                                         'live'
                                     )
                                     ->willReturn($this->expectedHtml);
    }

    public function testGetButtonHtml()
    {
        $html = $this->apiButton->getButtonHtml($this->elementMock);
        $this->assertEquals($this->expectedHtml, $html);
    }
}
