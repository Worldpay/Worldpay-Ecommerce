<?php

namespace WorldpayEcommerce\Payment\Test\Unit\Block\Adminhtml\System\Config\Buttons;

use PHPUnit\Framework\TestCase;
use Magento\Backend\Block\Template\Context;
use WorldpayEcommerce\Payment\Helper\ConfigButtonHelper;
use Magento\Framework\Data\Form\Element\AbstractElement;

class BaseApiButtonTest extends TestCase
{
    protected $apiButton;
    protected $configButtonHelperMock;
    protected $contextMock;
    protected $elementMock;
    protected $expectedHtml;

    protected function setUp(): void
    {
        $this->contextMock = $this->getMockBuilder(Context::class)
                                  ->disableOriginalConstructor()
                                  ->getMock();

        $this->configButtonHelperMock = $this->createMock(ConfigButtonHelper::class);
        $this->elementMock = $this->createMock(AbstractElement::class);

        $this->apiButton = new TestConcreteApiButton(
            $this->contextMock,
            $this->configButtonHelperMock,
            []
        );

        $this->expectedHtml = '<input id="element_id" name="element_name" /><br><button>Test Button</button>';
    }

    public function testRenderScopeLabel()
    {
        $html = $this->apiButton->callRenderScopeLabel($this->elementMock);

        $this->assertEquals('', $html);
    }

    public function testGetElementHtml()
    {
        $elementHtml = '<input id="element_id" name="element_name" />';
        $buttonHtml = '<button>Test Button</button>';
        $expectedHtml = $elementHtml . '<br>' . $buttonHtml;

        $this->elementMock->method('getElementHtml')->willReturn($elementHtml);
        $this->configButtonHelperMock->method('appendButtonHtml')->willReturn($expectedHtml);

        $html = $this->apiButton->callGetElementHtml($this->elementMock);

        $this->assertEquals($expectedHtml, $html);
    }
}
