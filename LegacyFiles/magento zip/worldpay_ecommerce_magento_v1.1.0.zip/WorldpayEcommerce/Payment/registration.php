<?php

use Magento\Framework\Component\ComponentRegistrar;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;

WorldpayService::includeSdk();

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'WorldpayEcommerce_Payment', __DIR__);
