<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\Successful;

use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Model\InfoInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Model\Order;
use WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome\AbstractOutcome;

class SuccessfulOutcome extends AbstractOutcome
{

    /**
     * @param  InfoInterface|OrderPaymentInterface  $payment
     * @param  object  $response
     *
     * @return void
     */
    public function setPaymentLinks(InfoInterface|OrderPaymentInterface $payment, object $response): void
    {
        $payment->setAdditionalInformation('linkData', $this->getLinkDataForPaymentManagement(
            $response->_actions->refundPayment->href ?? '')
        );
        $payment->unsAdditionalInformation('deviceDataCollectionSubmissionEndpoint');
        $payment->unsAdditionalInformation('deviceDataCollectionEndpoint');
        $payment->unsAdditionalInformation('threeDsSubmissionEndpoint');
        $payment->unsAdditionalInformation('threeDsEndpoint');
        $payment->unsAdditionalInformation('threeDSChallengeWindowSize');
        $payment->unsAdditionalInformation('checkoutSessionHref');
    }

    /**
     * @param  Order  $order
     *
     * @return void
     * @throws LocalizedException
     */
    public function handleOrder(Order $order): void
    {
        $payment = $order->getPayment();
        $this->transactionHelper->createTransaction(
            $order,
            $payment,
            $payment->getAdditionalInformation('transactionReference')
        );
        $order->addCommentToStatusHistory(
            sprintf(__('Payment successful via Worldpay. Transaction reference: %s')->render(),
                $payment->getAdditionalInformation('transactionReference'))
        );
        $order->setState(Order::STATE_PROCESSING);
        $order->setStatus(Order::STATE_PROCESSING);
        $order->getPayment()->setIsTransactionPending(false);
        $order->getPayment()->setIsTransactionClosed(true);
        $this->invoiceHelper->createInvoice($order, $payment->getAdditionalInformation('transactionReference'));
        $this->session->setLastSuccessQuoteId($order->getQuoteId());
        if ($order->getCanSendNewEmailFlag()) {
            $this->orderSender->send($order);
        }
        $this->orderRepositoryInterface->save($order);
    }

    /**
     * @param  string  $url
     *
     * @return array
     */
    protected function getLinkDataForPaymentManagement(string $url): array
    {
        $data = [];
        if (!$url) {
            return $data;
        }
        $data = [
            'paymentEnv' => 'live',
        ];
        if (str_contains($url, 'try')) {
            $data['paymentEnv'] = 'try';
        }
        $url_strings      = explode('/', str_replace('https://', '', $url));
        $data['linkData'] = $url_strings[3];

        return $data;
    }
}
