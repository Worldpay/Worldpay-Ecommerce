<?php

namespace WorldpayEcommerce\Payment\Gateway\Response\AccessWorldpayCheckout\PaymentOutcome;

interface OutcomeInterface
{

}
