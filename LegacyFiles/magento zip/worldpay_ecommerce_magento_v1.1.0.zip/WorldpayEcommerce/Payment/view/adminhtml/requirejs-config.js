var config = {
    config: {
        mixins: {
            'mage/validation': {
                'WorldpayEcommerce_Payment/js/merchant-narrative-validation-mixin': true,
                'WorldpayEcommerce_Payment/js/merchant-entity-validation-mixin': true,
            }
        }
    }
};
