require(['jquery', 'domReady!'], function ($) {
        'use strict';

        const onsiteEnabledSelector = '[data-ui-id="select-groups-worldpay-ecommerce-groups-card-payments-groups-access-worldpay-checkout-fields-active-value"]';
        const offsiteEnabledSelector = '[data-ui-id="select-groups-worldpay-ecommerce-groups-card-payments-groups-access-worldpay-hpp-fields-active-value"]';
        const selectors = [onsiteEnabledSelector, offsiteEnabledSelector];
        const cssDefaultSelector = '.worldpay-ecommerce-account-settings';

        function worldpayPaymentMethodsEnabled() {
            return selectors.some(selector => $(selector).find(':selected').val() === '1');
        }

        function isOnsitePaymentMethodEnabled() {
            return $(onsiteEnabledSelector).find(':selected').val() === '1';
        }

        function isEmptyCheckoutId() {
            return $('.worldpay-ecommerce-account-settings-onsite').val().trim() === '';
        }

        function updateValidationClasses() {
            const addClasses = worldpayPaymentMethodsEnabled();
            const isOnsiteEnabled = isOnsitePaymentMethodEnabled();

            $(cssDefaultSelector).toggleClass('required-entry', addClasses);
            $('.worldpay-ecommerce-account-settings-onsite').toggleClass('required-entry', isOnsiteEnabled);
            $('.worldpay-ecommerce-account-settings-onsite').toggleClass('mage-error', isOnsiteEnabled && isEmptyCheckoutId());
            if (!addClasses) {
                $(cssDefaultSelector).removeClass('mage-error');
            }
        }

        $(selectors.join(', ')).change(updateValidationClasses);
        updateValidationClasses();

        $('.worldpay-ecommerce-obscure').each(function() {
            let currentVal = $(this).val();
            $(this).focusin(function() {
                $(this).val('');
            } );
            $(this).focusout(function() {
                if ($(this).val() === '') {
                    $(this).val(currentVal);
                }
            });
        });
    });
