<?php

namespace WorldpayEcommerce\Payment\Plugin\Config;

use Magento\Config\Model\Config;
use WorldpayEcommerce\Payment\Gateway\Config\Config as WorldpayConfig;

class MerchantEntity
{
    /**
     * Check if merchant entity is not changed to strip off masking.
     *
     * @param  Config  $config
     *
     * @return void
     */
    public function beforeSave(Config $config): void
    {
        $merchantEntityCurrentValue = $config->getData('groups/worldpay_ecommerce/groups/account_settings/fields/merchant_entity/value');
        if (isset($merchantEntityCurrentValue) && preg_match('/^\*+[^*]{4}$/', $merchantEntityCurrentValue)) {
            $configPath = 'payment/' . WorldpayConfig::ACCESS_WORLDPAY_HPP_CODE . '/merchant_entity';
            $merchantEntityOldValue = $config->getConfigDataValue($configPath);
            if (!empty($merchantEntityOldValue)) {
                $config->setDataByPath($configPath, $merchantEntityOldValue);
            }
        }
    }
}
