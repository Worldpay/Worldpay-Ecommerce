<?php

namespace WorldpayEcommerce\Payment\Plugin;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Request\CsrfValidator;

class BypassCsrfForThreeDsSubmit
{
    /**
     * Bypass CSRF validation for 3DS challenge callback.
     *
     * @param CsrfValidator $subject
     * @param \Closure $proceed
     * @param RequestInterface $request
     * @param ActionInterface $action
     * @return void
     */
    public function aroundValidate(
        CsrfValidator $subject,
        \Closure $proceed,
        RequestInterface $request,
        ActionInterface $action
    ) {
        if ($request->getFullActionName() === 'access_worldpay_hpp_threeDsChallenge_submit') {
            return;
        }

        $proceed($request, $action);
    }
}
