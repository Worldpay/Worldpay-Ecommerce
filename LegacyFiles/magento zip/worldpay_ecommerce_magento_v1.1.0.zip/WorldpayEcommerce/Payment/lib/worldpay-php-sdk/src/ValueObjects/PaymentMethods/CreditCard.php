<?php

namespace Worldpay\Api\ValueObjects\PaymentMethods;

use Worldpay\Api\Enums\PaymentMethod;
use Worldpay\Api\ValueObjects\PaymentInstrument;

class CreditCard extends PaymentInstrument
{
	/**
	 * @var string
	 */
	public string $method = PaymentMethod::CARD;

	/**
	 * @var string
	 */
	public string $type;

	/**
	 * @var string
	 */
	public string $sessionHref;

	/**
	 * @var string
	 */
	public string $cardNumber;

	/**
	 * @var int
	 */
	public int $cardExpiryMonth;

	/**
	 * @var int
	 */
	public int $cardExpiryYear;

	/**
	 * @var string
	 */
	public string $cvc;

	/**
	 * @var string
	 */
	public string $cvcSessionHref;

	/**
	 * @var string
	 */
	public string $cardHolderName;

	/**
	 * @param  string  $type
	 */
	public function __construct(string $type) {
		$this->type = $type;
	}
}
