<?php

namespace Worldpay\Api\Enums;

/**
 * HTTP request valid methods.
 */
class RequestMethods
{
    /**
     * HTTP POST method.
     */
    public const POST = 'POST';

    /**
     * HTTP GET method.
     */
    public const GET = 'GET';
}
