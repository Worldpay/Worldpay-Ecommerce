<?php

namespace Worldpay\Api\Exceptions;

class ApiException extends \Exception
{

}
