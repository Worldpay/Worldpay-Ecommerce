<?php
use Magento\Framework\App\Bootstrap;
use Magento\Framework\App\ObjectManager;

// Include the Composer autoloader
require_once __DIR__ . '/../../../../vendor/autoload.php';

// Bootstrap Magento
require_once __DIR__ . '/../../../../app/bootstrap.php';

$bootstrap = Bootstrap::create(BP, $_SERVER);
$objectManager = $bootstrap->getObjectManager();

// Set the ObjectManager instance
ObjectManager::setInstance($objectManager);
