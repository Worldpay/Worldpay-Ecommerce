<?php

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Api\Data\TransactionInterface;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;

class TransactionHelper
{

    /**
     * @var BuilderInterface
     */
    protected BuilderInterface $transactionBuilder;

    /**
     * Transaction Helper Constructor.
     *
     * @param  BuilderInterface  $transactionBuilder
     */
    public function __construct(BuilderInterface $transactionBuilder)
    {
        $this->transactionBuilder = $transactionBuilder;
    }

    /**
     * Create transaction.
     *
     * @param  OrderInterface         $order
     * @param  OrderPaymentInterface  $payment
     * @param  string                 $transactionId
     *
     * @return TransactionInterface
     */
    public function createTransaction(
        OrderInterface $order,
        OrderPaymentInterface $payment,
        string $transactionId
    ): TransactionInterface {
        return $this->transactionBuilder
            ->setPayment($payment)
            ->setOrder($order)
            ->setTransactionId($transactionId)
            ->setFailSafe(true)
            ->build(TransactionInterface::TYPE_PAYMENT)
            ->setIsClosed(true);
    }
}
