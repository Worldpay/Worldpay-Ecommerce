<?php
/**
 * Plugin Name: Worldpay eCommerce for WooCommerce
 * Description: Use the Worldpay eCommerce for WooCommerce plugin to easily integrate your WooCommerce Online Store into Worldpay eCommerce.
 * Version: 1.0.1
 * Requires at least: 6.4.2
 * Requires PHP: 7.4
 * Author: Worldpay
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 * WC requires at least: 8.4.0
 * WC tested up to: 8.5.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WORLDPAY_ECOMM_WC_PLUGIN_FILE' ) ) {
	define( 'WORLDPAY_ECOMM_WC_PLUGIN_FILE', __FILE__ );
}

define( 'WORLDPAY_ECOMMERCE_WOOCOMMERCE_PHP_MIN_VERSION', '7.4' );
define( 'WORLDPAY_ECOMMERCE_WOOCOMMERCE_WP_MIN_VERSION', '6.4.2' );
define( 'WORLDPAY_ECOMMERCE_WOOCOMMERCE_WC_MIN_VERSION', '8.4.0' );

add_action( 'plugins_loaded', 'woocommerce_worldpay_ecommerce_compatibility_check' );

register_uninstall_hook(
	WORLDPAY_ECOMM_WC_PLUGIN_FILE,
	'woocommerce_worldpay_ecommerce_uninstall'
);

// Check if WooCommerce is active
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {


	if ( ! class_exists( 'WC_Worldpay_Ecommerce_Woocommerce', false ) ) {
		include_once dirname( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) . '/includes/class-wc-worldpay-ecommerce-woocommerce.php';
	}

	WC_Worldpay_Ecommerce_Woocommerce::instance();
}

function woocommerce_worldpay_ecommerce_compatibility_check() {
	global $wp_version;
	if ( version_compare( phpversion(), WORLDPAY_ECOMMERCE_WOOCOMMERCE_PHP_MIN_VERSION, '<' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_php_min_version_notice' );
	}
	if ( version_compare( $wp_version, WORLDPAY_ECOMMERCE_WOOCOMMERCE_WP_MIN_VERSION, '<' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_wp_min_version_notice' );
	}
	if ( version_compare( WC()->version, WORLDPAY_ECOMMERCE_WOOCOMMERCE_WC_MIN_VERSION, '<' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_wc_min_version_notice' );
	}
	if ( ! extension_loaded( 'curl' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_php_curl_notice' );
	}
	if ( ! extension_loaded( 'mbstring' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_php_mbstring_notice' );
	}
	if ( ! extension_loaded( 'intl' ) ) {
		deactivate_plugins( plugin_basename( WORLDPAY_ECOMM_WC_PLUGIN_FILE ) );
		add_action( 'admin_notices', 'woocommerce_worldpay_ecommerce_php_intl_notice' );
	}
}

function woocommerce_worldpay_ecommerce_php_min_version_notice() {
	echo '<div class="error"><p><strong>' . sprintf( __( 'Worldpay Ecommerce for Woocommerce requires PHP %s and above to be activated.',
			'worldpay-gateway-woocommerce' ), WORLDPAY_ECOMMERCE_WOOCOMMERCE_PHP_MIN_VERSION ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_wp_min_version_notice() {
	echo '<div class="error"><p><strong>' . sprintf( __( 'Worldpay Ecommerce for Woocommerce requires Wordpress %s and above to be activated.',
			'worldpay-gateway-woocommerce' ), WORLDPAY_ECOMMERCE_WOOCOMMERCE_WP_MIN_VERSION ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_wc_min_version_notice() {
	echo '<div class="error"><p><strong>' . sprintf( __( 'Worldpay Ecommerce for Woocommerce requires Woocoomerce %s and above to be activated.',
			'worldpay-gateway-woocommerce' ), WORLDPAY_ECOMMERCE_WOOCOMMERCE_WC_MIN_VERSION ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_php_curl_notice() {
	echo '<div class="error"><p><strong>' . __( 'Worldpay Ecommerce for Woocommerce requires php-curl to be activated.',
			'worldpay-gateway-woocommerce' ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_php_mbstring_notice() {
	echo '<div class="error"><p><strong>' . __( 'Worldpay Ecommerce for Woocommerce requires php-mbstring to be activated.',
			'worldpay-gateway-woocommerce' ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_php_intl_notice() {
	echo '<div class="error"><p><strong>' . __( 'Worldpay Ecommerce for Woocommerce requires php-intl to be activated.',
			'worldpay-gateway-woocommerce' ) . '</strong></p></div>';
}

function woocommerce_worldpay_ecommerce_uninstall() {
	delete_option( 'woocommerce_access_worldpay_hpp_settings' );
}
