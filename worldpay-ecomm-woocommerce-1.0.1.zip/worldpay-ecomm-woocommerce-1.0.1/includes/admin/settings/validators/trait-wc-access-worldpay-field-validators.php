<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

trait WC_Access_Worldpay_Field_Validators {

	/**
	 * Validate live username field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_api_live_username_field( $key, $value ) {
		if ( wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) && empty( $value ) ) {
			WC_Admin_Settings::add_error( 'The API Live user name is mandatory when you enable Live mode.' );
		}

		return $value;
	}

	/**
	 * Validate live password field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_api_live_password_field( $key, $value ) {
		if ( preg_match( '/^[*]+$/', $value ) && $value != $this->get_option( 'app_api_live_password' ) ) {
			$value = $this->get_option( 'app_api_live_password' );
		}
		if ( wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) && empty( $value ) ) {
			WC_Admin_Settings::add_error( 'The API Live password is mandatory when you enable Live mode.' );
			$value = '';
		}

		return $value;
	}

	/**
	 * Validate try username field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_api_try_username_field( $key, $value ) {
		if ( ! wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) && empty( $value ) ) {
			WC_Admin_Settings::add_error( 'The API Try user name is mandatory when you enable Try mode.' );
		}

		return $value;
	}

	/**
	 * Validate try password field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_api_try_password_field( $key, $value ) {
		if ( preg_match( '/^[*]+$/', $value ) && $value != $this->get_option( 'app_api_try_password' ) ) {
			$value = $this->get_option( 'app_api_try_password' );
		}
		if ( ! wc_string_to_bool( $this->get_option( 'is_live_mode' ) ) && empty( $value ) ) {
			WC_Admin_Settings::add_error( 'The API Try password is mandatory when you enable Try mode.' );
			$value = '';
		}

		return $value;
	}

	/**
	 * Validate merchant entity field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_merchant_entity_field( $key, $value ) {
		if ( preg_match( '/^\\*+[^*]{4}$/', $value ) && $value != $this->get_option( 'app_merchant_entity' ) ) {
			$value = $this->get_option( 'app_merchant_entity' );
		}
		if ( empty( $value ) || strlen( $value ) > 32 ) {
			WC_Admin_Settings::add_error( 'The merchant entity is mandatory. Maximum of 32 characters.' );
		}

		return $value;
	}

	/**
	 * Validate merchant narrative field.
	 *
	 * @param $key
	 * @param $value
	 *
	 * @return mixed|string
	 */
	public function validate_app_merchant_narrative_field( $key, $value ) {
		if ( empty( $value ) || strlen( $value ) > 24 ) {
			WC_Admin_Settings::add_error( 'The merchant narrative is mandatory. Maximum of 24 characters.' );
		}

		return $value;
	}
}