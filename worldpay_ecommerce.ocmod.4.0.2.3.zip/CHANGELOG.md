# Worldpay eCommerce for OpenCart change log

## [v1.0.1] (07/19/2024)
* Added compatibility checks.
* Added iframe support.
* Added regex validation for merchant narrative.
* Added Description setting.
* Removed GBP checkout restriction.

## [v1.0.0] (03/01/2024)
* Initial release.
