<?php

namespace WorldpayEcommerce\Payment\Controller;

use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\App\ActionInterface;

class NotFound implements ActionInterface
{
    /**
     * @var RedirectFactory
     */
    protected RedirectFactory $resultRedirectFactory;

    /**
     * Constructor.
     *
     * @param RedirectFactory $resultRedirectFactory
     */
    public function __construct(
        RedirectFactory $resultRedirectFactory
    ) {
        $this->resultRedirectFactory = $resultRedirectFactory;
    }

    /**
     * Execute action.
     *
     * @return Redirect
     */
    public function execute(): Redirect
    {
        return $this->resultRedirectFactory->create()->setPath('noroute');
    }
}
