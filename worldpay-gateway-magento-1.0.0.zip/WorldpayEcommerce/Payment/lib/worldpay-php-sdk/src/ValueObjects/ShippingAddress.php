<?php

namespace Worldpay\Api\ValueObjects;

/**
 * Contains the shipping address information.
 */
class ShippingAddress extends Address
{

}
