<?php

namespace Worldpay\Api\ValueObjects;

/**
 * Contains the billingAddress information.
 */
class BillingAddress extends Address
{

}
