<?php

namespace Worldpay\Api;

interface ApiInterface
{

}
