<?php

namespace Worldpay\Api;

use Worldpay\Api\Builders\HostedPaymentPages\HostedPaymentPagesBuilder;
use Worldpay\Api\Builders\Payments\RefundsBuilder;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;

class AccessWorldpay implements ApiInterface
{
    public const TRY_ACCESS_WORLDPAY_URL = 'https://try.access.worldpay.com';
    public const LIVE_ACCESS_WORLDPAY_URL = 'https://access.worldpay.com';

    /*
     * payment_pages:setup action links
     */
    public const TRY_PAYMENT_PAGES_SETUP_URL = 'https://try.access.worldpay.com/payment_pages';
    public const LIVE_PAYMENT_PAGES_SETUP_URL = 'https://access.worldpay.com/payment_pages';

    /*
     * payment_pages:setup headers
     */
    public const HEADER_PAYMENT_PAGES_SETUP_CONTENT_TYPE = 'application/vnd.worldpay.payment_pages-v1.hal+json';
    public const HEADER_PAYMENT_PAGES_SETUP_ACCEPT = 'application/vnd.worldpay.payment_pages-v1.hal+json';

    /*
     * Query payments
     */
    public const TRY_PAYMENT_QUERIES_URL = 'https://try.access.worldpay.com/paymentQueries/payments';
    public const LIVE_PAYMENT_QUERIES_URL = 'https://access.worldpay.com/paymentQueries/payments';

    /*
     * Query payments headers
     */
    public const HEADER_PAYMENT_QUERIES_CONTENT_TYPE = 'application/vnd.worldpay.payment-queries-v1.hal+json';
    public const HEADER_PAYMENT_QUERIES_ACCEPT = 'application/vnd.worldpay.payment-queries-v1.hal+json';

    /*
     * payments:events headers
     */
    public const HEADER_PAYMENTS_EVENTS_CONTENT_TYPE = 'application/vnd.worldpay.payments-v6+json';
    public const HEADER_PAYMENTS_EVENTS_ACCEPT = 'application/vnd.worldpay.payments-v6.hal+json';

    /**
     * @var AccessWorldpayConfigProvider
     */
    protected AccessWorldpayConfigProvider $apiConfigProvider;

    /**
     * @param $method
     * @param $arguments
     * @return mixed
     */
    public static function __callStatic($method, $arguments)
    {
        return (new static)->$method(...$arguments);
    }

    /**
     * @param  AccessWorldpayConfigProvider  $apiConfigProvider
     * @return AccessWorldpay
     */
    protected function config(AccessWorldpayConfigProvider $apiConfigProvider): AccessWorldpay {
        $this->apiConfigProvider = $apiConfigProvider;

        return $this;
    }

    /**
     * @param  int  $amount
     * @return HostedPaymentPagesBuilder
     */
    public function HPPSetup(int $amount): HostedPaymentPagesBuilder {
        return (new HostedPaymentPagesBuilder($this->apiConfigProvider))->withAmount($amount);
    }

    /**
     * @param  int  $amount
     * @return RefundsBuilder
     */
    public function refund(int $amount): RefundsBuilder {
        return (new RefundsBuilder($this->apiConfigProvider))->withAmount($amount);
    }

    /**
     * @param  string  $environment
     * @return string
     */
    public static function paymentPagesSetupUrl(string $environment) {
        return $environment === Environment::LIVE_MODE ? self::LIVE_PAYMENT_PAGES_SETUP_URL : self::TRY_PAYMENT_PAGES_SETUP_URL;
    }

    /**
     * @return string
     */
    public static function paymentPagesSetupContentTypeHeader(): string {
        return self::HEADER_PAYMENT_PAGES_SETUP_CONTENT_TYPE;
    }

    /**
     * @return string
     */
    public static function paymentPagesSetupAcceptHeader(): string {
        return self::HEADER_PAYMENT_PAGES_SETUP_ACCEPT;
    }

    /**
     * @param  string  $environment
     * @return string
     */
    public static function paymentQueriesUrl(string $environment): string {
        return $environment === Environment::LIVE_MODE ? self::LIVE_PAYMENT_QUERIES_URL : self::TRY_PAYMENT_QUERIES_URL;
    }

    /**
     * @return string
     */
    public static function paymentQueriesContentTypeHeader(): string {
        return self::HEADER_PAYMENT_QUERIES_CONTENT_TYPE;
    }

    /**
     * @return string
     */
    public static function paymentQueriesAcceptHeader(): string {
        return self::HEADER_PAYMENT_QUERIES_ACCEPT;
    }

    /**
     * @param  string  $environment
     * @return string
     */
    public static function rootResource(string $environment): string {
        return $environment === Environment::LIVE_MODE ? self::LIVE_ACCESS_WORLDPAY_URL : self::TRY_ACCESS_WORLDPAY_URL;
    }

    /**
     * @return string
     */
    public static function paymentsEventsContentTypeHeader(): string {
        return self::HEADER_PAYMENTS_EVENTS_CONTENT_TYPE;
    }

    /**
     * @return string
     */
    public static function paymentsEventsAcceptHeader(): string {
        return self::HEADER_PAYMENTS_EVENTS_ACCEPT;
    }
}
