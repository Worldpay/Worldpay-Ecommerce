<?php

namespace Worldpay\Api\Services\Api\AccessWorldpay;

use Worldpay\Api\ApiResponse;
use Worldpay\Api\Builders\RequestBuilder;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;

class QueryResource
{
    /**
     * @param  string  $payload
     * @return ApiResponse
     * @throws AuthenticationException
     */
    public static function paymentPagesSetup(string $payload): ApiResponse {
        $apiConfigProvider = self::config();

        return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
            ->withContentTypeHeader(AccessWorldpay::paymentPagesSetupContentTypeHeader())
            ->withAcceptHeader(AccessWorldpay::paymentPagesSetupAcceptHeader())
            ->withBody($payload)
            ->post(AccessWorldpay::paymentPagesSetupUrl($apiConfigProvider->environment));
    }

    /**
     * Query payment using the transaction reference (used in authorization request) and entity.
     *
     * @param  string  $transactionReference
     * @return ApiResponse
     * @throws AuthenticationException
     */
    public static function queryPaymentByTransactionReference(string $transactionReference): ApiResponse {
        $apiConfigProvider = self::config();

        $queryParams = array(
            'transactionReference' => $transactionReference,
            'entity' => $apiConfigProvider->merchantEntity ?? '',
        );

        return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
            ->withContentTypeHeader(AccessWorldpay::paymentQueriesContentTypeHeader())
            ->withAcceptHeader(AccessWorldpay::paymentQueriesAcceptHeader())
            ->withParams($queryParams)
            ->get(AccessWorldpay::paymentQueriesUrl($apiConfigProvider->environment));
    }

    /**
     * Query payment using the self reference.
     *
     * @param  string  $selfReferenceUrl
     * @return ApiResponse
     * @throws AuthenticationException
     */
    public static function queryPaymentBySelfReference(string $selfReferenceUrl): ApiResponse {
        $apiConfigProvider = self::config();

        return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
            ->withContentTypeHeader(AccessWorldpay::paymentQueriesContentTypeHeader())
            ->withAcceptHeader(AccessWorldpay::paymentQueriesAcceptHeader())
            ->get(AccessWorldpay::rootResource($apiConfigProvider->environment) . $selfReferenceUrl);
    }

    /**
     * Request payment refund.
     *
     * @param  string  $refundUrl
     * @return ApiResponse
     * @throws AuthenticationException
     */
    public static function paymentsRefund(string $refundUrl): ApiResponse {
        $apiConfigProvider = self::config();

        return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
            ->withContentTypeHeader(AccessWorldpay::paymentsEventsContentTypeHeader())
            ->withAcceptHeader(AccessWorldpay::paymentsEventsAcceptHeader())
            ->post($refundUrl);
    }

    /**
     * Request payment partial refund.
     *
     * @param  string  $partialRefundUrl
     * @param  string  $payload
     * @return ApiResponse
     * @throws AuthenticationException
     */
    public static function paymentsPartialRefund(string $partialRefundUrl, string $payload): ApiResponse {
        $apiConfigProvider = self::config();

        return RequestBuilder::withBasicAuth($apiConfigProvider->username, $apiConfigProvider->password)
            ->withContentTypeHeader(AccessWorldpay::paymentsEventsContentTypeHeader())
            ->withAcceptHeader(AccessWorldpay::paymentsEventsAcceptHeader())
            ->withBody($payload)
            ->post($partialRefundUrl);
    }

    /**
     * @return AccessWorldpayConfigProvider
     * @throws AuthenticationException
     */
    public static function config(): AccessWorldpayConfigProvider {
        $apiConfigProvider = AccessWorldpayConfigProvider::instance();
        if (empty($apiConfigProvider->username) ||
            empty($apiConfigProvider->password)) {
            throw new AuthenticationException('Invalid authentication credentials.');
        }

        return $apiConfigProvider;
    }
}
