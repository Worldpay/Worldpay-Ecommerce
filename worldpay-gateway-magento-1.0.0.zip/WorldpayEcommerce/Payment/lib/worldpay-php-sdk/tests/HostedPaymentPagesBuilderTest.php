<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\Builders\HostedPaymentPages\HostedPaymentPagesBuilder;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Enums\ShippingMethod;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;

class HostedPaymentPagesBuilderTest extends TestCase
{
    public static function setUpBeforeClass(): void {
        $apiConfigProvider = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->environment = Environment::TRY_MODE;
        $apiConfigProvider->username = '';
        $apiConfigProvider->password = '';
        $apiConfigProvider->merchantEntity = '';
        $apiConfigProvider->merchantNarrative = 'php-sdk';
    }

    public function testSetup() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(100)
                ->withTransactionReference(bin2hex(random_bytes(12)))
                ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithCurrency() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withCurrency('USD')
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithDescription() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withDescription('Mind Palace Ltd')
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithBillingAddress() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $billingAddress = new BillingAddress();
        $billingAddress->address1 = '221B Baker Street';
        $billingAddress->address2 = 'Marylebone';
        $billingAddress->address3 = 'Westminster';
        $billingAddress->postalCode = 'NW1 6XE';
        $billingAddress->city = 'London';
        $billingAddress->state = 'Greater London';
        $billingAddress->countryCode = 'GB';

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withBillingAddress($billingAddress)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithResultURLs() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $resultURLs = new ResultURLs();
        $resultURLs->successURL = 'https://mindpalace-website/result/success';
        $resultURLs->pendingURL = 'https://mindpalace-website/result/pending';
        $resultURLs->failureURL = 'https://mindpalace-website/result/failure';
        $resultURLs->errorURL = 'https://mindpalace-website/result/error';
        $resultURLs->cancelURL = 'https://mindpalace-website/result/cancel';
        $resultURLs->expiryURL = 'https://mindpalace-website/result/expiry';

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withResultURLs($resultURLs)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithExpiry() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withExpiry(300)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithShippingAddress() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $shippingAddress = new ShippingAddress();
        $shippingAddress->address1 = 'The Palatine Centre';
        $shippingAddress->address2 = 'Durham University';
        $shippingAddress->address3 = 'Stockton Road';
        $shippingAddress->postalCode = 'DH1 3LE';
        $shippingAddress->city = 'Durham';
        $shippingAddress->state = 'County Durham';
        $shippingAddress->countryCode = 'GB';

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withShippingAddress($shippingAddress)->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithShippingEmail() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

       $shippingEmail = 'james.moriarty@example.com';

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withShippingEmail($shippingEmail)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithShippingMethod() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withShippingMethod(ShippingMethod::OTHER)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public function testWithCustomer() {
        $builder = new HostedPaymentPagesBuilder(AccessWorldpayConfigProvider::instance());

        $customer = new Customer();
        $customer->firstName = 'James';
        $customer->lastName = 'Moriarty';
        $customer->email = 'james.moriarty@example.com';
        $customer->phoneNumber = '01189998819999197253';

        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference(bin2hex(random_bytes(12)))
            ->withCustomer($customer)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }
}
