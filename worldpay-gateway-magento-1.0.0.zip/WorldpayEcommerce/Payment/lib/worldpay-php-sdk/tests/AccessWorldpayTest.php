<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Enums\ShippingMethod;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;

class AccessWorldpayTest extends TestCase
{
    public static function setUpBeforeClass(): void {
        $apiConfigProvider = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->environment = Environment::TRY_MODE;
        $apiConfigProvider->username = '';
        $apiConfigProvider->password = '';
        $apiConfigProvider->merchantEntity = '';
        $apiConfigProvider->merchantNarrative = 'php-sdk';
    }

    /**
     * @dataProvider HPPSetupProvider
     */
    public function testHPPSetup($amount, $transactionReference, $expectedApiResponseStatusCode) {
        $api = AccessWorldpay::config(AccessWorldpayConfigProvider::instance());

        $apiResponse = $api->HPPSetup($amount)
            ->withTransactionReference($transactionReference)
            ->execute();
        $this->assertEquals($expectedApiResponseStatusCode, $apiResponse->statusCode);
    }

    /**
     * @dataProvider HPPSetupWithFullDataProvider
     */
    public function testHPPSetupWithFullData($transactionReference, $currency, $description, $billingAddress, $resultURLs, $expiry, $shippingAddress, $shippingEmail, $customer) {
        $api = AccessWorldpay::config(AccessWorldpayConfigProvider::instance());

        $apiResponse = $api->HPPSetup(100)
            ->withCurrency($currency)
            ->withTransactionReference($transactionReference)
            ->withDescription($description)
            ->withBillingAddress($billingAddress)
            ->withResultURLs($resultURLs)
            ->withExpiry($expiry)
            ->withShippingAddress($shippingAddress)
            ->withShippingEmail($shippingEmail)
            ->withShippingMethod(ShippingMethod::OTHER)
            ->withCustomer($customer)
            ->execute();
        $this->assertNotNull($apiResponse);
        $this->assertEquals(200, $apiResponse->statusCode);
        $this->assertStringContainsString('url', $apiResponse->rawResponse);
    }

    public static function HPPSetupProvider() {
        return [
            //amount, transactionReference, expected status code
            [0, bin2hex(random_bytes(12)), 400],
            [1, bin2hex(random_bytes(12)), 200],
            [10, bin2hex(random_bytes(12)), 200],
            [100, bin2hex(random_bytes(12)), 200]
        ];
    }

    public static function HPPSetupWithFullDataProvider() {
        $transactionReference = bin2hex(random_bytes(12));

        $currency = 'USD';

        $description = 'Mind Palace Ltd';

        $billingAddress = new BillingAddress();
        $billingAddress->address1 = '221B Baker Street';
        $billingAddress->address2 = 'Marylebone';
        $billingAddress->address3 = 'Westminster';
        $billingAddress->postalCode = 'NW1 6XE';
        $billingAddress->city = 'London';
        $billingAddress->state = 'Greater London';
        $billingAddress->countryCode = 'GB';

        $resultURLs = new ResultURLs();
        $resultURLs->successURL = 'https://mindpalace-website/result/success';
        $resultURLs->pendingURL = 'https://mindpalace-website/result/pending';
        $resultURLs->failureURL = 'https://mindpalace-website/result/failure';
        $resultURLs->errorURL = 'https://mindpalace-website/result/error';
        $resultURLs->cancelURL = 'https://mindpalace-website/result/cancel';
        $resultURLs->expiryURL = 'https://mindpalace-website/result/expiry';

        $expiry = 300;

        $shippingAddress = new ShippingAddress();
        $shippingAddress->address1 = 'The Palatine Centre';
        $shippingAddress->address2 = 'Durham University';
        $shippingAddress->address3 = 'Stockton Road';
        $shippingAddress->postalCode = 'DH1 3LE';
        $shippingAddress->city = 'Durham';
        $shippingAddress->state = 'County Durham';
        $shippingAddress->countryCode = 'GB';

        $shippingEmail = 'james.moriarty@example.com';

        $customer = new Customer();
        $customer->firstName = 'John';
        $customer->lastName = 'Smith';
        $customer->email = 'sample@sample.com';
        $customer->phoneNumber = '4444';

        return [
            [$transactionReference, $currency, $description, $billingAddress, $resultURLs, $expiry, $shippingAddress, $shippingEmail, $customer],
        ];
    }
}