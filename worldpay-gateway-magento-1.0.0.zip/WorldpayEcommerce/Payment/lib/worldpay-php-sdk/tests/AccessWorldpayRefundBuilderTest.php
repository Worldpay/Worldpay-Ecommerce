<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\Builders\Payments\AccessWorldpayRefundBuilder;
use Worldpay\Api\Builders\Payments\RefundsBuilder;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;

class AccessWorldpayRefundBuilderTest extends TestCase
{
    public function testCreatePayload() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $expectedPayload = json_encode([
            'value' => [
                'amount' => 125,
                'currency' => 'GBP',
            ],
            'reference' => 'partial-refund-reference',
        ]);

        $builder->withAmount(125)
            ->withPartialRefundReference('partial-refund-reference');

        $apiBuilder = new AccessWorldpayRefundBuilder($builder);
        $payload = $apiBuilder->createPayload();
        $this->assertEquals($expectedPayload, $payload);

        $expectedPayload = json_encode([
            'value' => [
                'amount' => 125,
                'currency' => 'EUR',
            ],
            'reference' => 'partial-refund-reference',
        ]);

        $builder->withAmount(125)
            ->withCurrency('EUR')
            ->withPartialRefundReference('partial-refund-reference');

        $apiBuilder = new AccessWorldpayRefundBuilder($builder);
        $payload = $apiBuilder->createPayload();
        $this->assertEquals($expectedPayload, $payload);
    }
}
