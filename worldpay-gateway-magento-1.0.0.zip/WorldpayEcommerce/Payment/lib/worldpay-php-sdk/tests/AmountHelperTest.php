<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\AmountHelper;

class AmountHelperTest extends TestCase
{
    /**
     * @dataProvider AmountProvider
     */
    public function testDecimalToExponentDelimiter($amount, $currency, $locale, $expectedAmount) {
        $convertedAmount = AmountHelper::decimalToExponentDelimiter($amount, $currency, $locale);
        $this->assertIsInt($convertedAmount);
        $this->assertEquals($expectedAmount, $convertedAmount);
    }

    public function testDecimalToExponentDelimiterWithInvalidAmount() {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid amount.');
        $convertedAmount = AmountHelper::decimalToExponentDelimiter('test');
    }

    public function testDecimalToExponentDelimiterWithInvalidCurrency() {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid currency.');
        $convertedAmount = AmountHelper::decimalToExponentDelimiter('10.00', 10);

        $convertedAmount = AmountHelper::decimalToExponentDelimiter('10.00', 'GBP');
        $this->assertIsInt($convertedAmount);
        $this->assertEquals(1000, $convertedAmount);
    }

    public function testDecimalToExponentDelimiterWithInvalidLocale() {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid language tag.');
        $convertedAmount = AmountHelper::decimalToExponentDelimiter(10.00, 'GBP', 10);

        $convertedAmount = AmountHelper::decimalToExponentDelimiter('10.00', 'GBP');
        $this->assertIsInt($convertedAmount);
        $this->assertEquals(1000, $convertedAmount);
    }

    public static function amountProvider() {
        return [
            //amount, currency, locale, expected converted amount
            [0.01, 'GBP', 'en-GB', 1],
            [0.1, 'GBP', 'en-GB', 10],
            [1, 'GBP', 'en-GB', 100],
            [1.0, 'GBP', 'en-GB', 100],
            [1.00, 'GBP', 'en-GB', 100],
            [100.01, 'GBP', 'en-GB', 10001],
            [1.00, 'BHD', '', 1000],
            [1.00, 'XOF', '', 1],
        ];
    }
}
