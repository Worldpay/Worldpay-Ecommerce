<?php

namespace Tests;

use PHPUnit\Framework\TestCase;
use Worldpay\Api\AccessWorldpay;
use Worldpay\Api\Builders\Payments\RefundsBuilder;
use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;

class RefundBuilderTest extends TestCase
{
    public static function setUpBeforeClass(): void {
        $apiConfigProvider = AccessWorldpayConfigProvider::instance();
        $apiConfigProvider->environment = Environment::TRY_MODE;
        $apiConfigProvider->username = '';
        $apiConfigProvider->password = '';
        $apiConfigProvider->merchantEntity = '';
        $apiConfigProvider->merchantNarrative = 'php-sdk';
    }

    /**
     * @dataProvider transactionProvider
     */
    public function testRefundWithSuccessfulTransaction($amount, $transactionReference, $hppUrl) {
        fwrite(STDERR, print_r('Open HPP Url in browser and simulate successful transaction ', TRUE));
        fwrite(STDERR, print_r($hppUrl, TRUE));
        sleep(30);

        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount($amount)
            ->withTransactionReference($transactionReference)
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(202, $apiResponse->statusCode);
    }

    public function testRefundWithFailedTransaction() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $this->expectException(ApiException::class);
        $this->expectExceptionMessage('Refund is not available.');
        $apiResponse = $builder->withAmount(1)
            ->withTransactionReference('51ab3a042ef8eceb0370abb9271535679cf8a1c3')
            ->execute();
    }

    public function testRefundWithInvalidTransactionReference() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid transaction reference. Must supply a non empty-string.');
        $apiResponse = $builder->withAmount(100)
            ->execute();

        $this->expectException(ApiException::class);
        $this->expectExceptionMessage('No payments associated with the given parameters.');
        $apiResponse = $builder->withAmount(100)
            ->withTransactionReference('3daeb58d-e1ab-4baa-b6c3')
            ->execute();
    }

    public function testRefundWithInvalidAmount() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Requested refund amount is higher than the authorization amount.');
        $apiResponse = $builder->withAmount(999900)
            ->withTransactionReference('3daeb58d-e1ab-4baa-b6c3-ac846c8c90b0')
            ->execute();
    }

    public function testPartialRefund() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $apiResponse = $builder->withAmount(1)
            ->withTransactionReference('3daeb58d-e1ab-4baa-b6c3-ac846c8c90b0')
            ->withPartialRefundReference(Helper::generateString(12))
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(202, $apiResponse->statusCode);
    }

    public function testPartialRefundWithInvalidPartialRefundReference() {
        $builder = new RefundsBuilder(AccessWorldpayConfigProvider::instance());

        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Invalid partial refund reference. Must supply a non empty-string. Maximum of 128 characters.');
        $apiResponse = $builder->withAmount(1)
            ->withTransactionReference('3daeb58d-e1ab-4baa-b6c3-ac846c8c90b0')
            ->execute();

        $this->assertNotNull($apiResponse);
        $this->assertEquals(202, $apiResponse->statusCode);
    }

    public function transactionProvider() {
        self::setUpBeforeClass();

        $amount = 100;
        $transactionReference = Helper::generateString(20);

        $api = AccessWorldpay::config(AccessWorldpayConfigProvider::instance());

        $apiResponse = $api->HPPSetup($amount)
            ->withTransactionReference($transactionReference)
            ->execute();

        $decodedApiResponse = json_decode($apiResponse->rawResponse);

        return [
            [$amount, $transactionReference, $decodedApiResponse->url]
        ];
    }
}
