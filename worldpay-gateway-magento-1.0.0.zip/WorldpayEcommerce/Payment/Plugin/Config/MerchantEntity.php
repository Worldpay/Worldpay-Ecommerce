<?php

namespace WorldpayEcommerce\Payment\Plugin\Config;

use Magento\Config\Model\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;

class MerchantEntity
{

    /**
     * @var ScopeConfigInterface
     */
    protected ScopeConfigInterface $scopeConfig;

    /**
     * @param  ScopeConfigInterface $scopeConfig
     */
    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Check if merchant entity is not changed to strip off masking.
     *
     * @param  Config  $subject
     *
     * @return void
     */
    public function beforeSave(Config $subject)
    {
        $groups = $subject->getGroups();
        if (isset($groups['worldpay_ecommerce'])) {
            $merchantEntityNewValue = $groups['worldpay_ecommerce']['fields']['merchant_entity']['value'];
            if (preg_match('/^\*+[^*]{4}$/', $merchantEntityNewValue)) {
                $merchantEntityOldValue = $this->scopeConfig->getValue('payment/access_worldpay_hpp/merchant_entity');
                if (!empty($merchantEntityOldValue)) {
                    $subject->setDataByPath('payment/access_worldpay_hpp/merchant_entity', $merchantEntityOldValue);
                }
            }
        }
    }
}
