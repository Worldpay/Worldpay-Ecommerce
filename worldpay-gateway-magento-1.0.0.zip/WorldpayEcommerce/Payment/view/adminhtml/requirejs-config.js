var config = {
    config: {
        mixins: {
            'mage/validation': {
                'WorldpayEcommerce_Payment/js/merchant-narrative-validation-mixin': true
            }
        }
    }
};
