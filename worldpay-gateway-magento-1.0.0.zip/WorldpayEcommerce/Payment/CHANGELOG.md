## Worldpay eCommerce for Magento Community Edition Changelog

### Version 1.0.0
* initial release
