<?php

namespace WorldpayEcommerce\Payment\Helper;

use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order\InvoiceRepository;
use Magento\Sales\Model\Order;

class InvoiceHelper
{
    /**
     * @var InvoiceRepository
     */
    protected InvoiceRepository $invoiceRepository;

    /**
     * @param  InvoiceRepository  $invoiceRepository
     */
    public function __construct(InvoiceRepository $invoiceRepository)
    {
        $this->invoiceRepository = $invoiceRepository;
    }

    /**
     * Create invoice.
     *
     * @param  Order   $order
     * @param  string  $transactionId
     * @return void
     * @throws LocalizedException
     */
    public function createInvoice(Order $order, string $transactionId)
    {
        $invoice = $order->prepareInvoice();
        $invoice->getOrder()->setIsInProcess(true);
        $invoice->setTransactionId($transactionId);
        $invoice->register()
                ->pay();

        $this->invoiceRepository->save($invoice);
    }
}
