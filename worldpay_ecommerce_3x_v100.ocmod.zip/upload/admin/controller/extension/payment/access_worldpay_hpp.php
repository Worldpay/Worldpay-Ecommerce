<?php
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/string_utils.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php');

use Worldpay\Api\Enums\Environment;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\Utils\Helper;

class ControllerExtensionPaymentAccessWorldpayHpp extends Controller {

	/**
	 * index
	 *
	 * @return void
	 */
	public function index(): void {

		$this->load->language('extension/payment/access_worldpay_hpp');
		
		$this->document->addStyle('view/stylesheet/access_worldpay_hpp.css');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = [
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/payment/access_worldpay_hpp', 'user_token=' . $this->session->data['user_token'])
			];
		} else {
			$data['breadcrumbs'][] = [
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/payment/access_worldpay_hpp', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'])
			];
		}

		$data['save'] = $this->url->link('extension/payment/access_worldpay_hpp/save', 'user_token=' . $this->session->data['user_token'], true);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		$data['testCredentials'] = $this->url->link('extension/payment/access_worldpay_hpp/testApiCredentialsRequest', 'user_token=' . $this->session->data['user_token'], true);
		$data['maskCredentials'] = $this->url->link('extension/payment/access_worldpay_hpp/maskCredentialsRequest', 'user_token=' . $this->session->data['user_token'], true);

		$data = array_merge($data, $this->getSettingFields());

		$data['mbstring_enabled'] = extension_loaded('mbstring');
		$data['intl_enabled']     = extension_loaded('intl');

		$data['header']      = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer']      = $this->load->controller('common/footer');
		$data['error_warning'] = isset($this->session->data['error_warning']) ? $this->session->data['error_warning'] : '';
		unset($this->session->data['error_warning']);

		$this->response->setOutput($this->load->view('extension/payment/access_worldpay_hpp', $data));
	}

	/**
	 * save method
	 *
	 * @return void
	 */
	public function save(): void {
		Logger::config($this->config);
		Logger::logPlatformVersion();

		$this->load->language('extension/payment/access_worldpay_hpp');

		$json = [];

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'][] = $this->language->get('error_invalid_request');
		}
		
		if (!$this->user->hasPermission('modify', 'extension/payment/access_worldpay_hpp')) {
			$json['error']['warning'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$post_request = $this->request->post;
			$errors = $this->validate($post_request);
			if (!empty($errors)) {
				$json['error'] = array_merge($json, $this->validate($post_request));
			}
		}

		if (!$json) {
			$this->load->model('setting/setting');
			$this->model_setting_setting->editSetting('payment_access_worldpay_hpp', $post_request);

			if ($this->testApiCredentials($post_request)) {
				$this->session->data['success'] = $this->language->get('success_test_save_credentials');
				$this->response->redirect( $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
			} else {
				$this->session->data['error_warning'] = $this->language->get('error_test_save_credentials');
				$this->response->redirect($this->url->link('extension/payment/access_worldpay_hpp', 'user_token=' . $this->session->data['user_token'], true));
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param array $post_request
	 *
	 * @return bool
	 */
	protected function testApiCredentials($post_request = []): bool {
		Logger::config($this->config);
		$this->registry->set('worldpay_service', new WorldpayService($this->registry));

		try {
			if (!empty($post_request)) {
				$api_config_provider                    = AccessWorldpayConfigProvider::instance();
				if ($post_request['payment_access_worldpay_hpp_app_mode'] == 'live') {
					$api_config_provider->environment = Environment::LIVE_MODE;
					$api_config_provider->username = $post_request['payment_access_worldpay_hpp_app_live_username'];
					$api_config_provider->password = $post_request['payment_access_worldpay_hpp_app_live_password'];
				} else {
					$api_config_provider->environment = Environment::TRY_MODE;
					$api_config_provider->username = $post_request['payment_access_worldpay_hpp_app_try_username'];
					$api_config_provider->password = $post_request['payment_access_worldpay_hpp_app_try_password'];
				}
				$api_config_provider->merchantEntity    = $post_request['payment_access_worldpay_hpp_app_merchant_entity'];
				$api_config_provider->merchantNarrative = 'Test API Credentials';

				$this->registry->set('api_config_provider', $api_config_provider);
			}

			$worldpay = new WorldpayEcommerce($this->worldpay_service);
			$order = WorldpayService::orderForGatewayCredentialsTest();
			$worldpay->requestHppUrl(Helper::generateString(12) . '_test', $order);

			return true;
		} catch (\Exception $e) {
			Logger::setDescription("Retrieve Hpp url - HPP API Response")->debug($e->getMessage());

			return false;
		}
	}

	/**
	 * @return void
	 */
	public function testApiCredentialsRequest(): void {
		$json = [];

		$this->load->language('extension/payment/access_worldpay_hpp');

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_invalid_request');
		}

		if (!$json) {
			$post_to_forward = [
				'payment_access_worldpay_hpp_app_mode'            => $this->request->post['app_mode'],
				'payment_access_worldpay_hpp_app_merchant_entity' => $this->request->post['app_merchant_entity'],
			];
			$this->replaceMaskedMerchantEntity($post_to_forward);
			if ($this->request->post['app_mode'] == 'try') {
				$post_to_forward['payment_access_worldpay_hpp_app_try_username'] = $this->request->post['app_username'];
				$post_to_forward['payment_access_worldpay_hpp_app_try_password'] = $this->request->post['app_password'];
				$this->replaceMaskedApiTryPassword($post_to_forward);
			} else {
				$post_to_forward['payment_access_worldpay_hpp_app_live_username'] = $this->request->post['app_username'];
				$post_to_forward['payment_access_worldpay_hpp_app_live_password'] = $this->request->post['app_password'];
				$this->replaceMaskedApiLivePassword($post_to_forward);
			}
			if ($this->testApiCredentials($post_to_forward)) {
				$json['status'] = 'success';
			} else {
				$json['status'] = 'failed';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @return void
	 */
	public function maskCredentialsRequest(): void {
		$json = [];

		$this->load->language('extension/payment/access_worldpay_hpp');

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_invalid_request');
		}

		$post_request = $this->request->post;
		$errors = $this->validate($post_request);
		if (!empty($errors)) {
			$json['error'] = array_merge($json, $this->validate($post_request));
		}

		if (!$json) {
			$json = [
				'app_try_password'    => StringUtils::maskStringTotally($this->request->post['app_try_password']),
				'app_live_password'   => StringUtils::maskStringTotally($this->request->post['app_live_password']),
				'app_merchant_entity' => StringUtils::maskStringPartially($this->request->post['app_merchant_entity']),
			];
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validate(array &$post_request): array {
		$validation_methods = [
			'validateApiTryUsername',
			'validateApiTryPassword',
			'validateApiLiveUsername',
			'validateApiLivePassword',
			'validateApiMerchantEntity',
			'validateApiMerchantNarrative',
			'validateApiDescription',
		];

		$errors = [];
		foreach ($validation_methods as $method) {
			$error = $this->{$method}($post_request);
			if (!empty($error)) {
				$errors = array_merge($errors, $error);
			}
		}

		return $errors;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiTryUsername(array $post_request): array {
		$error = [];

		if (array_key_exists('payment_access_worldpay_hpp_app_mode', $post_request)
			&& $post_request['payment_access_worldpay_hpp_app_mode'] === 'try'
	        && empty( $post_request['payment_access_worldpay_hpp_app_try_username'] ) ) {
			$error['app-try-username'] = $this->language->get( 'error_try_username' );
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiTryPassword(array &$post_request): array {
		$error = [];
		$this->replaceMaskedApiTryPassword($post_request);


		if (array_key_exists('payment_access_worldpay_hpp_app_mode', $post_request)
		    && $post_request['payment_access_worldpay_hpp_app_mode'] === 'try'
			&& empty($post_request['payment_access_worldpay_hpp_app_try_password'])) {
			$error['app-try-password'] = $this->language->get('error_try_password');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedApiTryPassword(array &$post_request): void {
		$configured_value = $this->config->get('payment_access_worldpay_hpp_app_try_password');
		if (!empty($configured_value) && preg_match('/^[*]+$/', $post_request['payment_access_worldpay_hpp_app_try_password'])
			&& $post_request['payment_access_worldpay_hpp_app_try_password'] != $configured_value) {
			$post_request['payment_access_worldpay_hpp_app_try_password'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiLiveUsername(array $post_request): array {
		$error = [];
		if (array_key_exists('payment_access_worldpay_hpp_app_mode', $post_request)
		    && $post_request['payment_access_worldpay_hpp_app_mode'] === 'live'
			&& empty($post_request['payment_access_worldpay_hpp_app_live_username'])) {
			$error['app-live-username'] = $this->language->get('error_live_username');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiLivePassword(array &$post_request): array {
		$error = [];
		$this->replaceMaskedApiLivePassword($post_request);
		if (array_key_exists('payment_access_worldpay_hpp_app_mode', $post_request)
		    && $post_request['payment_access_worldpay_hpp_app_mode'] === 'live'
			&& empty($post_request['payment_access_worldpay_hpp_app_live_password'])) {
			$error['app-live-password'] = $this->language->get('error_live_password');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedApiLivePassword(array &$post_request): void {
		$configured_value = $this->config->get('payment_access_worldpay_hpp_app_live_password');
		if (!empty($configured_value) && preg_match('/^[*]+$/', $post_request['payment_access_worldpay_hpp_app_live_password'])
			&& $post_request['payment_access_worldpay_hpp_app_live_password'] != $configured_value) {
			$post_request['payment_access_worldpay_hpp_app_live_password'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantEntity(array &$post_request): array {
		$error = [];
		$this->replaceMaskedMerchantEntity($post_request);
		if (empty($post_request['payment_access_worldpay_hpp_app_merchant_entity'])
			|| strlen($post_request['payment_access_worldpay_hpp_app_merchant_entity']) > 32) {
			$error['app-merchant-entity'] = $this->language->get('error_merchant_entity');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return void
	 */
	protected function replaceMaskedMerchantEntity(array &$post_request): void {
		$configured_value = $this->config->get('payment_access_worldpay_hpp_app_merchant_entity');
		if (!empty($configured_value) && preg_match('/^\*+[^*]{4}$/', $post_request['payment_access_worldpay_hpp_app_merchant_entity'])
			&& $post_request['payment_access_worldpay_hpp_app_merchant_entity'] != $configured_value) {
			$post_request['payment_access_worldpay_hpp_app_merchant_entity'] = $configured_value;
		}
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiMerchantNarrative(array $post_request): array {
		$error = [];
		if (empty($post_request['payment_access_worldpay_hpp_app_merchant_narrative'])
			|| strlen($post_request['payment_access_worldpay_hpp_app_merchant_narrative']) > 24) {
			$error['app-merchant-narrative'] = $this->language->get('error_live_narrative');
		}

		return $error;
	}

	/**
	 * @param array $post_request
	 *
	 * @return array
	 */
	protected function validateApiDescription(array $post_request): array {
		$error = [];
		if (!empty($post_request['payment_access_worldpay_hpp_app_merchant_description'])
		    && strlen($post_request['payment_access_worldpay_hpp_app_merchant_description']) > 128) {
			$error['app-description'] = $this->language->get('error_description');
		}

		return $error;
	}

	/**
	 * @return void
	 */
	public function order() {
		$this->load->language('extension/payment/access_worldpay_hpp');
		$this->load->model('extension/payment/access_worldpay_hpp');
		$this->load->model('localisation/currency');

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id'] = $this->request->get['order_id'];

		$transactions = $this->model_extension_payment_access_worldpay_hpp->getAllTransactionsByOrderId($data['order_id']);
		if (!empty($transactions)) {
			foreach ($transactions as $key => $transaction) {
				$transactions[$key]['formatted_amount'] = $this->formatCurrencyAmount($transaction['amount'], $transaction['currency']);
			}

			$data['transactions'] = $transactions;
			$data['refunds'] = $this->refundsHistory();
		}

		return $this->load->view('extension/payment/access_worldpay_hpp_order', $data);
	}

	/**
	 * @return void
	 */
	public function history(): void {
		$this->response->setOutput($this->refundsHistory());
	}

	/**
	 * @return mixed
	 */
	public function refundsHistory() {
		$this->document->addStyle('view/stylesheet/access_worldpay_hpp.css');
		$this->load->language('extension/payment/access_worldpay_hpp');
		$this->load->model('extension/payment/access_worldpay_hpp');
		$this->load->model('localisation/currency');

		$data['user_token'] = $this->session->data['user_token'];
		$data['order_id'] = $this->request->get['order_id'] ?? 0;
		$data['refund_action'] = $this->url->link('extension/payment/access_worldpay_hpp/refund', ['user_token' => $data['user_token'], 'order_id' => $data['order_id']], true);

		$data['can_refund'] = false;

		$refunded_amount = 0;
		$transaction = $this->model_extension_payment_access_worldpay_hpp->getFinalizedTransactionByOrderId((int)$data['order_id'], WorldpayService::TRANSACTION_STATUS_SUCCESS);
		if (!empty($transaction)) {
			$refunds = $this->model_extension_payment_access_worldpay_hpp->getAllRefundsByOrderId((int)$data['order_id']);

			if (!empty($refunds)) {
				foreach ($refunds as $refund_key => $refund) {
					$refunded_amount += $refund['amount'];
					$refunds[$refund_key]['formatted_amount'] = $this->formatCurrencyAmount($refund['amount'], $refund['currency']);
				}
				$data['refunds'] = $refunds;
			}
			if (empty($refunded_amount) || ($refunded_amount < $transaction['amount'])) {
				$data['can_refund'] = true;
			}
			$transaction['refunded_amount'] = $refunded_amount;
			$transaction['available_amount'] = number_format((float)($transaction['amount'] - $refunded_amount), 2, '.', '');
			$transaction['formatted_amount'] = $this->formatCurrencyAmount($transaction['amount'], $transaction['currency']);
			$transaction['formatted_available_amount'] = $this->formatCurrencyAmount($transaction['available_amount'], $transaction['currency']);
			$transaction['currency_sign'] = $this->currency->getSymbolLeft($transaction['currency']);

			$data['transaction'] = $transaction;
		}

		return $this->load->view('extension/payment/access_worldpay_hpp_order_refunds', $data);
	}

	/**
	 * @return void
	 */
	public function refund(): void {
		Logger::config($this->config);
		$json = [];

		$this->load->language('extension/payment/access_worldpay_hpp');

		if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$json['error'] = $this->language->get('error_invalid_request');
		}

		$order_id = $this->request->post['access_worldpay_hpp_full_refund_order_id'] ?? '';

		$refund_amount = $this->request->post['access_worldpay_hpp_full_refund_amount'] ?? '0.00';
		$partial_refund_reference = '';
		if (!empty($this->request->post['access_worldpay_hpp_partial_refund_amount'])) {
			$partial_refund_amount = $this->request->post['access_worldpay_hpp_partial_refund_amount'];
			if ((float)$partial_refund_amount > (float)$refund_amount) {
				$json['error'] = $this->language->get('error_partial_refund_amount_high');
			} elseif ((float)$partial_refund_amount == (float)$refund_amount) {
				$refund_amount = $partial_refund_amount;
			} else {
				$refund_amount = $partial_refund_amount;
				$partial_refund_reference = Helper::generateString(12) . '-' . $order_id;
			}
		}

		$transaction_reference = $this->request->post['access_worldpay_hpp_full_refund_reference'] ?? '';
		$refund_currency = $this->request->post['access_worldpay_hpp_refund_currency'] ?? '';

		if (!$json) {
			try {
				$this->registry->set('worldpay_service', new WorldpayService($this->registry));
				$worldpay = new WorldpayEcommerce($this->worldpay_service);

				$worldpay->refund($order_id, $refund_amount, $refund_currency, $transaction_reference, $partial_refund_reference);

				$this->load->model('extension/payment/access_worldpay_hpp');
				$this->model_extension_payment_access_worldpay_hpp->saveRefundDetails($order_id, $this->request->post['access_worldpay_hpp_transaction_id'], $partial_refund_reference, $refund_amount, $refund_currency);

				$this->addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference);

				$json['success'] = $this->language->get('success_refund_processed');
			} catch (\Exception $e) {
				$data_to_log = [
					'message'               => $e->getMessage(),
					'order_id'              => $order_id,
					'refund_amount'         => $refund_amount,
					'transaction_reference' => $transaction_reference,
				];
				Logger::setDescription("Refund failed")->alert($data_to_log);
				$json['error'] = $this->language->get('error_refund_failed');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @param $order_id
	 * @param $refund_amount
	 * @param $partial_refund_reference
	 *
	 * @return void
	 */
	protected function addRefundHistoryToOrder($order_id, $refund_amount, $partial_refund_reference): void {
		$this->load->model('sale/order');

		$order_data = $this->model_sale_order->getOrder($order_id);
		$order_note = $this->currency->format($refund_amount, $order_data['currency_code'], 1) . $this->language->get('entry_refund_history')
					  . (!empty($partial_refund_reference) ? ($this->language->get('entry_partial_refund_history') . $partial_refund_reference) : (''));

		$post = [
			'order_status_id' => $order_data['order_status_id'],
			'comment'         => $order_note,
			'order_id'        => $order_id,
		];

        $this->addOrderHistory($order_id, $post);
	}

	/**
	 * @return void
	 */
	public function install(): void {
		$extension_route = 'extension/payment/access_worldpay_hpp';

		$this->load->model($extension_route);
		$this->model_extension_payment_access_worldpay_hpp->install();

		$this->load->model('setting/extension');

		if(in_array('access_worldpay_hpp', $this->model_setting_extension->getInstalled('payment'))) {
			return;
		}

		$this->model_setting_extension->install('payment', 'access_worldpay_hpp');

		$this->load->model('user/user_group');

		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', $extension_route);
		$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', $extension_route);
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$extension_route = 'extension/payment/access_worldpay_hpp';

		$this->load->model($extension_route);
		$this->model_extension_payment_access_worldpay_hpp->uninstall();

		$this->load->model('setting/extension');

		if(!in_array('access_worldpay_hpp', $this->model_setting_extension->getInstalled('payment'))) {
			return;
		}

		$this->model_setting_extension->uninstall('payment', 'access_worldpay_hpp');

		$this->load->model('user/user_group');

		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', $extension_route);
		$this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', $extension_route);
	}

	/**
	 * @return array
	 */
	protected function getSettingFields(): array {
		return [
			'payment_access_worldpay_hpp_status'                 => $this->config->get('payment_access_worldpay_hpp_status'),
			'payment_access_worldpay_hpp_app_mode'               => $this->config->get('payment_access_worldpay_hpp_app_mode'),
			'payment_access_worldpay_hpp_checkout_mode'          => $this->config->get('payment_access_worldpay_hpp_checkout_mode'),
			'payment_access_worldpay_hpp_app_try_username'       => $this->config->get('payment_access_worldpay_hpp_app_try_username'),
			'payment_access_worldpay_hpp_app_try_password'       => StringUtils::maskStringTotally($this->config->get('payment_access_worldpay_hpp_app_try_password')),
			'payment_access_worldpay_hpp_app_live_username'      => $this->config->get('payment_access_worldpay_hpp_app_live_username'),
			'payment_access_worldpay_hpp_app_live_password'      => StringUtils::maskStringTotally($this->config->get('payment_access_worldpay_hpp_app_live_password')),
			'payment_access_worldpay_hpp_app_merchant_entity'    => StringUtils::maskStringPartially($this->config->get('payment_access_worldpay_hpp_app_merchant_entity')),
			'payment_access_worldpay_hpp_app_merchant_narrative' => $this->config->get('payment_access_worldpay_hpp_app_merchant_narrative'),
			'payment_access_worldpay_hpp_app_merchant_description'        => $this->config->get('payment_access_worldpay_hpp_app_merchant_description'),
			'payment_access_worldpay_hpp_app_debug'              => $this->config->get('payment_access_worldpay_hpp_app_debug'),
		];
	}

	/**
	 * @param $amount
	 * @param $currencyCode
	 *
	 * @return string
	 */
	private function formatCurrencyAmount($amount, $currencyCode) {
		$currency_symbol_left = $this->currency->getSymbolLeft($currencyCode);
		$currency_symbol_right = $this->currency->getSymbolRight($currencyCode);

		$currency_symbol = $currency_symbol_left ?: $currency_symbol_right;
		$formatted_amount = number_format((float)$amount, 2, '.', '');

		return $currency_symbol ? $currency_symbol . $formatted_amount : $formatted_amount;
	}

	/**
	 * @param $order_id
	 * @param $data
	 * @param $store_id
	 * @return array|bool|string
	 */
    protected function addOrderHistory($order_id, $data, $store_id = 0): string {
        $json = array();

        $this->load->model('setting/store');

        // The URL we send API requests to
        $url = $this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;

        // API login
        $this->load->model('user/api');

        $api_info = $this->model_user_api->getApi($this->config->get('config_api_id'));
        if ($api_info && $this->user->hasPermission('modify', 'sale/order')) {
            $session = new Session($this->config->get('session_engine'), $this->registry);
            $session->start();

            $this->model_user_api->deleteApiSessionBySessionId($session->getId());
            $this->model_user_api->addApiSession($api_info['api_id'], $session->getId(), $this->request->server['REMOTE_ADDR']);

            $session->data['api_id'] = $api_info['api_id'];
            $api_token = $session->getId();
            $session->close();

			// make api call to add refund to order history
			$curl = curl_init();

            // Set SSL if required
            if (substr($url, 0, 5) == 'https') {
                curl_setopt($curl, CURLOPT_PORT, 443);
            }

            $apiUrl = $url . 'index.php?route=api/order/history&order_id=' . $order_id. '&api_token='.$api_token;

            curl_setopt($curl, CURLOPT_HEADER, false);
            curl_setopt($curl, CURLINFO_HEADER_OUT, true);
            curl_setopt($curl, CURLOPT_USERAGENT, $this->request->server['HTTP_USER_AGENT']);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_FORBID_REUSE, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_URL, $apiUrl);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));

            $json = curl_exec($curl);

            curl_close($curl);
        }

        return $json;
    }
}
