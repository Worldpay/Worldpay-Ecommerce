<?php
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');

class ModelExtensionPaymentAccessWorldpayHpp extends Model {
	/**
	 * @return void
	 */
	public function install(): void {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "access_worldpay_hpp_transactions` (
				`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				`order_id` BIGINT UNSIGNED NOT NULL,
				`reference` VARCHAR(100) NOT NULL,
				`amount` DECIMAL(15,4) NOT NULL,
				`currency` VARCHAR(3) NOT NULL,
				`order_status` ENUM('" . WorldpayService::TRANSACTION_STATUS_PENDING . "', '" . WorldpayService::TRANSACTION_STATUS_SUCCESS . "', '" . WorldpayService::TRANSACTION_STATUS_FAILED . "', '" . WorldpayService::TRANSACTION_STATUS_CANCELED . "') DEFAULT '" . WorldpayService::TRANSACTION_STATUS_PENDING . "',
				`success_guid` VARCHAR(36) NOT NULL,
				`failure_guid` VARCHAR(36) NOT NULL,
				`hpp_redirect_url` VARCHAR(512) NOT NULL,
				`finalized` BOOLEAN DEFAULT FALSE,
				`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (`id`),
				KEY (`success_guid`),
				KEY (`failure_guid`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		");

		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "access_worldpay_hpp_refunds` (
				`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				`order_id` BIGINT UNSIGNED NOT NULL,
				`transaction_id` BIGINT UNSIGNED NOT NULL,
				`reference` VARCHAR(100) NOT NULL,
				`amount` DECIMAL(15,4) NOT NULL,
				`currency` VARCHAR(3) NOT NULL,
				`created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (`id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		");
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "access_worldpay_hpp_transactions`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "access_worldpay_hpp_refunds`");
	}

	/**
	 * @param        $order_id
	 * @param string $status
	 *
	 * @return mixed
	 */
	public function getFinalizedTransactionByOrderId(int $order_id, string $status = '') {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "access_worldpay_hpp_transactions` WHERE `order_id` = '" . (int)$order_id . "' AND `finalized` = 1" . (!empty($status) ? " AND `order_status`='" . $this->db->escape($status) . "'" : "") . " LIMIT 1;");

		return $query->row;
	}

	/**
	 * @param $order_id
	 *
	 * @return mixed
	 */
	public function getAllTransactionsByOrderId($order_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "access_worldpay_hpp_transactions` WHERE `order_id` = '" . (int)$order_id . "' ORDER BY `id` DESC");

		return $query->rows;
	}

	public function saveRefundDetails(int $order_id, int $transaction_id, string $reference, float $amount, string $currency): bool {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "access_worldpay_hpp_refunds` SET `order_id` = '" . $order_id . "', `transaction_id` = '" . $transaction_id . "',`reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $amount . "', `currency` = '" . $this->db->escape($currency) . "', `created_at` = NOW();");

		return true;
	}

	public function getAllRefundsByOrderId($order_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "access_worldpay_hpp_refunds` WHERE `order_id` = '" . (int)$order_id . "' ORDER BY `created_at` DESC");

		return $query->rows;
	}
}
