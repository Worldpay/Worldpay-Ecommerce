<?php
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');

class ModelExtensionPaymentAccessWorldpayHpp extends Model {
	/**
	 * getMethods
	 *
	 * @param mixed $address
	 *
	 * @return array
	 */
	public function getMethod($address, $total): array {
		$total = $total ? $total : 0;
		$this->load->language('extension/payment/access_worldpay_hpp');

		$status = true;
		if ($this->session->data['currency'] != 'GBP') {
			$status = false;
		} elseif ($total < 0) {
			$status = false;
		} elseif (!empty($this->cart->getRecurringProducts())){
			$status = false;
		}

		$method_data = [];

		if ($status) {
			$method_data = [
				'code'       => 'access_worldpay_hpp',
				'title'       => $this->language->get('heading_title'),
                'terms' => '',
				'sort_order' => $this->config->get('payment_access_worldpay_hpp_sort_order')
			];
		}

		return $method_data;
	}

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 *
	 * @return bool
	 */
	public function saveTransactionInitialDetails(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url): bool {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `order_id` = '" . (int)$order_data["order_id"] . "', `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW();");

		return true;
	}

	/**
	 * @param array  $order_data
	 * @param string $reference
	 * @param string $success_guid
	 * @param string $failure_guid
	 * @param string $hpp_url
	 *
	 * @return bool
	 */
	public function updateTransactionInitialDetailsByOcOrderId(array $order_data, string $reference, string $success_guid, string $failure_guid, string $hpp_url): bool {
		$query = $this->db->query("UPDATE `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `reference` = '" . $this->db->escape($reference) . "', `amount` = '" . $order_data["total"] . "', `currency` = '" . $order_data["currency_code"] . "', `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "', `success_guid` = '" . $this->db->escape($success_guid) . "', `failure_guid` = '" . $this->db->escape($failure_guid) . "', `hpp_redirect_url` = '" . $this->db->escape($hpp_url) . "', `created_at` = NOW() WHERE `order_id` = " . (int)$order_data["order_id"] . ";");

		return true;
	}

	/**
	 * @param string $guid
	 *
	 * @return array
	 */
	public function getTransactionDetailsByGuid(string $guid): array {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "access_worldpay_hpp_transactions` WHERE (`success_guid` = '" . $this->db->escape($guid) . "' OR `failure_guid` = '" . $this->db->escape($guid) . "') AND `finalized` = false AND `order_status` = '" . WorldpayService::TRANSACTION_STATUS_PENDING . "' ORDER BY `id` DESC LIMIT 1;");

		return $query->row;
	}

	/**
	 * @param int    $id
	 * @param string $status
	 *
	 * @return bool
	 */
	public function changeTransactionStatus(int $id, string $status): bool {
		if (!in_array($status, [WorldpayService::TRANSACTION_STATUS_SUCCESS, WorldpayService::TRANSACTION_STATUS_FAILED])) {
			return false;
		}
		$finalized = (int)($status === WorldpayService::TRANSACTION_STATUS_SUCCESS ? true : false);

		$query = $this->db->query("UPDATE `" . DB_PREFIX . "access_worldpay_hpp_transactions` SET `finalized` = " . $finalized . ", `order_status` = '" . $status . "' WHERE `id` = " . $id . ";");

		return true;
	}
}
