<?php
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/string_utils.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/logger.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_service.php');
require_once(DIR_SYSTEM . 'library/worldpay_ecommerce/worldpay_ecommerce.php');

use Worldpay\Api\Utils\Helper;

class ControllerExtensionPaymentAccessWorldpayHpp extends Controller {
	/**
	 * @return string
	 */
	public function index(): string {
		$data['language'] = $this->config->get('config_language');

		return $this->load->view('extension/payment/access_worldpay_hpp', $data);
	}

	/**
	 * @throws \Exception
	 *
	 * @return void
	 */
	public function confirm(): void {
		Logger::config($this->config);

		$this->registry->set('worldpay_service', new WorldpayService($this->registry));
		$this->load->language('extension/payment/access_worldpay_hpp');
		$this->load->model('extension/payment/access_worldpay_hpp');

		$json = $this->validateOrder();

		$order_id = $this->session->data['order_id'] ?? 0;
		$this->load->model('checkout/order');
		$order_data = $this->model_checkout_order->getOrder($order_id);
		if (empty($order_data)) {
			$json['error'] = $this->language->get('error_order');
		}

		if (!$json) {
			$success_guid = Helper::guidv4();
			$failure_guid = Helper::guidv4();
			$transaction_reference =  WorldpayService::getTransactionReferenceByOrderId($order_id);

			$success_return_url = $this->url->link('extension/payment/access_worldpay_hpp/returnUrl', ['language' => $this->config->get('config_language'), 'guid' => $success_guid], false);
			$failure_return_url = $this->url->link('extension/payment/access_worldpay_hpp/returnUrl', ['language' => $this->config->get('config_language'), 'guid' => $failure_guid], false);
			$cancel_return_url = $this->url->link('checkout/checkout', ['language' => $this->config->get('config_language')]);

			// currency conversion manage
			$order_currency_conversion_log_info = [
				'session_currency'     => $this->session->data['currency'],
				'config_currency'      => $this->config->get('config_currency'),
				'order_total'          => $order_data['total'],
				'order_currency_code'  => $order_data['currency_code'],
				'order_currency_value' => $order_data['currency_value'],
			];
			$order_data['total'] = $this->currency->format($order_data['total'], $order_data['currency_code'], $order_data['currency_value'], false);
			$order_currency_conversion_log_info['currency_conversion_amount'] = $order_data['total'];

			try {
				$worldpay = new WorldpayEcommerce($this->worldpay_service, $order_data);
				$hpp_url = $worldpay->retrieveHppUrl($transaction_reference, $success_return_url, $failure_return_url, $cancel_return_url);
				$json['redirect'] = $hpp_url;
				unset($this->session->data['order_id']);

				$note = $this->currency->format($order_data['total'], $order_data['currency_code'], 1) . ' awaiting payment via Worldpay. Transaction reference ' . $transaction_reference;
				$this->model_checkout_order->addOrderHistory($order_id, WorldpayService::OC_ORDER_STATUS_ID_PENDING, $note);

				if (empty($order_details)) {
					$this->model_extension_payment_access_worldpay_hpp->saveTransactionInitialDetails($order_data, $transaction_reference, $success_guid, $failure_guid, $hpp_url);
				} else {
					$this->model_extension_payment_access_worldpay_hpp->updateTransactionInitialDetailsByOcOrderId($order_data, $transaction_reference, $success_guid, $failure_guid, $hpp_url);
				}

				$data_to_log = [
					"order_id"                  => $order_id,
					"order_data"                => $order_data,
					"order_currency_conversion" => $order_currency_conversion_log_info
				];
				Logger::setDescription("Retrieve Hpp url")->debug($data_to_log);
			} catch (\Throwable $exception) {
				$data_to_log = [
					"message"                   => $exception->getMessage(),
					"order_id"                  => $order_id,
					"order_data"                => $order_data,
					"success_return_url"        => $success_return_url,
					"failure_return_url"        => $failure_return_url,
					"cancel_return_url"         => $cancel_return_url,
					"transaction_reference"     => $transaction_reference,
					"hpp_url"                   => $hpp_url ?? "",
					"order_currency_conversion" => $order_currency_conversion_log_info
				];
				Logger::setDescription("Retrieve Hpp url failed")->alert($data_to_log);

				$json['error'] = $this->language->get('error_payment_hpp_url');
			}
		} else {
			$data_to_log = [
				"order_id"     => $order_id ?? "",
				"order_data"   => $order_data ?? [],
				"confirm_json" => $json,
			];
			Logger::setDescription("Retrieve Hpp url failed - configuration error")->alert($data_to_log);
		}

        $errors_thrown_by_oc = ob_get_contents();
        if (strlen($errors_thrown_by_oc)) {
            Logger::setDescription("Confirm error thrown by OpenCart")->alert([$errors_thrown_by_oc]);
            ob_clean();
        }

        $this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * @return void
	 */
	public function returnUrl(): void {
		Logger::config($this->config);

		$url_redirect_params = [
			'language' => $this->config->get('config_language')
		];

		$data = [];
		$this->load->language('extension/payment/access_worldpay_hpp');
		$this->load->model('extension/payment/access_worldpay_hpp');
		$this->load->model('checkout/order');

		$guid = $this->request->get["guid"] ?? '';
		if (empty($guid)) {
			$data_to_log = [
				"request_data" => $this->request->get,
			];
			Logger::setDescription("Return url - invalid guid")->alert($data_to_log);
			$this->redirectToNotFound();
		}

		$order_details = $this->model_extension_payment_access_worldpay_hpp->getTransactionDetailsByGuid($guid);
		if (empty($order_details)) {
			$data_to_log = [
				"request_data" => $this->request->get,
			];
			Logger::setDescription("Return url - invalid order")->alert($data_to_log);
			$this->redirectToNotFound();
		}

		$order_id = $order_details['order_id'];

		$data_to_log = [
			"guid"          => $guid,
			"order_id"      => $order_id,
			"order_details" => $order_details,
			"request_data"  => $this->request->get,
		];
		$data_to_log["order_details"]["amount"] = number_format($order_details['amount'], 2, '.', '');

		$amount_with_currency = $this->currency->format($order_details['amount'], $order_details['currency'], 1);

		switch ($guid) {
			case $order_details["success_guid"]:
				$order_note = $amount_with_currency . " " . $this->language->get('payment_success_via_worldpay') . $order_details["reference"];
				$data['redirect'] = $this->processPaymentSuccessUrl($order_details, $url_redirect_params, $order_note);

				$data_to_log["order_details"]["order_status"] = WorldpayService::TRANSACTION_STATUS_SUCCESS;
				$this->session->data['order_id'] = $order_id;
				Logger::setDescription("Return url - success payment")->debug($data_to_log);
				break;

			case $order_details["failure_guid"]:
				$order_note = $amount_with_currency . " " . $this->language->get('payment_failed_via_worldpay') . $order_details["reference"];
				$data['redirect'] = $this->processPaymentFailureUrl($order_details, $url_redirect_params, $order_note);

				$data_to_log["order_details"]["order_status"] = WorldpayService::TRANSACTION_STATUS_FAILED;
				Logger::setDescription("Return url - failed payment")->debug($data_to_log);
				break;
		}

		$this->response->redirect($data['redirect']);
	}

	/**
	 * @return array
	 */
	protected function validateOrder(): array {
		$json = [];

		if (!isset($this->session->data['order_id'])) {
			$json['error'][] = $this->language->get('error_order');
		}

		if (!isset($this->session->data['payment_method']) || $this->session->data['payment_method']['code'] != 'access_worldpay_hpp') {
			$json['error'][] = $this->language->get('error_payment_method');
		}

		return $json;
	}

	/**
	 * @param        $order_details
	 * @param array  $url_redirect_params
	 * @param string $order_note
	 *
	 * @return string
	 */
	protected function processPaymentSuccessUrl($order_details, array $url_redirect_params, string $order_note): string {
		$this->model_checkout_order->addOrderHistory($order_details['order_id'], WorldpayService::OC_ORDER_STATUS_ID_PROCESSING, $order_note, true);
		$this->model_extension_payment_access_worldpay_hpp->changeTransactionStatus($order_details['id'], WorldpayService::TRANSACTION_STATUS_SUCCESS);

		if (empty($url_redirect_params)) {
			return "";
		}

		return $this->url->link('checkout/success', $url_redirect_params, true);
	}

	/**
	 * @param        $order_details
	 * @param array  $url_redirect_params
	 * @param string $order_note
	 *
	 * @return string
	 */
	protected function processPaymentFailureUrl($order_details, array $url_redirect_params, string $order_note): string {
		$this->model_checkout_order->addOrderHistory($order_details['order_id'], WorldpayService::OC_ORDER_STATUS_ID_FAILED, $order_note, true);
		$this->model_extension_payment_access_worldpay_hpp->changeTransactionStatus($order_details['id'], WorldpayService::TRANSACTION_STATUS_FAILED);

		return $this->url->link('checkout/failure', $url_redirect_params, true);
	}

	/**
	 * @return void
	 */
	protected function redirectToNotFound(): void {
		$this->response->redirect($this->url->link('error/not_found', 'language=' . $this->config->get('config_language')));
	}
}
