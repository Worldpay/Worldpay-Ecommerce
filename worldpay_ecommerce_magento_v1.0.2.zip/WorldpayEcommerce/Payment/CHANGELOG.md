## Worldpay eCommerce for Magento Community Edition Changelog

### Version 1.0.2
* changed wording for some of the merchant settings inputs
* fixed billing and shipping address not being sent to the gateway
* delayed the order confirmation mails to only be sent after a successful payment

### Version 1.0.1
* fixed bug for empty merchant settings fields at fresh module install

### Version 1.0.0
* initial release
