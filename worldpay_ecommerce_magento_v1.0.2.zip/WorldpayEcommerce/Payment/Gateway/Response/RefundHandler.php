<?php

namespace WorldpayEcommerce\Payment\Gateway\Response;

use Magento\Framework\App\ObjectManager;
use Magento\Payment\Gateway\Response\HandlerInterface;
use Magento\Payment\Gateway\Helper\SubjectReader;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\OrderFactory;

class RefundHandler implements HandlerInterface
{
    /**
     * @var SubjectReader
     */
    protected SubjectReader $subjectReader;

    /**
     * @var OrderRepositoryInterface
     */
    protected OrderRepositoryInterface $orderRepository;

    /**
     * Constructor.
     *
     * @param  SubjectReader             $subjectReader
     * @param  OrderRepositoryInterface  $orderRepository
     */
    public function __construct(
        SubjectReader $subjectReader,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->subjectReader = $subjectReader;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Handle response.
     *
     * @param  array  $handlingSubject
     * @param  array  $response
     * @return void
     */
    public function handle(array $handlingSubject, array $response)
    {
        $paymentDO = $this->subjectReader->readPayment($handlingSubject);
        $payment = $paymentDO->getPayment();
        $orderInterface = $paymentDO->getOrder();
        $order = $this->orderRepository->get($orderInterface->getId());

        $orderComment = __('%1 sent for refund via Worldpay.', $order->getPayment()->formatPrice($response['refundAmount']));

        if ($response['refundAmount'] < $order->getGrandTotal()) {
            $orderComment .= __(' Partial refund reference: %1.', $response['partialRefundReference']);
            $payment->setTransactionId($response['partialRefundReference']);
        }
        $order->addCommentToStatusHistory($orderComment);
        $this->orderRepository->save($order);
    }
}
