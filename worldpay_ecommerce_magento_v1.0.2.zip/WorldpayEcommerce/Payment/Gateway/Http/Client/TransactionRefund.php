<?php

namespace WorldpayEcommerce\Payment\Gateway\Http\Client;

use Exception;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Payment\Gateway\Http\ClientInterface;
use Magento\Payment\Gateway\Http\TransferInterface;
use Worldpay\Api\Exceptions\ApiException;
use Worldpay\Api\Exceptions\AuthenticationException;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Utils\Helper;
use WorldpayEcommerce\Payment\lib\Service\Logger;
use WorldpayEcommerce\Payment\lib\Service\WorldpayEcommerce;
use WorldpayEcommerce\Payment\lib\Service\WorldpayService;
use WorldpayEcommerce\Payment\Gateway\Config\Config;
use Magento\Framework\Locale\Resolver;

class TransactionRefund implements ClientInterface
{
    /**
     * @var WorldpayService
     */
    protected WorldpayService $worldpayService;

    /**
     * @var Config
     */
    protected Config $config;

    /**
     * @var Resolver
     */
    private Resolver $store;

    /**
     * @param Config $config
     * @param ScopeConfigInterface $scopeConfig
     * @param Resolver $store
     */
    public function __construct(
        Config $config,
        ScopeConfigInterface $scopeConfig,
        Resolver $store,
    ) {
        $this->worldpayService = new WorldpayService($config, $scopeConfig);
        $this->store = $store;
    }

    /**
     * Place request.
     *
     * @param  TransferInterface  $transferObject
     * @return array
     * @throws ClientException
     * @throws \Throwable
     * @throws ApiException
     * @throws AuthenticationException
     * @throws InvalidArgumentException
     */
    public function placeRequest(TransferInterface $transferObject)
    {
        $requestData = $transferObject->getBody();
        $requestData['partialRefundReference'] = Helper::generateString(12) . '-' . $requestData['orderIncrementId'];

        try {
            $worldpay = new WorldpayEcommerce($this->worldpayService, []);

            $apiResponse = $worldpay->refund(
                $requestData['transactionReference'],
                $requestData['refundAmount'],
                $requestData['currency'],
                $this->store->getLocale(),
                $requestData['partialRefundReference']
            );
            $dataToLog = [
                'correlationId' => WorldpayService::getWpCorrelationIdFromHeaders($apiResponse->headers),
                'requestData'   => $requestData,
                'response'      => $apiResponse->rawResponse,
                'statusCode'    => $apiResponse->statusCode,
            ];
            if ($apiResponse->isSuccessful()) {
                Logger::setDescription('Refund request successful. Api call response.')->debug($dataToLog);
                return [
                    'refundAmount'           => $requestData['refundAmount'],
                    'partialRefundReference' => $requestData['partialRefundReference']
                ];
            } else {
                Logger::setDescription('Refund request failed. Api call response.')->alert($dataToLog);
                throw new ClientException(__('Something went wrong while requesting payment refund.'));
            }
        } catch (\Throwable $e) {
            Logger::setDescription('Refund request failed. Exception thrown.')->alert([
                'errorMessage' => $e->getMessage(),
                'requestData'  => $requestData
            ]);
            throw $e;
        }
    }
}
