<?php

namespace WorldpayEcommerce\Payment\Block;

use Magento\Framework\View\Element\Template;
use Magento\Payment\Block\Form as MagentoFormBlock;

class Form extends MagentoFormBlock
{
    /**
     * @param  Template\Context  $context
     * @param  array             $data
     */
    public function __construct(Template\Context $context, array $data = [])
    {
        parent::__construct($context, $data);
    }
}
