<?php

namespace Worldpay\Api;

use Worldpay\Api\Exceptions\ApiResponseException;

class ApiResponse
{
    /**
     * @var int The last response code.
     */
    public int $statusCode;

    /**
     * @var array All headers received.
     */
    public array $headers;

    /**
     * @var string The result.
     */
    public string $rawResponse;

    /**
     * @var string
     */
    public string $curlError;

    /**
     * @var int
     */
    public int $curlErrorNo;

    public $rawRequest;

    /**
     * Determine if the request was successful (status codes in the 2xx range).
     *
     * @return bool
     */
    public function isSuccessful(): bool {
        return $this->statusCode >= 200 && $this->statusCode < 300;
    }

    /**
     * @return bool
     */
    public function hasError(): bool {
        return !empty($this->curlErrorNo);
    }

    /**
     * Determine if the response indicates problems on the server side of the connection (status codes in the 5xx range).
     *
     * @return bool
     */
    public function hasServerError(): bool {
        return $this->statusCode >= 500;
    }

    /**
     * Determine if the response indicates problems with the request which must be resolved (status codes in the 4xx range).
     *
     * @return bool
     */
    public function hasClientError(): bool {
        return $this->statusCode >= 400 && $this->statusCode <500;
    }

    /**
     * @param  bool|null  $associative
     *
     * @return object|mixed
     * @throws ApiResponseException
     */
    public function jsonDecode(?bool $associative = null): object {
        $decodedResponse = json_decode($this->rawResponse, $associative);
        if ($decodedResponse === null && json_last_error() !== JSON_ERROR_NONE) {
            throw new ApiResponseException(json_last_error_msg());
        }

        return $decodedResponse;
    }
}
