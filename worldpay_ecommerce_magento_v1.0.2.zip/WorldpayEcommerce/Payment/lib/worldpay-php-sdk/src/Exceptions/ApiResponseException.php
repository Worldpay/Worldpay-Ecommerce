<?php

namespace Worldpay\Api\Exceptions;

/**
 * Exception thrown when response received from Access Worldpay APIs cannot be decoded.
 */
class ApiResponseException extends \Exception
{

}
