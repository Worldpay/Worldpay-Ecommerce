<?php

namespace Worldpay\Api\Builders\HostedPaymentPages;

use Worldpay\Api\Builders\ApiBuilderInterface;
use Worldpay\Api\Entities\Customer;
use Worldpay\Api\Exceptions\InvalidArgumentException;
use Worldpay\Api\Providers\AccessWorldpayConfigProvider;
use Worldpay\Api\ValueObjects\BillingAddress;
use Worldpay\Api\ValueObjects\ResultURLs;
use Worldpay\Api\ValueObjects\ShippingAddress;

class AccessWorldpayHPPBuilder implements ApiBuilderInterface
{
    /**
     * @var HostedPaymentPagesBuilder
     */
    private HostedPaymentPagesBuilder $baseBuilder;

    /**
     * @param  HostedPaymentPagesBuilder  $builder
     */
    public function __construct(HostedPaymentPagesBuilder $builder) {
        $this->baseBuilder = $builder;
    }

    /**
     * @return false|string
     * @throws InvalidArgumentException
     */
    public function createPayload() {
        $payload = [];

        $apiConfigProvider = AccessWorldpayConfigProvider::instance();
        $payload['merchant']['entity'] = $apiConfigProvider->merchantEntity;
        $payload['narrative']['line1'] = $apiConfigProvider->merchantNarrative;

        if (empty($this->baseBuilder->transactionReference)) {
            throw new InvalidArgumentException('Invalid transaction reference.');
        }
        $payload['transactionReference'] = $this->baseBuilder->transactionReference;

        $payload['value']['currency'] = $this->baseBuilder->currency;
        $payload['value']['amount'] = $this->baseBuilder->amount;

        if (!empty($this->baseBuilder->description)) {
            $payload['description'] = $this->baseBuilder->description;
        }
        if (isset($this->baseBuilder->billingAddress) && $this->baseBuilder->billingAddress instanceof BillingAddress) {
            $payload['billingAddress'] = $this->baseBuilder->billingAddress;
        }
        if (isset($this->baseBuilder->resultURLs) && $this->baseBuilder->resultURLs instanceof ResultURLs) {
            $payload['resultURLs'] = $this->baseBuilder->resultURLs;
        }
        if (!empty($this->baseBuilder->expiry)) {
            $payload['expiry'] = $this->baseBuilder->expiry;
        }
        if (isset($this->baseBuilder->shippingAddress) && $this->baseBuilder->shippingAddress instanceof ShippingAddress) {
            $payload['riskData']['shipping']['address'] = $this->baseBuilder->shippingAddress;
        }
        if (!empty($this->baseBuilder->shippingEmail)) {
            $payload['riskData']['shipping']['email'] = $this->baseBuilder->shippingEmail;
        }
        if (!empty($this->baseBuilder->shippingMethod)) {
            $payload['riskData']['shipping']['method'] = $this->baseBuilder->shippingMethod;
        }
        if (isset($this->baseBuilder->customer) && $this->baseBuilder->customer instanceof Customer) {
            if (!empty($this->baseBuilder->customer->email)) {
                $payload['riskData']['account']['email'] = $this->baseBuilder->customer->email;
            }
            if (!empty($this->baseBuilder->customer->firstName) && !empty($this->baseBuilder->customer->lastName)) {
                $payload['riskData']['transaction']['firstName'] = $this->baseBuilder->customer->firstName;
                $payload['riskData']['transaction']['lastName'] = $this->baseBuilder->customer->lastName;
            }
            if (!empty($this->baseBuilder->customer->phoneNumber)) {
                $payload['riskData']['transaction']['phoneNumber'] = $this->baseBuilder->customer->phoneNumber;
            }
        }

        return json_encode($payload);
    }
}
