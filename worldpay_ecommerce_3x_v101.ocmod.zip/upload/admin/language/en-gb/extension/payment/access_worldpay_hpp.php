<?php

// Heading
$_['heading_title'] = 'Worldpay Payment';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success']   = 'Success: You have modified Worldpay Payment payment module!';
$_['text_edit']      = 'Edit Worldpay Payment';
$_['text_test_try']  = 'Test try credentials';
$_['text_test_live'] = 'Test live credentials';

// Admin settings entries
$_['entry_general_settings']            = 'General Settings';
$_['entry_status']                      = 'Extension status';
$_['entry_try_live_mode']               = 'Select environment';
$_['entry_try_live_mode_help']          = 'Choose between try/test or live/production mode which will influence the used credentials.';
$_['entry_try_mode']                    = 'Try';
$_['entry_live_mode']                   = 'Live';
$_['entry_checkout_mode']               = 'Checkout mode';
$_['entry_redirect_mode']               = 'Redirect';
$_['entry_iframe_mode']                 = 'Iframe';
$_['entry_username']                    = 'Username';
$_['entry_password']                    = 'Password';
$_['entry_try_credential_settings']     = 'Try API Credentials';
$_['entry_live_credential_settings']    = 'Live API Credentials';
$_['entry_credentials_help']            = 'Get your credentials from your <a target="_blank" href="https://dashboard.worldpay.com/">Worldpay Dashboard</a>.';
$_['entry_merchant_settings']           = 'Merchant Settings';
$_['entry_merchant_entity']             = 'Merchant entity';
$_['entry_merchant_entity_help']        = 'You can find your entity in your <a target="_blank" href="https://dashboard.worldpay.com/">Worldpay Dashboard</a> under the currency tab setting.';
$_['entry_merchant_entity_placeholder'] = 'POxxxxxxxxx';
$_['entry_merchant_narrative']          = 'Merchant narrative';
$_['entry_merchant_narrative_help']     = 'Helps your customers better identify you on their statement.';
$_['entry_merchant_narrative_help_valid']     = 'Please enter a valid merchant narrative. Valid characters are: A-Z, a-z, 0-9, hyphen(-), full stop(.), commas(,), space.';
$_['error_merchant_description']                 = 'Description';
$_['error_merchant_description_help']            = 'An optional text, when supplied is displayed to your customer on payment pages.';
$_['entry_debug_settings']              = 'Debug';
$_['entry_debug']                       = 'Debug mode';
$_['entry_debug_help']                  = 'Debug your connection to Worldpay.';
$_['entry_refund_history']              = ' sent for payment refund';
$_['entry_partial_refund_history']      = '. Partial refund reference: ';

//Admin order tab
$_['column_date']                     = 'Date';
$_['column_status']                   = 'Status';
$_['column_event']                    = 'Event';
$_['column_transaction_reference']    = 'Transaction Reference';
$_['column_partial_refund_reference'] = 'Partial Refund Reference';
$_['column_amount']                   = 'Amount';

$_['line_transaction_details']          = 'Transaction Details';
$_['line_refunds_details']              = 'Refunds Details';
$_['line_transaction_refund']           = 'Refund Transaction';
$_['line_full_refund']                  = 'Full refund';
$_['line_partial_refund']               = 'Partial refund';
$_['button_refund']                     = 'Refund';
$_['text_no_results']                   = 'No transactions found';
$_['text_refunds_no_results']           = 'No refunds found';
$_['text_choose_refund_type']           = 'Choose if you want to issue a full or partial refund:';
$_['text_event_refund_requested']       = 'Refund Requested';
$_['note_refund_request']               = 'Note: Please do not re-attempt to perform same refund. Refund request may take some time to process.';
$_['alert_select_refund_type']          = 'Please select a refund type.';
$_['alert_enter_partial_refund_amount'] = 'Please enter a partial refund amount.';
$_['modal_button_cancel']               = 'Cancel';
$_['modal_button_confirm']              = 'Confirm';

// Error
$_['error_php_version']                = 'Worldpay eCommerce requires PHP 7.3.33 or higher. You are using PHP %s.';
$_['error_php_extension']              = 'Worldpay eCommerce cannot be enabled because <strong>%s</strong> extension is not loaded on the server.';
$_['error_compatibility_check']        = 'Compatibility check failed. Please resolve the issues and try again.';
$_['error_permission']                 = 'Warning: You do not have permission to modify payment Worldpay Payment!';
$_['error_try_username']               = 'The API Try username is mandatory when you enable Try mode.';
$_['error_try_password']               = 'The API Try password is mandatory when you enable Try mode.';
$_['error_live_username']              = 'The API Live username is mandatory when you enable Live mode.';
$_['error_live_password']              = 'The API Live password is mandatory when you enable Live mode.';
$_['error_merchant_entity']            = 'The merchant entity is mandatory. Maximum of 32 characters.';
$_['error_merchant_narrative']         = 'The merchant narrative is mandatory. Maximum of 24 characters.';
$_['error_description']                = 'The description can have a maximum of 128 characters.';
$_['error_test_save_credentials']      = 'Your settings were saved, but Worldpay Payment could not connect to the payment gateway with your provided credentials.';
$_['error_test_credentials']           = 'Worldpay Payment could not connect to the payment gateway with your provided credentials.';
$_['error_payment_method']             = 'Payment method is incorrect!';
$_['error_partial_refund_amount_high'] = 'The partial refund amount cannot be higher than the total transaction amount.';
$_['error_invalid_request']            = 'Invalid request type.';

// Success
$_['success_test_credentials']      = 'Worldpay Payment connected successfully to the payment gateway with your provided credentials.';
$_['success_test_save_credentials'] = 'Your settings were saved and Worldpay Payment connected successfully to the payment gateway with your provided credentials.';
$_['success_refund_processed']      = 'Refund request successfully submitted for processing.';
$_['error_refund_failed']           = 'Refund request failed.';

$_['text_access_worldpay_hpp']		= '<a target="_BLANK" href="https://www.worldpay.com/en-gb"><img src="view/image/payment/worldpay_ecommerce.png" alt="Worldpay eCommerce" title="Worldpay eCommerce" style="max-width: 150px;" /></a>';
